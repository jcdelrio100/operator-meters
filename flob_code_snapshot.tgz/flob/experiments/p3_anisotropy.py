"""
P3: does a FREE overcomplete non-separable frame self-select its anisotropy per data source?
We train the ConvFrame (Exp A) end-to-end on each 2-D task and read the anisotropy of the learned
kernels: for each kernel we take |w|^2 on the k x k grid, its 2nd-moment covariance, eigenvalues
l1>=l2, and aspect ratio rho = sqrt(l2/l1) in (0,1] (1 = isotropic/round ~ wavelet, ->0 = elongated
~ anisotropic curvelet/ridgelet). We compare the rho distribution across tasks -- the empirical alpha
the frame chooses. (Complements Exp B's fixed-alpha sweep with a *learned* anisotropy.)
"""
import sys, os, numpy as np, torch, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from s2frame_study import ConvFrame, to4d, zc

TASKS = ["texture (28x28)", "image digits (real)", "video (motion)"]

def train_frame(name, seed=0, ep=140):
    Xtr, ytr, Xte, yte, nc, _ = MM.load(name, seed)
    A = zc(to4d(name, Xtr)); yt = torch.tensor(ytr)
    torch.manual_seed(seed); net = ConvFrame(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), 3e-3, weight_decay=1e-4)
    for _ in range(ep):
        net.train(); opt.zero_grad(); Fn.cross_entropy(net(A), yt).backward(); opt.step()
    W = net.conv.weight.detach().numpy()               # (M, in_ch, k, k)
    return W

def aspect_ratios(W):
    M, C, k, _ = W.shape; ii, jj = np.mgrid[0:k, 0:k]; coords = np.stack([ii.ravel(), jj.ravel()], 1).astype(float)
    out = []
    for m in range(M):
        w = (W[m] ** 2).sum(0).ravel()                 # collapse channels -> energy map
        s = w.sum()
        if s < 1e-9: continue
        w = w / s; mu = (coords * w[:, None]).sum(0); dc = coords - mu
        Cov = (w[:, None, None] * (dc[:, :, None] * dc[:, None, :])).sum(0)
        ev = np.linalg.eigvalsh(Cov); ev = np.clip(ev, 1e-9, None)
        out.append(np.sqrt(ev[0] / ev[1]))             # l2/l1
    return np.array(out)

data = {}
print(f"{'task':22s} {'mean rho':>9s} {'median':>8s}  (1=isotropic, 0=anisotropic)")
for name in TASKS:
    W = train_frame(name); rho = aspect_ratios(W); data[name] = rho
    print(f"{name:22s} {rho.mean():>9.3f} {np.median(rho):>8.3f}")

fig, ax = plt.subplots(figsize=(9, 5))
labels = list(data); pos = np.arange(len(labels))
parts = ax.violinplot([data[n] for n in labels], positions=pos, showmeans=True, showextrema=False)
for pc in parts["bodies"]: pc.set_facecolor("#1f77b4"); pc.set_alpha(0.5)
for i, n in enumerate(labels): ax.scatter(np.full(len(data[n]), pos[i]) + np.random.default_rng(i).normal(0, 0.03, len(data[n])), data[n], s=8, color="#333", alpha=0.4)
ax.set_xticks(pos); ax.set_xticklabels(labels, fontsize=9); ax.set_ylim(0, 1.02)
ax.set_ylabel(r"kernel aspect ratio $\rho=\sqrt{\lambda_2/\lambda_1}$")
ax.axhline(1.0, ls=":", color="gray"); ax.text(len(labels)-0.5, 0.98, "isotropic", fontsize=8, color="gray", ha="right")
ax.text(len(labels)-0.5, 0.05, "anisotropic (elongated)", fontsize=8, color="gray", ha="right")
ax.set_title("P3 - anisotropy the free overcomplete frame self-selects per data source")
ax.grid(axis="y", alpha=0.3); plt.tight_layout(); plt.savefig(os.path.join(HERE, "p3_anisotropy.png"), dpi=130)
print("saved p3_anisotropy.png")
