"""
SUPERSTRUCTURE COMPARISON (article-2 core experiment).

Same network as article 1 (the self-organizing GatedResidual head) fed by two
different front-ends, under identical conditions (tasks, seeds, K, head, epochs):

  Superstructure 1 (S1) = POOLED DICTIONARY  : fixed transforms {Fourier, DWT, |CWT|,
      scattering} -> discriminative F-ANOVA selection -> head.  (article-1 front-end)
  Superstructure 2 (S2) = LEARNED TRANSFORM  : Stage 1 learns a unitary U from scratch
      (no predefined transform, hybrid CE+sparsity); Stage 2 injects |Ux| -> selection
      -> the SAME head.

We compare accuracy, convergence (test-acc vs epoch of the shared head) and TOTAL
trainable parameters (transform + head). All chart labels in English.
"""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn, sys, os, json
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import wave_extractors as W
from learned_transform import UnitaryClassifier, StructuredUnitary, train as train_uni
import chirp_tasks, classic_tasks

K = 16
SEEDS = [0, 1, 2]
HEAD_EPOCHS = 400
REC_EVERY = 10


# ---------------- shared head (article 1) ----------------
class GatedResidual(nn.Module):
    def __init__(self, K, C, blocks=2, h=32, init_g=1.0):
        super().__init__()
        self.lin = nn.Linear(K, C)
        self.blocks = nn.ModuleList([nn.Sequential(nn.Linear(K, h), nn.ReLU(), nn.Linear(h, C))
                                     for _ in range(blocks)])
        self.gates = nn.Parameter(torch.full((blocks,), float(init_g)))
        self.K, self.C, self.h = K, C, h
    def forward(self, x):
        out = self.lin(x)
        for g, b in zip(self.gates, self.blocks):
            out = out + g * b(x)
        return out
    def lin_params(self): return self.K * self.C + self.C
    def block_params(self): return self.K * self.h + self.h + self.h * self.C + self.C


def fit_head(A, ytr, B, yte, nc, lam=0.25, ep=HEAD_EPOCHS, lr=5e-3, eps=0.15):
    A = torch.tensor(A, dtype=torch.float32); B = torch.tensor(B, dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = GatedResidual(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-4)
    curve = []
    for e in range(ep):
        net.train(); opt.zero_grad()
        loss = Fn.cross_entropy(net(A), yt) + lam * net.gates.abs().sum()
        loss.backward(); opt.step()
        if e % REC_EVERY == 0 or e == ep - 1:
            net.eval()
            with torch.no_grad():
                curve.append((e, (net(B).argmax(1) == ye).float().mean().item()))
    net.eval()
    with torch.no_grad():
        acc = (net(B).argmax(1) == ye).float().mean().item()
        gates = net.gates.abs().tolist()
    eff = net.lin_params() + sum(net.block_params() for g in gates if g > eps)
    return acc, eff, curve


# ---------------- front-ends ----------------
def fourier_mp(X):
    Xf = np.fft.rfft(X, axis=1); m = np.abs(Xf); p = np.angle(Xf)
    return np.concatenate([m, m * np.cos(p), m * np.sin(p)], 1)

DICT = {"fourier": fourier_mp, "dwt": lambda X: W.dwt_features(X, "db4"),
        "cwt": lambda X: W.cwt_mag(X), "scatter": lambda X: W.scattering1d(X)}


def fscore(F, y, nc):
    n, D = F.shape; grand = F.mean(0); ssb = np.zeros(D); ssw = np.zeros(D)
    for c in range(nc):
        Fc = F[y == c]; ssb += len(Fc) * (Fc.mean(0) - grand) ** 2; ssw += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return (ssb / (nc - 1)) / (ssw / (n - nc) + 1e-9)

def _std_select(P1, ytr, P2, nc):
    idx = np.argsort(fscore(P1, ytr, nc))[::-1][:min(K, P1.shape[1])]
    A, B = P1[:, idx], P2[:, idx]; mu, sd = A.mean(0), A.std(0) + 1e-9
    return (A - mu) / sd, (B - mu) / sd


def pooled_feats(Xtr, ytr, Xte, yte, nc):
    P1 = np.concatenate([f(Xtr) for f in DICT.values()], 1)
    P2 = np.concatenate([f(Xte) for f in DICT.values()], 1)
    A, B = _std_select(P1, ytr, P2, nc)
    return A, B, 0                      # transform trainable params = 0 (fixed)


def learned_feats(Xtr, ytr, Xte, yte, nc, bandwidth, seed):
    N = Xtr.shape[1]
    torch.manual_seed(seed)
    m = UnitaryClassifier(N, nc, seed=seed, bandwidth=bandwidth)
    train_uni(m, Xtr, ytr, Xte, yte, epochs=200, sparse=4.0)   # Stage 1: find the transform
    with torch.no_grad():
        Z1 = m.features(torch.tensor(Xtr)).numpy(); Z2 = m.features(torch.tensor(Xte)).numpy()
    A, B = _std_select(Z1, ytr, Z2, nc)
    tparams = m.U.n_free() if isinstance(m.U, StructuredUnitary) else N * N
    return A, B, tparams


TASKS = {"chirp_rate": chirp_tasks.chirp_rate,
         "narrowband_tones": classic_tasks.narrowband_tones,
         "hidden_basis": classic_tasks.hidden_basis}

results = {t: {"S1": {"acc": [], "tot": []}, "S2": {"acc": [], "tot": []},
              "S2c": {"acc": [], "tot": []}} for t in TASKS}
curves = {t: {} for t in TASKS}

for tname, tfn in TASKS.items():
    for s in SEEDS:
        Xtr, ytr, Xte, yte, nc = tfn(seed=s)
        # S1 pooled dictionary
        A, B, tp = pooled_feats(Xtr, ytr, Xte, yte, nc)
        acc, eff, cur = fit_head(A, ytr, B, yte, nc)
        results[tname]["S1"]["acc"].append(acc); results[tname]["S1"]["tot"].append(tp + eff)
        # S2 learned (full unitary, no predefined transform)
        A, B, tp = learned_feats(Xtr, ytr, Xte, yte, nc, None, s)
        acc2, eff2, cur2 = fit_head(A, ytr, B, yte, nc)
        results[tname]["S2"]["acc"].append(acc2); results[tname]["S2"]["tot"].append(tp + eff2)
        # S2c learned compact (structured band=8)
        A, B, tp = learned_feats(Xtr, ytr, Xte, yte, nc, 8, s)
        acc3, eff3, _ = fit_head(A, ytr, B, yte, nc)
        results[tname]["S2c"]["acc"].append(acc3); results[tname]["S2c"]["tot"].append(tp + eff3)
        if s == 0:
            curves[tname]["S1"] = cur; curves[tname]["S2"] = cur2

# ---------------- report ----------------
print(f"Superstructure comparison — K={K}, {len(SEEDS)} seeds, shared GatedResidual head\n")
print(f"  {'task':17s} {'S1 acc':>12s} {'S2 acc':>12s} {'S2c acc':>12s} | {'S1 par':>7s} {'S2 par':>8s} {'S2c par':>8s}")
for t in TASKS:
    r = results[t]
    def ms(k): v = np.array(r[k]["acc"]); return f"{v.mean():.3f}+/-{v.std():.3f}"
    p = lambda k: int(np.median(r[k]["tot"]))
    print(f"  {t:17s} {ms('S1'):>12s} {ms('S2'):>12s} {ms('S2c'):>12s} | "
          f"{p('S1'):>7d} {p('S2'):>8d} {p('S2c'):>8d}")
json.dump({t: {k: {"acc_mean": float(np.mean(results[t][k]['acc'])),
                   "acc_std": float(np.std(results[t][k]['acc'])),
                   "params": int(np.median(results[t][k]['tot']))} for k in results[t]}
           for t in TASKS}, open(os.path.join(HERE, "superstructure_results.json"), "w"), indent=1)

# ---------------- charts (ENGLISH) ----------------
tasks = list(TASKS); x = np.arange(len(tasks)); w = 0.26
labels = {"S1": "S1 Pooled dictionary", "S2": "S2 Learned (full)", "S2c": "S2 Learned (compact)"}
colors = {"S1": "#555555", "S2": "#d62728", "S2c": "#ff9896"}

# accuracy
fig, ax = plt.subplots(figsize=(7.5, 4.2))
for k, key in enumerate(["S1", "S2", "S2c"]):
    means = [np.mean(results[t][key]["acc"]) for t in tasks]
    stds = [np.std(results[t][key]["acc"]) for t in tasks]
    ax.bar(x + (k - 1) * w, means, w, yerr=stds, capsize=4, color=colors[key], label=labels[key])
ax.set_xticks(x); ax.set_xticklabels(tasks); ax.set_ylabel("Test accuracy"); ax.set_ylim(0, 1.05)
ax.set_title(f"Accuracy: Pooled Dictionary vs Learned Transform (mean +/- std, {len(SEEDS)} seeds)")
ax.legend(fontsize=8); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
plt.savefig(os.path.join(HERE, "superstructure_accuracy.png"), dpi=130)

# total parameters
fig, ax = plt.subplots(figsize=(7.5, 4.2))
for k, key in enumerate(["S1", "S2", "S2c"]):
    vals = [np.median(results[t][key]["tot"]) for t in tasks]
    ax.bar(x + (k - 1) * w, vals, w, color=colors[key], label=labels[key])
ax.set_xticks(x); ax.set_xticklabels(tasks); ax.set_ylabel("Total trainable parameters (log)")
ax.set_yscale("log"); ax.set_title("Total parameters: transform + head")
ax.legend(fontsize=8); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
plt.savefig(os.path.join(HERE, "superstructure_params.png"), dpi=130)

# convergence
fig, axs = plt.subplots(1, len(tasks), figsize=(13, 3.6), sharey=True)
for i, t in enumerate(tasks):
    for key, cur in curves[t].items():
        e = [c[0] for c in cur]; a = [c[1] for c in cur]
        axs[i].plot(e, a, label=labels[key], color=colors[key], lw=1.6)
    axs[i].set_title(t); axs[i].set_xlabel("epoch"); axs[i].grid(alpha=0.3)
axs[0].set_ylabel("Test accuracy"); axs[0].legend(fontsize=8)
fig.suptitle("Convergence of the shared head (test accuracy vs epoch)")
plt.tight_layout(); plt.savefig(os.path.join(HERE, "superstructure_convergence.png"), dpi=130)
print("\nsaved: superstructure_accuracy.png, superstructure_params.png, superstructure_convergence.png")
