# Why isn't the learned transform ≥ the pooled dictionary? (diagnostic)

Same head + K=16. Per task: S1 union (full dictionary), best single fixed transform alone, S2 with a frozen sparsity Stage-1, and S2 trained end-to-end with the classification loss. 2 seeds.

| task | S1 union | best single fixed | S2 sparse | S2 task (e2e) |
|---|---|---|---|---|
| 1D global (Fourier) | 1.000 | 1.000 (Fourier) | 0.998 | 0.997 |
| 1D localized | 0.998 | 0.999 (Fourier) | 0.801 | **0.909** |
| video (motion) | 1.000 | 1.000 (Fourier) | 0.711 | **0.819** |
| hidden basis (rotated) | 0.675 | 0.795 (DWT) | **1.000** | 0.985 |

## What it means

The premise is right — the unitary group *contains* Fourier/wavelet/chirplet, so a learned transform *should* be able to match the best fixed one. The gap is not about expressivity; it is about three separable, measurable things:

1. **Objective (biggest, fixable lever).** Our S2 used a two-stage protocol: learn the transform for *sparsity*, freeze it, then train the head. Sparsity ≠ discrimination. Training the transform **end-to-end with the classification loss** recovers a large part of the gap: 1D-localized 0.80 → 0.91, video 0.71 → 0.82. So much of the earlier deficit was the protocol, not the idea. (Note: on hidden_basis the sparsity objective is actually *better*, 1.00 vs 0.985 — the best objective is task-dependent.)

2. **Optimization ≠ expressivity (the core reason it still lags).** Even trained for the task, the learned transform does not fully reach a *fixed* Fourier: on 1D-localized a fixed Fourier scores 0.999 while the task-trained learned unitary reaches 0.909 — same pipeline, same available expressivity, different result. The Fourier basis is a single point in a huge non-convex unitary manifold; gradient descent from a random start, with only a few hundred samples, lands in a good-but-suboptimal local solution. A fixed transform is a **zero-variance, globally-optimal-by-construction** estimator for its matched regime; a learned one is a **high-variance** estimator that must *find* the basis and usually stops short.

3. **One basis vs a union of bases (structural).** The dictionary is Fourier ∪ DWT ∪ CWT with magnitude *and* phase — an overcomplete frame of hundreds of features from which the selector cherry-picks 16. A single learned unitary is *one* orthonormal basis (N coefficients); it cannot be Fourier *and* wavelet *and* phase simultaneously. (On these particular tasks the best single ≈ the union, so here optimization dominates over this factor — but in general the union is a real structural edge.)

There is also an estimation/data cost (a huge learned unitary generalizes worse than a zero-parameter fixed transform, worst on high-dim video where PCA-128 also drops information).

## The resolution, and the fix

Flexibility does not come free: it converts a *fixed, optimal* transform into an *estimated, suboptimal* one. The learned transform only wins when no fixed transform is close (hidden_basis), where "suboptimal-but-flexible" beats "optimal-for-the-wrong-basis". Where a matched transform exists, the fixed one is both better and cheaper.

**The clean fix suggested by this:** warm-start the learned transform *from* the best fixed transform (initialize U = DFT / wavelet) and then train end-to-end. It then starts at the fixed transform's accuracy and can only improve, keeping the flexibility to move toward a better basis when one exists — guaranteeing learned ≥ fixed. This is the natural next experiment, and it would turn the learned transform from a *replacement* into a *strict generalization* of the dictionary.
