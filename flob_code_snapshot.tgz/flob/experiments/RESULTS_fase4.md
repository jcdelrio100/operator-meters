# Fase 4 — Transformadas aprendibles (FrFT-α y chirplet)

Capas diferenciables en torch: `part1_frft/learnable_frft.py` (α aprendible; V y órdenes HG fijos, solo α entrena) y `part2_chirplet/learnable_chirplet.py` (átomos `(t_c, σ, f, c)` aprendibles). Entrenadas end-to-end (Adam, full-batch). Comparación con recuento honesto de parámetros en `compare_fixed_vs_learnable.py`.

Protocolo justo: la FrFT fija (7 órdenes) y la aprendible (3 α) usan **la misma lectura compacta** (F-ANOVA top-K=8 + lineal), así el único cambio es la elección de α. La chirplet aprendible se evalúa como modelo compacto end-to-end (10 átomos + cabeza).

## Resultados

| tarea | FrFT fija 7ord | FrFT apr. 3α (e2e) | chirplet fija | chirplet apr. (10) |
|---|---|---|---|---|
| **chirp_rate** (4 cl) | 0.877 | **0.940** (e2e 1.000) | 0.997 | **1.000** (104 par) |
| up_vs_down_hard (2 cl) | 0.844 | 0.828 (e2e 0.950) | 0.917 | 0.900 (82 par) |
| up_vs_down_chirp (2 cl) | 1.000 | 1.000 | 1.000 | 1.000 |

α aprendidos (chirp_rate): (0.78, 1.03, 1.14) — se despliegan alrededor de la DFT (α=1) para cubrir las distintas pendientes. Tasas c aprendidas (chirplet, chirp_rate): reparto en ambos signos de −10 a +11.

## Lectura (H3, H4, H5)

1. **La FrFT aprendible cierra la brecha del banco fijo (H3).** En chirp_rate, 3 órdenes aprendidos baten a 7 fijos con la misma lectura compacta (0.940 vs 0.877), y el modelo end-to-end alcanza el techo (1.000 vs 0.877). Justo la tarea multiclase donde la FrFT de órdenes fijos se estancaba: aprender α la resuelve.
2. **La chirplet aprendible es la más compacta y precisa:** 1.000 en chirp_rate con ~100 parámetros totales (10 átomos + cabeza), sin banco de 140.
3. **La tarea difícil discrimina métodos (H4/diseño):** up_vs_down_hard ya no la resuelve nadie al 100% (0.83–0.95); la mejor es la FrFT aprendible end-to-end (0.950). up/down fácil sigue trivial (1.000 para todo).
4. **Matiz honesto:** la lectura compacta de los α aprendidos no siempre bate a la fija (en up_vs_down_hard 0.828 vs 0.844) porque descarta la cabeza entrenada; la ventaja clara de aprender está en el modelo end-to-end. Es decir: aprender α ayuda sobre todo cuando la cabeza también se entrena junta (coste ≈ la propia cabeza, H5).

## Siguiente
- Barrido de semillas (2–3) y barras de error para las tablas.
- Figuras apples-to-apples (precisión vs parámetros reales) para el paper, con las cuatro variantes.
- Opcional: cabeza auto-organizada (`GatedResidual`) sobre las transformadas aprendibles.
