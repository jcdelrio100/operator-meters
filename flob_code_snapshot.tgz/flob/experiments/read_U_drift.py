"""
Reading U, done honestly: on the 1-D FOURIER task (where the DFT is optimal), show the
top discriminative atoms of U (a) right after warm-start = exact DFT, and (b) after
task-training. Classification alone is under-constrained: many unitaries classify equally,
so U drifts to a data-adapted, NON-canonical basis even though a clean optimal one exists.
"""
import sys, os, numpy as np, torch
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier
from warmstart import dft_matrix, warm_start_flat, train_ws
HERE = os.path.dirname(os.path.abspath(__file__))

def fscore(F, y, nc):
    mu = F.mean(0); num = np.zeros(F.shape[1]); den = np.zeros(F.shape[1]) + 1e-9
    for c in range(nc):
        Fc = F[y == c]; num += len(Fc) * (Fc.mean(0) - mu) ** 2; den += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return num / den
def nov(a, U0):
    a = a / (np.linalg.norm(a) + 1e-12); return 1 - np.abs(U0.conj() @ a).max()

d = 128; U0 = dft_matrix(d)
Xtr, ytr, Xte, yte, nc, _ = MM.load("1D global (Fourier)", 0); F1 = Xtr.astype(np.float64)
m = UnitaryClassifier(d, nc, seed=0); warm_start_flat(m.U, U0)
Ub = m.U.matrix().detach().numpy()
with torch.no_grad(): cb = m.features(torch.tensor(F1)).numpy()
tb = np.argsort(fscore(cb, ytr, nc))[::-1][:3]
train_ws(m, F1, ytr, Xte.astype(np.float64), yte, epochs=150)
Ua = m.U.matrix().detach().numpy()
with torch.no_grad(): ca = m.features(torch.tensor(F1)).numpy()
ta = np.argsort(fscore(ca, ytr, nc))[::-1][:3]
dd = np.linalg.norm(Ua - U0) / np.linalg.norm(U0)

fig, axes = plt.subplots(2, 3, figsize=(11, 5.2))
for c in range(3):
    ax = axes[0, c]; a = Ub[tb[c]]
    ax.plot(a.real, color="#1f77b4", lw=1.3); ax.plot(a.imag, color="#d62728", lw=0.9, alpha=0.6)
    ax.set_title(f"atom #{tb[c]}   novelty={nov(a,U0):.2f}", fontsize=9); ax.set_xticks([]); ax.set_yticks([])
    ax = axes[1, c]; a = Ua[ta[c]]
    ax.plot(a.real, color="#1f77b4", lw=1.3); ax.plot(a.imag, color="#d62728", lw=0.9, alpha=0.6)
    ax.set_title(f"atom #{ta[c]}   novelty={nov(a,U0):.2f}", fontsize=9); ax.set_xticks([]); ax.set_yticks([])
axes[0, 0].set_ylabel("(a) warm-start only\n= exact DFT", fontsize=10)
axes[1, 0].set_ylabel("(b) after task-training\n(classification)", fontsize=10)
from matplotlib.lines import Line2D
fig.legend([Line2D([0], [0], color="#1f77b4", lw=1.5), Line2D([0], [0], color="#d62728", lw=1.5)],
           ["Real part of atom", "Imaginary part of atom"], loc="lower center", ncol=2, fontsize=10, frameon=True)
fig.suptitle(f"Reading U on the Fourier task: clean DFT atoms (top) drift to a data-adapted, non-canonical "
             f"basis (bottom)\nafter task-training, ||U-U0||/||U0|| = {dd:.2f}  (novelty 0 = pure Fourier mode)",
             fontsize=11)
plt.tight_layout(rect=[0, 0.05, 1, 0.93]); plt.savefig(os.path.join(HERE, "read_U_drift.png"), dpi=130)
print(f"saved read_U_drift.png  drift={dd:.2f}")
