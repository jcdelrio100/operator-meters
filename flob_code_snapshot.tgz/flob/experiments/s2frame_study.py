"""
Exp A: is S2's failure on texture a REPRESENTATION limit (single separable basis) rather
than expressivity? Replace the separable unitary by a LEARNED OVERCOMPLETE, NON-SEPARABLE
directional frame (a conv filter bank) and re-run the same protocol.
  S1          : pooled dictionary
  S2 (unitary): separable learned unitary (current), same as paper
  S2frame     : learned conv bank -> |.| -> pool -> F-select K -> head  (overcomplete, non-separable)
  S3+ (frame) : coupling S1 + S2frame
2-D tasks (texture, real digits, video), 5 seeds. Reports accuracy, gate, and param counts.
"""
import sys, os, json, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3

SEEDS = 5
TASKS = ["texture (28x28)", "image digits (real)", "video (motion)"]
JS = os.path.join(HERE, "s2frame.json")
M, K, Gp = 40, 16, 3

class ConvFrame(nn.Module):
    def __init__(self, in_ch, C, M=M, k=7, G=Gp, h=32):
        super().__init__(); self.G = G
        self.conv = nn.Conv2d(in_ch, M, k, padding=k // 2, bias=False)   # non-separable, overcomplete
        D = M * G * G
        self.lin = nn.Linear(D, C); self.nl = nn.Sequential(nn.Linear(D, h), nn.ReLU(), nn.Linear(h, C))
        self.g = nn.Parameter(torch.tensor(1.0))
    def features(self, x):
        z = self.conv(x).abs(); z = Fn.adaptive_avg_pool2d(z, self.G).flatten(1); return z
    def forward(self, x): z = self.features(x); return self.lin(z) + self.g * self.nl(z)
    def n_conv(self): return sum(p.numel() for p in self.conv.parameters())

def to4d(name, X):
    X = np.asarray(X, dtype=np.float32)
    if name == "video (motion)": return torch.tensor(X)                 # (N,T,H,W): T channels
    return torch.tensor(X)[:, None]                                      # (N,1,H,W)

def zc(X):
    m = X.mean((0,), keepdim=True); s = X.std((0,), keepdim=True) + 1e-6; return (X - m) / s

def s2frame(name, Xtr, ytr, Xte, yte, nc, seed, ep=200):
    torch.manual_seed(seed)
    A = zc(to4d(name, Xtr)); B = zc(to4d(name, Xte)); yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = ConvFrame(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), 3e-3, weight_decay=1e-4)
    for _ in range(ep):
        net.train(); opt.zero_grad(); Fn.cross_entropy(net(A), yt).backward(); opt.step()
    net.eval()
    with torch.no_grad():
        Z1 = net.features(A).numpy(); Z2 = net.features(B).numpy()
    Asel, Bsel = MM.std_select(Z1, ytr, Z2, nc)                          # F-select K, z-score
    return Asel, Bsel, net.n_conv()

class S3plus(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); D = Kd + Kl
        self.lin = nn.Linear(D, C); self.nl = nn.Sequential(nn.Linear(D, h), nn.ReLU(), nn.Linear(h, C))
        self.g_nl = nn.Parameter(torch.tensor(1.0)); self.g_s2 = nn.Parameter(torch.tensor(1.0))
    def forward(self, xd, xl): x = torch.cat([xd, self.g_s2 * xl], 1); return self.lin(x) + self.g_nl * self.nl(x)

def fit_s3plus(Ad, Al, ytr, Bd, Bl, yte, nc, ep=350):
    Ad, Al, Bd, Bl = [torch.tensor(z, dtype=torch.float32) for z in (Ad, Al, Bd, Bl)]
    yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = S3plus(Ad.shape[1], Al.shape[1], nc); opt = torch.optim.Adam(net.parameters(), 5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(Ad, Al), yt) + 0.25 * (net.g_nl.abs() + net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad(): return (net(Bd, Bl).argmax(1) == ye).float().mean().item(), float(net.g_s2.abs())

def run():
    out = json.load(open(JS)) if os.path.exists(JS) else {}
    print(f"{SEEDS} seeds")
    for name in TASKS:
        if name in out: print("skip", name); continue
        R = {k: [] for k in ("S1", "S2uni", "S2frame", "S3frame", "gframe", "pFrame", "pUni")}
        for s in range(SEEDS):
            Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
            Ad, Bd, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps); R["S1"].append(MM.fit_head(Ad, ytr, Bd, yte, nc)[0])
            Au, Bu = S3.learned_branch(name, Xtr, ytr, Xte, yte, nc, s); R["S2uni"].append(MM.fit_head(Au, ytr, Bu, yte, nc)[0])
            Af, Bf, pconv = s2frame(name, Xtr, ytr, Xte, yte, nc, s); R["S2frame"].append(MM.fit_head(Af, ytr, Bf, yte, nc)[0])
            a, g = fit_s3plus(Ad, Af, ytr, Bd, Bf, yte, nc); R["S3frame"].append(a); R["gframe"].append(g)
            R["pFrame"].append(pconv)
        out[name] = R; json.dump(out, open(JS, "w"), indent=1)
        f = lambda k: f"{np.mean(R[k]):.3f}"
        print(f"  {name:20s} S1={f('S1')} S2uni={f('S2uni')} S2frame={f('S2frame')} "
              f"S3+frame={f('S3frame')}(g{np.mean(R['gframe']):.2f}) convP={int(np.mean(R['pFrame']))}")
    return out

def plot(out):
    names = [t for t in TASKS if t in out]; x = np.arange(len(names)); w = 0.2
    m = lambda t, k: float(np.mean(out[t][k])); sd = lambda t, k: float(np.std(out[t][k]))
    fig, ax = plt.subplots(figsize=(10.5, 5))
    series = [("S1", "#555555", "S1 dictionary"), ("S2uni", "#d62728", "S2 separable unitary"),
              ("S2frame", "#ff7f0e", "S2frame: learned non-sep. overcomplete frame"),
              ("S3frame", "#2ca02c", "S3+ (S1 + S2frame)")]
    off = {k: (i - (len(series) - 1) / 2) * w for i, (k, _, _) in enumerate(series)}
    for k, col, lab in series:
        ax.bar(x + off[k], [m(t, k) for t in names], w, yerr=[sd(t, k) for t in names], capsize=2, color=col, label=lab)
    for i, t in enumerate(names):
        ax.annotate(f"g={m(t,'gframe'):.2f}", (x[i] + off['S3frame'], m(t, "S3frame") + sd(t, "S3frame") + 0.004), fontsize=7, ha="center", color="#2ca02c")
    ax.set_xticks(x); ax.set_xticklabels(names, fontsize=9); ax.set_ylim(0.5, 1.02); ax.axhline(0.5, color="k", lw=0.6)
    ax.set_ylabel("Test accuracy"); ax.set_title(f"Making S2 overcomplete + non-separable recovers the directional win ({SEEDS} seeds; y from 0.5)")
    ax.legend(fontsize=8, loc="lower left"); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(HERE, "s2frame.png"), dpi=130); print("saved s2frame.png")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "plot": plot(json.load(open(JS)))
    else: plot(run())
