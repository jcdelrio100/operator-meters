"""
Does a STRUCTURE-AWARE learned transform (separable/multilinear unitary) recover the
modalities where the flat learned unitary lost, and shift the break-even?

Compares three front-ends into the SAME article-1 GatedResidual head, K=16 after
F-ANOVA in all three:
  S1  = pooled dictionary (fixed, modality-appropriate)
  S2  = learned FLAT unitary (single global unitary on the flattened/PCA-reduced input)
  S2s = learned SEPARABLE unitary (one unitary per tensor axis)  <-- new

Usage: python structured_breakeven.py run <task1;task2;...>   /   plot
"""
import sys, os, json, numpy as np, torch
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM          # generators, load, head, s1/s2 feats (guarded)
from learned_transform import train as train_uni
from structured_learned import MultilinearClassifier

JSON = os.path.join(HERE, "structured_results.json")
SEEDS, STAGE1_EP = MM.SEEDS, MM.STAGE1_EP


def s2s_feats(Xtr, ytr, Xte, yte, nc, seed):
    shape = Xtr.shape[1:]
    mu = Xtr.mean(0, keepdims=True); sd = Xtr.std(0, keepdims=True) + 1e-9
    F1 = ((Xtr - mu) / sd).astype(np.float64); F2 = ((Xte - mu) / sd).astype(np.float64)
    torch.manual_seed(seed)
    m = MultilinearClassifier(shape, nc, seed=seed)
    train_uni(m, F1, ytr, F2, yte, epochs=STAGE1_EP, sparse=4.0)
    with torch.no_grad():
        Z1 = m.features(torch.tensor(F1)).numpy(); Z2 = m.features(torch.tensor(F2)).numpy()
    A, B = MM.std_select(Z1, ytr, Z2, nc)
    return A, B, m.U.n_free()


def run(tasks):
    out = json.load(open(JSON)) if os.path.exists(JSON) else {}
    for name in tasks:
        r = {"S1": [], "S2": [], "S2s": [], "S1p": [], "S2p": [], "S2sp": []}
        for s in range(SEEDS):
            Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
            A, B, tp = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
            a1, e1, _ = MM.fit_head(A, ytr, B, yte, nc); r["S1"].append(a1); r["S1p"].append(tp + e1)
            A, B, tp, _ = MM.s2_feats(Xtr, ytr, Xte, yte, nc, s)
            a2, e2, _ = MM.fit_head(A, ytr, B, yte, nc); r["S2"].append(a2); r["S2p"].append(tp + e2)
            A, B, tp = s2s_feats(Xtr, ytr, Xte, yte, nc, s)
            a3, e3, _ = MM.fit_head(A, ytr, B, yte, nc); r["S2s"].append(a3); r["S2sp"].append(tp + e3)
        out[name] = r
        print(f"{name:26s} S1={np.mean(r['S1']):.3f}  S2flat={np.mean(r['S2']):.3f}  "
              f"S2sep={np.mean(r['S2s']):.3f}  | par S2sep={int(np.median(r['S2sp']))}")
        json.dump(out, open(JSON, "w"), indent=1)


def plot():
    out = json.load(open(JSON)); names = list(out)
    names.sort(key=lambda t: np.mean(out[t]["S2s"]) - np.mean(out[t]["S1"]))
    x = np.arange(len(names)); w = 0.27
    def mv(k): return [np.mean(out[t][k]) for t in names]
    def sv(k): return [np.std(out[t][k]) for t in names]
    fig, ax = plt.subplots(figsize=(11.5, 4.8))
    ax.bar(x - w, mv("S1"), w, yerr=sv("S1"), capsize=3, color="#555555", label="S1 Pooled dictionary")
    ax.bar(x, mv("S2"), w, yerr=sv("S2"), capsize=3, color="#d62728", label="S2 Learned (flat)")
    ax.bar(x + w, mv("S2s"), w, yerr=sv("S2s"), capsize=3, color="#2ca02c", label="S2 Learned (separable)")
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("Test accuracy"); ax.set_ylim(0, 1.05)
    ax.set_title("Structure-aware learned transform vs pooled dictionary (K=16, mean +/- std)")
    ax.legend(fontsize=8); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(HERE, "structured_breakeven.png"), dpi=130)
    print("saved structured_breakeven.png\n")
    print(f"  {'task':26s} {'S1':>6s} {'S2flat':>7s} {'S2sep':>7s} {'d(S2sep-S1)':>12s}")
    for t in names:
        print(f"  {t:26s} {np.mean(out[t]['S1']):>6.3f} {np.mean(out[t]['S2']):>7.3f} "
              f"{np.mean(out[t]['S2s']):>7.3f} {np.mean(out[t]['S2s'])-np.mean(out[t]['S1']):>+12.3f}")


if __name__ == "__main__":
    if sys.argv[1] == "run": run(sys.argv[2].split(";"))
    elif sys.argv[1] == "plot": plot()
