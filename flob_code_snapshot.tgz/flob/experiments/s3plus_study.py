"""
S3+ : joint nonlinear head over [x_dict ; g_s2 * x_learn] with a PROTECTIVE per-branch
gate g_s2 (L1-penalized) on the learned block. Aim: capture the complementary accuracy
the additive scalar gate leaves on the table (e.g. texture) while keeping protection on
tasks where the learned branch is useless (e.g. text).

Compares, 5 seeds: S1, S2, max, oracle-union (ceiling of a per-sample selector),
S3 (current additive gate), concat (joint head, NO gate), S3+ (joint head + protective gate).
Usage: python s3plus_study.py run "t1;t2"   /   plot
"""
import sys, os, json, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3
JSON = os.path.join(HERE, "s3plus_results.json"); SEEDS = 5
TASKS = ["1D global (Fourier)", "1D localized (wavelet)", "video (motion)", "texture (28x28)",
         "text (topic)", "XOR in hidden basis", "hidden basis (rotated)"]

class GR(nn.Module):
    def __init__(self, K, C, h=32):
        super().__init__(); self.lin = nn.Linear(K, C)
        self.nl = nn.Sequential(nn.Linear(K, h), nn.ReLU(), nn.Linear(h, C)); self.g = nn.Parameter(torch.tensor(1.0))
    def forward(self, x): return self.lin(x) + self.g*self.nl(x)

class S3plus(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); D = Kd + Kl
        self.lin = nn.Linear(D, C); self.nl = nn.Sequential(nn.Linear(D, h), nn.ReLU(), nn.Linear(h, C))
        self.g_nl = nn.Parameter(torch.tensor(1.0)); self.g_s2 = nn.Parameter(torch.tensor(1.0)); self.Kd = Kd
    def forward(self, xd, xl):
        x = torch.cat([xd, self.g_s2 * xl], 1)              # protective gate on the learned block
        return self.lin(x) + self.g_nl * self.nl(x)

def fit_preds(A, ytr, B, yte, nc, ep=350):
    A = torch.tensor(A, dtype=torch.float32); B = torch.tensor(B, dtype=torch.float32)
    yt = torch.tensor(ytr); net = GR(A.shape[1], nc); opt = torch.optim.Adam(net.parameters(), 5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(A), yt)+0.25*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return net(B).argmax(1).numpy()

def fit_concat(Ad, Al, ytr, Bd, Bl, yte, nc, ep=350):
    A = torch.tensor(np.concatenate([Ad, Al], 1), dtype=torch.float32); B = torch.tensor(np.concatenate([Bd, Bl], 1), dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte); net = GR(A.shape[1], nc); opt = torch.optim.Adam(net.parameters(), 5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); Fn.cross_entropy(net(A), yt).backward(); opt.step()
    with torch.no_grad(): return (net(B).argmax(1) == ye).float().mean().item()

def fit_s3plus(Ad, Al, ytr, Bd, Bl, yte, nc, lam=0.25, ep=350):
    Ad = torch.tensor(Ad, dtype=torch.float32); Al = torch.tensor(Al, dtype=torch.float32)
    Bd = torch.tensor(Bd, dtype=torch.float32); Bl = torch.tensor(Bl, dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte); net = S3plus(Ad.shape[1], Al.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), 5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(Ad, Al), yt)+lam*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad():
        return (net(Bd, Bl).argmax(1) == ye).float().mean().item(), float(net.g_s2.abs())

def run(tasks):
    out = json.load(open(JSON)) if os.path.exists(JSON) else {}
    print(f"  {'task':22s} {'S1':>6s} {'S2':>6s} {'oracleU':>8s} {'S3':>6s} {'concat':>7s} {'S3+':>6s} {'g+':>5s}")
    for name in tasks:
        r = {k: [] for k in ("s1", "s2", "orU", "s3", "concat", "s3plus", "gplus")}
        for s in range(SEEDS):
            Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
            Ad, Bd, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
            Al, Bl = S3.learned_branch(name, Xtr, ytr, Xte, yte, nc, s)
            p1 = fit_preds(Ad, ytr, Bd, yte, nc); p2 = fit_preds(Al, ytr, Bl, yte, nc)
            c1 = (p1 == yte); c2 = (p2 == yte)
            r["s1"].append(float(c1.mean())); r["s2"].append(float(c2.mean())); r["orU"].append(float((c1 | c2).mean()))
            r["s3"].append(S3.fit_s3(Ad, Al, ytr, Bd, Bl, yte, nc)[0])
            r["concat"].append(fit_concat(Ad, Al, ytr, Bd, Bl, yte, nc))
            acc, g = fit_s3plus(Ad, Al, ytr, Bd, Bl, yte, nc); r["s3plus"].append(acc); r["gplus"].append(g)
        out[name] = r; m = lambda k: np.mean(r[k])
        print(f"  {name:22s} {m('s1'):>6.3f} {m('s2'):>6.3f} {m('orU'):>8.3f} {m('s3'):>6.3f} {m('concat'):>7.3f} {m('s3plus'):>6.3f} {m('gplus'):>5.2f}")
        json.dump(out, open(JSON, "w"), indent=1)

def plot():
    out = json.load(open(JSON)); names = [t for t in TASKS if t in out]
    x = np.arange(len(names)); w = 0.2
    m = lambda t, k: float(np.mean(out[t][k])); sd = lambda t, k: float(np.std(out[t][k]))
    fig, ax = plt.subplots(figsize=(12, 4.8))
    ax.bar(x-1.5*w, [m(t,"s1") for t in names], w, yerr=[sd(t,"s1") for t in names], capsize=2, color="#555555", label="S1 dictionary")
    ax.bar(x-0.5*w, [m(t,"s2") for t in names], w, yerr=[sd(t,"s2") for t in names], capsize=2, color="#d62728", label="S2 learned")
    ax.bar(x+0.5*w, [m(t,"s3") for t in names], w, yerr=[sd(t,"s3") for t in names], capsize=2, color="#1f77b4", label="S3 (additive gate)")
    ax.bar(x+1.5*w, [m(t,"s3plus") for t in names], w, yerr=[sd(t,"s3plus") for t in names], capsize=2, color="#2ca02c", label="S3+ (joint head + protective gate)")
    ax.plot(x, [m(t,"orU") for t in names], "k_", ms=22, mew=2, label="oracle union (ceiling)")
    for i, t in enumerate(names):
        ax.annotate(f"g={m(t,'gplus'):.2f}", (x[i]+1.5*w, m(t,"s3plus")+sd(t,"s3plus")), fontsize=6.5, ha="center", va="bottom", color="#2ca02c")
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=22, ha="right", fontsize=8); ax.set_ylim(0.4, 1.04)
    ax.set_ylabel("Test accuracy"); ax.set_title("S3+ vs S3: capturing complementary accuracy (5 seeds; black = oracle-union ceiling)")
    ax.legend(fontsize=8, ncol=2); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(HERE, "s3plus.png"), dpi=130); print("saved s3plus.png")

if __name__ == "__main__":
    if sys.argv[1] == "run": run(sys.argv[2].split(";"))
    elif sys.argv[1] == "plot": plot()
