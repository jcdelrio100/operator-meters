"""
Can we close the gap to the oracle union? Train the learned transform to be
COMPLEMENTARY to S1 (boosting): weight Stage-A training toward the samples S1 gets
wrong, so the learned branch captures what the dictionary misses. Compare the oracle
union and the S3+ combination for a STANDARD learned branch vs a RESIDUAL one.
Tasks with headroom: texture (separable) and hidden basis (flat). 3 seeds.
"""
import sys, os, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3
from learned_transform import UnitaryClassifier
from structured_learned import MultilinearClassifier
from warmstart import dft_matrix, warm_start_flat, warm_start_separable
SEEDS = 3; FLAT = {"hidden basis (rotated)"}

class GR(nn.Module):
    def __init__(self, K, C, h=32):
        super().__init__(); self.lin=nn.Linear(K,C); self.nl=nn.Sequential(nn.Linear(K,h),nn.ReLU(),nn.Linear(h,C)); self.g=nn.Parameter(torch.tensor(1.0))
    def forward(self,x): return self.lin(x)+self.g*self.nl(x)
class S3plus(nn.Module):
    def __init__(self,Kd,Kl,C,h=32):
        super().__init__(); D=Kd+Kl; self.lin=nn.Linear(D,C); self.nl=nn.Sequential(nn.Linear(D,h),nn.ReLU(),nn.Linear(h,C))
        self.g_nl=nn.Parameter(torch.tensor(1.0)); self.g_s2=nn.Parameter(torch.tensor(1.0))
    def forward(self,xd,xl): x=torch.cat([xd,self.g_s2*xl],1); return self.lin(x)+self.g_nl*self.nl(x)

def head_fit(A,ytr,B,nc,ep=350):
    A=torch.tensor(A,dtype=torch.float32); B=torch.tensor(B,dtype=torch.float32); yt=torch.tensor(ytr); net=GR(A.shape[1],nc)
    opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(A),yt)+0.25*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return net(torch.tensor(A_.numpy() if False else A)).argmax(1).numpy(), net(B).argmax(1).numpy()

def s3plus_fit(Ad,Al,ytr,Bd,Bl,yte,nc,ep=350):
    Ad=torch.tensor(Ad,dtype=torch.float32); Al=torch.tensor(Al,dtype=torch.float32); Bd=torch.tensor(Bd,dtype=torch.float32); Bl=torch.tensor(Bl,dtype=torch.float32)
    yt=torch.tensor(ytr); ye=torch.tensor(yte); net=S3plus(Ad.shape[1],Al.shape[1],nc); opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(Ad,Al),yt)+0.25*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad(): return (net(Bd,Bl).argmax(1)==ye).float().mean().item()

def train_w(model, X, y, w, epochs=150, lr=0.02, head_lr=0.01):
    Xt=torch.tensor(X); yt=torch.tensor(y).long(); wt=torch.tensor(w,dtype=torch.float64)
    tr=[p for n,p in model.named_parameters() if n.startswith("U.")]; rest=[p for n,p in model.named_parameters() if not n.startswith("U.")]
    opt=torch.optim.Adam([{"params":tr,"lr":lr,"weight_decay":0.0},{"params":rest,"lr":head_lr,"weight_decay":1e-4}])
    for _ in range(epochs):
        opt.zero_grad(); l=Fn.cross_entropy(model(Xt),yt,reduction="none"); (l*wt/wt.mean()).mean().backward(); opt.step()

def learned_feats(name, Xtr, ytr, Xte, yte, nc, seed, w):
    if name in FLAT:
        F1=Xtr.astype(np.float64); F2=Xte.astype(np.float64); m=UnitaryClassifier(F1.shape[1],nc,seed=seed); warm_start_flat(m.U,dft_matrix(F1.shape[1]))
    else:
        shape=Xtr.shape[1:]; mu=Xtr.mean(0,keepdims=True); sd=Xtr.std(0,keepdims=True)+1e-9
        F1=((Xtr-mu)/sd).astype(np.float64); F2=((Xte-mu)/sd).astype(np.float64)
        m=MultilinearClassifier(shape,nc,seed=seed); warm_start_separable(m.U,[dft_matrix(int(d)) for d in shape])
    train_w(m,F1,ytr,w,epochs=150)
    with torch.no_grad():
        Z1=m.features(torch.tensor(F1)).numpy(); Z2=m.features(torch.tensor(F2)).numpy()
    return MM.std_select(Z1,ytr,Z2,nc)

def preds(A,ytr,B,nc,ep=350):
    A=torch.tensor(A,dtype=torch.float32); B=torch.tensor(B,dtype=torch.float32); yt=torch.tensor(ytr); net=GR(A.shape[1],nc)
    opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(A),yt)+0.25*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return net(A).argmax(1).numpy(), net(B).argmax(1).numpy()

for name in ["texture (28x28)", "hidden basis (rotated)"]:
    R = {"std_or":[], "std_s3p":[], "res_or":[], "res_s3p":[]}
    for s in range(SEEDS):
        Xtr,ytr,Xte,yte,nc,reps = MM.load(name,s)
        Ad,Bd,_ = MM.s1_feats(Xtr,ytr,Xte,yte,nc,reps)
        s1tr,s1te = preds(Ad,ytr,Bd,nc); c1=(s1te==yte)
        wfocus = 1.0 + 3.0*(s1tr!=ytr).astype(float)                       # boost S1's train errors
        # standard learned branch (unweighted)
        Al,Bl = learned_feats(name,Xtr,ytr,Xte,yte,nc,s,np.ones(len(ytr)))
        _,p2 = preds(Al,ytr,Bl,nc); c2=(p2==yte)
        R["std_or"].append((c1|c2).mean()); R["std_s3p"].append(s3plus_fit(Ad,Al,ytr,Bd,Bl,yte,nc))
        # residual learned branch (weighted toward S1 errors)
        Alr,Blr = learned_feats(name,Xtr,ytr,Xte,yte,nc,s,wfocus)
        _,p2r = preds(Alr,ytr,Blr,nc); c2r=(p2r==yte)
        R["res_or"].append((c1|c2r).mean()); R["res_s3p"].append(s3plus_fit(Ad,Alr,ytr,Bd,Blr,yte,nc))
    m=lambda k: np.mean(R[k])
    print(f"{name}")
    print(f"   standard : oracle-union={m('std_or'):.3f}   S3+={m('std_s3p'):.3f}")
    print(f"   residual : oracle-union={m('res_or'):.3f}   S3+={m('res_s3p'):.3f}")
