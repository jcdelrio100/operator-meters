"""
Lightweight cone-adapted discrete shearlet-like directional filter bank (frequency domain).
Not pyshearlab: a faithful practical stand-in that captures the defining property of
shearlets -- anisotropic, multiscale, DIRECTIONAL sub-bands selected by SHEAR (slope),
split into a horizontal and a vertical frequency cone (the cone-adapted construction).

shearlet_feats(X)  ->  (N, F) real directional-energy features for 2-D inputs X:(N,H,W).
Filters are built once per (H,W) and cached. Each sub-band's coefficient magnitude is
average-pooled to a GxG grid; features are concatenated over (scale, cone, shear) + lowpass.
"""
import numpy as np

_CACHE = {}

def _rcos(t, c, hw):
    """raised-cosine bump centered at c, half-width hw, on values t (0 outside [c-hw,c+hw])."""
    u = (t - c) / hw
    w = 0.5 * (1 + np.cos(np.pi * u))
    w[np.abs(u) >= 1] = 0.0
    return w

def _build(H, W, scales=2, shears=2, G=2):
    """Return list of (name, filter HxW real) plus meta. shears: +-shears per cone/scale."""
    fy = np.fft.fftfreq(H)[:, None] * np.ones((1, W))      # in [-0.5,0.5)
    fx = (np.fft.fftfreq(W)[None, :] * np.ones((H, 1)))
    r = np.sqrt(fx**2 + fy**2); rmax = r.max() + 1e-9
    rn = r / rmax
    filts = []
    # radial (scale) windows: smooth dyadic-ish rings + lowpass
    edges = np.linspace(0.0, 1.0, scales + 2)              # scales+1 bands incl lowpass
    # lowpass
    lp = np.clip(1 - rn / (edges[1] + 1e-9), 0, 1) ** 0.5
    filts.append(("lp", lp))
    eps = 1e-6
    for j in range(1, scales + 1):
        c = 0.5 * (edges[j] + edges[j + 1]); hw = (edges[j + 1] - edges[j])
        radial = _rcos(rn, c, hw)
        # cones: horizontal |fy|<=|fx|, vertical otherwise; slope in [-1,1]
        for cone in ("H", "V"):
            if cone == "H":
                mask = (np.abs(fy) <= np.abs(fx) + eps); slope = fy / (fx + np.sign(fx) * eps + eps)
            else:
                mask = (np.abs(fx) < np.abs(fy)); slope = fx / (fy + np.sign(fy) * eps + eps)
            slope = np.clip(slope, -1, 1)
            for k in range(-shears, shears + 1):
                c_k = k / shears; hw_k = 1.0 / shears
                ang = _rcos(slope, c_k, hw_k) * mask
                f = radial * ang
                if f.max() > 1e-9:
                    filts.append((f"s{j}{cone}{k}", f))
    return filts, G

def _feats_one(img, filts, G):
    F = np.fft.fft2(img); out = []
    H, W = img.shape
    for _, filt in filts:
        c = np.abs(np.fft.ifft2(F * filt))                 # sub-band magnitude
        # average-pool to GxG
        hs = np.array_split(c, G, axis=0)
        for hb in hs:
            for wb in np.array_split(hb, G, axis=1):
                out.append(wb.mean())
    return np.array(out, dtype=np.float64)

def shearlet_feats(X, scales=2, shears=2, G=2):
    """X:(N,H,W) real -> (N,F). For video (N,T,H,W) call per-frame then average outside."""
    X = np.asarray(X, dtype=np.float64)
    H, W = X.shape[1], X.shape[2]
    key = (H, W, scales, shears, G)
    if key not in _CACHE: _CACHE[key] = _build(H, W, scales, shears, G)
    filts, Gg = _CACHE[key]
    return np.stack([_feats_one(X[i], filts, Gg) for i in range(len(X))])

def shearlet_feats_video(X, **kw):
    """X:(N,T,H,W) -> average shearlet energy over frames -> (N,F)."""
    X = np.asarray(X, dtype=np.float64); N, T = X.shape[0], X.shape[1]
    acc = None
    for t in range(T):
        f = shearlet_feats(X[:, t], **kw)
        acc = f if acc is None else acc + f
    return acc / T

if __name__ == "__main__":
    # quick sanity: directional bars should light up different shears
    rng = np.random.default_rng(0)
    horiz = np.zeros((28, 28)); horiz[13:15, :] = 1
    vert = np.zeros((28, 28)); vert[:, 13:15] = 1
    fh = shearlet_feats(horiz[None])[0]; fv = shearlet_feats(vert[None])[0]
    print("feat dim:", fh.shape[0])
    print("horiz vs vert differ:", np.abs(fh - fv).sum() > 1e-3, " L1diff=", round(float(np.abs(fh-fv).sum()), 3))
