"""
alpha-molecule-flavored directional filter bank (frequency domain), parametrized by the
anisotropy exponent alpha in [0,1]:
  alpha=1   -> angular resolution CONSTANT with scale  (isotropic, wavelet-like)
  alpha=1/2 -> orientations grow ~2^{j/2} with scale   (parabolic: curvelet/shearlet-like)
  alpha=0   -> orientations grow fastest               (ridgelet-like, max anisotropy)
The defining alpha behaviour is the RATE at which angular resolution refines with scale:
N_orient(j) ~ N0 * 2^{(1-alpha)(j-1)}. Each wedge = radial(scale) x angular(orientation)
window; feature = average-pooled sub-band magnitude. Real images -> orientation is mod pi.
"""
import numpy as np
_CACHE = {}

def _rcos(t, hw):
    w = 0.5 * (1 + np.cos(np.pi * t / hw)); w[np.abs(t) >= hw] = 0.0; return w

def _build(H, W, alpha, scales=3, N0=4, G=2):
    fy = np.fft.fftfreq(H)[:, None] * np.ones((1, W))
    fx = np.fft.fftfreq(W)[None, :] * np.ones((H, 1))
    r = np.sqrt(fx**2 + fy**2); rn = r / (r.max() + 1e-9)
    theta = np.arctan2(fy, fx)                                    # (-pi,pi]
    filts = []
    edges = np.linspace(0.0, 1.0, scales + 2)
    filts.append(("lp", np.clip(1 - rn / (edges[1] + 1e-9), 0, 1) ** 0.5))
    for j in range(1, scales + 1):
        c = 0.5 * (edges[j] + edges[j + 1]); hw = (edges[j + 1] - edges[j])
        radial = _rcos(rn - c, hw)
        Nj = max(1, int(round(N0 * 2 ** ((1 - alpha) * (j - 1)))))
        for m in range(Nj):
            phi = np.pi * m / Nj
            d = (theta - phi + np.pi / 2) % np.pi - np.pi / 2      # distance to line phi (mod pi)
            ang = _rcos(d, np.pi / Nj)
            f = radial * ang
            if f.max() > 1e-9: filts.append((f"s{j}o{m}", f))
    return filts, G

def alpha_feats(X, alpha, scales=3, N0=4, G=2):
    X = np.asarray(X, dtype=np.float64); H, W = X.shape[1], X.shape[2]
    key = (H, W, round(alpha, 4), scales, N0, G)
    if key not in _CACHE: _CACHE[key] = _build(H, W, alpha, scales, N0, G)
    filts, Gg = _CACHE[key]
    out = np.empty((len(X), len(filts) * Gg * Gg))
    for i in range(len(X)):
        F = np.fft.fft2(X[i]); row = []
        for _, filt in filts:
            c = np.abs(np.fft.ifft2(F * filt))
            for hb in np.array_split(c, Gg, 0):
                for wb in np.array_split(hb, Gg, 1): row.append(wb.mean())
        out[i] = row
    return out

def alpha_feats_video(X, **kw):
    X = np.asarray(X, dtype=np.float64); T = X.shape[1]; acc = None
    for t in range(T):
        f = alpha_feats(X[:, t], **kw); acc = f if acc is None else acc + f
    return acc / T

if __name__ == "__main__":
    horiz = np.zeros((28, 28)); horiz[13:15, :] = 1
    for a in (0.0, 0.5, 1.0):
        f = alpha_feats(horiz[None], a); print(f"alpha={a}: feat dim {f.shape[1]}")
