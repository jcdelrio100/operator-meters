"""
Why isn't the learned transform >= the pooled dictionary? Separate the causes.

Per task, same head + K=16, compare:
  S1 union         : full pooled dictionary (Fourier u DWT u CWT, mag+phase)
  best single fixed: the single best transform in the dictionary, alone
  S2 sparse        : learned unitary, Stage-1 objective = sparsity(+CE), frozen
  S2 task (e2e)    : learned unitary trained END-TO-END with the classification loss

If 'S2 task' ~ 'best single fixed', the learned transform DOES reach the best single
basis when optimized for the task, and the dictionary's edge is the UNION of bases.
"""
import sys, os, numpy as np, torch
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier, train as train_uni

DMAX = MM.DMAX; STAGE1 = MM.STAGE1_EP; SEEDS = 2


def single_fixed(Xtr, ytr, Xte, yte, nc, reps):
    best = 0.0; who = None
    for name, fn in reps.items():
        A, B = MM.std_select(fn(Xtr), ytr, fn(Xte), nc)
        a, _, _ = MM.fit_head(A, ytr, B, yte, nc)
        if a > best: best, who = a, name
    return best, who


def s2(Xtr, ytr, Xte, yte, nc, seed, sparse):
    F1 = Xtr.reshape(len(Xtr), -1).astype(np.float64); F2 = Xte.reshape(len(Xte), -1).astype(np.float64)
    if F1.shape[1] > DMAX:
        mu = F1.mean(0); _, _, Vt = np.linalg.svd(F1 - mu, full_matrices=False); Vt = Vt[:DMAX]
        F1 = (F1 - mu) @ Vt.T; F2 = (F2 - mu) @ Vt.T
    sd = F1.std(0) + 1e-9; F1 /= sd; F2 /= sd
    torch.manual_seed(seed); m = UnitaryClassifier(F1.shape[1], nc, seed=seed)
    train_uni(m, F1, ytr, F2, yte, epochs=STAGE1, sparse=sparse)
    with torch.no_grad():
        Z1 = m.features(torch.tensor(F1)).numpy(); Z2 = m.features(torch.tensor(F2)).numpy()
    A, B = MM.std_select(Z1, ytr, Z2, nc)
    return MM.fit_head(A, ytr, B, yte, nc)[0]


TASKS = ["1D global (Fourier)", "1D localized (wavelet)", "video (motion)", "hidden basis (rotated)"]
print(f"{len(SEEDS) if isinstance(SEEDS,list) else SEEDS} seeds\n")
print(f"  {'task':24s} {'S1 union':>9s} {'best single':>16s} {'S2 sparse':>10s} {'S2 task(e2e)':>13s}")
for name in TASKS:
    U, BS, SP, TK = [], [], [], []
    for s in range(SEEDS):
        Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
        A, B, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
        U.append(MM.fit_head(A, ytr, B, yte, nc)[0])
        bs, who = single_fixed(Xtr, ytr, Xte, yte, nc, reps); BS.append(bs)
        SP.append(s2(Xtr, ytr, Xte, yte, nc, s, sparse=4.0))
        TK.append(s2(Xtr, ytr, Xte, yte, nc, s, sparse=0.0))
    print(f"  {name:24s} {np.mean(U):>9.3f} {np.mean(BS):>11.3f}({who[:4]}) "
          f"{np.mean(SP):>10.3f} {np.mean(TK):>13.3f}")
