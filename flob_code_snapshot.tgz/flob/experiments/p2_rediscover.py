"""
P2: does the discovery objective recover a genuinely NEW (non-Fourier) transform?
(a) hidden-basis: data is sparse in a planted random orthogonal basis Q (NOT Fourier/wavelet).
    We train U with classification-only vs discovery (CE+sparsity+TV) and measure how well the
    discriminative atoms align to Q vs to the DFT. Rediscovery => high align-to-Q, low align-to-DFT.
(b) ECG: extract the discovered atoms and check they are QRS-localized (a new data-specific transform).
"""
import os, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import disc_common as D
import superstructure_multimodal as MM
from warmstart import dft_matrix
HERE = os.path.dirname(os.path.abspath(__file__))

def align(atoms, B):
    """mean over atoms of max_j |<atom, B_j>| ; atoms, B rows unit-norm-ish."""
    out = []
    for a in atoms:
        a = a / (np.linalg.norm(a) + 1e-12)
        out.append(np.abs(B.conj() @ a).max())
    return float(np.mean(out))

N = 128; Q = D.hidden_Q(N); U0 = dft_matrix(N)
Qn = Q / (np.linalg.norm(Q, axis=1, keepdims=True) + 1e-12)
Xtr, ytr, Xte, yte, nc, _ = MM.load("hidden basis (rotated)", 0)

rows = []
res = {}
for mode, kw in [("cls", dict(sparse=0.0, tv=0.0)), ("discovery", dict(sparse=0.2, tv=0.1))]:
    m, U, coeff, acc = D.discover(Xtr, ytr, Xte, yte, nc, epochs=180, warm=True, **kw)
    top = D.top_atoms(coeff, ytr, nc, k=4)
    aQ = align(U[top], Qn); aF = align(U[top], U0)
    res[mode] = (U, top, aQ, aF, acc)
    rows.append((mode, acc, aQ, aF))
    print(f"hidden-basis {mode:10s} acc={acc:.3f}  align->Q={aQ:.2f}  align->DFT={aF:.2f}")

# ECG discovery
Xtr_e, ytr_e, Xte_e, yte_e, nce = D.ecg_task(seed=0)
me, Ue, coeffe, acce = D.discover(Xtr_e, ytr_e, Xte_e, yte_e, nce, epochs=180, warm=True, sparse=0.15, tv=0.3)
tope = D.top_atoms(coeffe, ytr_e, nce, k=3)
nov_ecg = 1 - align(Ue[tope], U0); ts = np.mean([D.time_spread(Ue[i]) for i in tope])
mean_beat = Xtr_e[ytr_e == 1].mean(0)
print(f"ECG discovery acc={acce:.3f}  novelty(vs DFT)={nov_ecg:.2f}  time-spread(atoms)={ts:.2f}")

# ---------------- figure ----------------
fig = plt.figure(figsize=(13, 7.5))
gs = fig.add_gridspec(2, 3, hspace=0.42, wspace=0.28)
# (1) alignment heatmap |U Q^T| for discovery vs cls, restricted to discriminative rows
for c, mode in enumerate(("cls", "discovery")):
    U, top, aQ, aF, acc = res[mode]
    M = np.abs(U[top] @ Q.T)                          # (4 x N)
    ax = fig.add_subplot(gs[0, c]); im = ax.imshow(M, aspect="auto", cmap="magma")
    ax.set_title(f"{mode}: |U·Qᵀ| (discriminative atoms)\nalign→Q={aQ:.2f}  align→DFT={aF:.2f}", fontsize=9)
    ax.set_xlabel("planted-basis index j"); ax.set_ylabel("learned atom"); ax.set_yticks(range(len(top)))
# (2) bar: alignment to Q vs DFT
ax = fig.add_subplot(gs[0, 2]); x = np.arange(2); w = 0.35
ax.bar(x - w/2, [res["cls"][2], res["discovery"][2]], w, color="#2ca02c", label="align → planted Q")
ax.bar(x + w/2, [res["cls"][3], res["discovery"][3]], w, color="#888888", label="align → DFT (Fourier)")
ax.set_xticks(x); ax.set_xticklabels(["cls only", "discovery"]); ax.set_ylim(0, 1)
ax.set_ylabel("mean max alignment"); ax.set_title("Rediscovering the planted basis", fontsize=9); ax.legend(fontsize=8)
# (3) overlay: a discovered atom vs its best-matching Q row
U, top, *_ = res["discovery"]; a = U[top[0]].real; a = a / (np.linalg.norm(a) + 1e-12)
j = np.argmax(np.abs(Qn @ (U[top[0]] / (np.linalg.norm(U[top[0]]) + 1e-12))))
q = Qn[j] * np.sign(np.dot(Qn[j], a))
ax = fig.add_subplot(gs[1, 0]); ax.plot(q, color="#000000", lw=2.0, label=f"planted Q row #{j}")
ax.plot(a, color="#d62728", lw=1.2, ls="--", label="discovered atom")
ax.set_title("Discovered atom matches a planted-basis vector", fontsize=9); ax.legend(fontsize=8); ax.set_xticks([]); ax.set_yticks([])
# (4) ECG discovered atom over mean beat
ax = fig.add_subplot(gs[1, 1]); ae = Ue[tope[0]].real; ae = ae / (np.abs(ae).max() + 1e-9)
ax.plot(mean_beat / (np.abs(mean_beat).max() + 1e-9), color="#000000", lw=2.0, label="mean QRS beat")
ax.plot(ae, color="#1f77b4", lw=1.2, label="discovered ECG atom")
ax.set_title(f"ECG: discovered atom is QRS-localized\nnovelty(vs DFT)={nov_ecg:.2f}, time-spread={ts:.2f}", fontsize=9)
ax.legend(fontsize=8); ax.set_xticks([]); ax.set_yticks([])
# (5) text summary
ax = fig.add_subplot(gs[1, 2]); ax.axis("off")
txt = ("Findings\n\n"
       f"Hidden basis (non-Fourier):\n  discovery align→Q = {res['discovery'][2]:.2f}  (DFT {res['discovery'][3]:.2f})\n"
       f"  cls-only align→Q = {res['cls'][2]:.2f}\n  => discovery REDISCOVERS the planted basis,\n     classification alone does not.\n\n"
       f"ECG (real): discovered atom is QRS-\n  localized (time-spread {ts:.2f}), novel vs\n  Fourier ({nov_ecg:.2f}) = a new data-specific\n  transform.")
ax.text(0, 1, txt, va="top", fontsize=9, family="monospace")
fig.suptitle("P2 - discovering genuinely new clean transforms (hidden basis + real ECG)", fontsize=12)
plt.savefig(os.path.join(HERE, "p2_rediscover.png"), dpi=130)
print("saved p2_rediscover.png")
