"""Minimal LIF spiking network with surrogate gradient (self-contained)."""
import torch, torch.nn as nn, torch.nn.functional as F

class _Spike(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x); return (x > 0).float()
    @staticmethod
    def backward(ctx, g):
        (x,) = ctx.saved_tensors; return g / (1 + 10 * x.abs()) ** 2
def spk(x): return _Spike.apply(x)

class SNN_LIF(nn.Module):
    def __init__(self, N, hidden=64, n_classes=4, T=20, beta=0.9):
        super().__init__()
        self.fc1 = nn.Linear(N, hidden); self.fc2 = nn.Linear(hidden, n_classes)
        self.T = T; self.beta = beta
    def forward(self, x):
        B = x.shape[0]
        m1 = torch.zeros(B, self.fc1.out_features, device=x.device)
        m2 = torch.zeros(B, self.fc2.out_features, device=x.device)
        out = torch.zeros_like(m2); c1 = self.fc1(x)
        for _ in range(self.T):
            m1 = self.beta * m1 + c1; s1 = spk(m1 - 1.0); m1 = m1 * (1 - s1.detach())
            m2 = self.beta * m2 + self.fc2(s1); s2 = spk(m2 - 1.0); m2 = m2 * (1 - s2.detach())
            out = out + s2
        return out

def n_params(net): return sum(p.numel() for p in net.parameters())
