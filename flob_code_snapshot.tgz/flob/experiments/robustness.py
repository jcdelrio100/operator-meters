"""
Robustness battery for S3.
  mode 'complex'    : harder tasks (multi-component, more classes, larger N, more
                      samples) at a fixed SINR -> table S1 / S2 / S3 + gate.
  mode 'sinr NAME'  : sweep SINR (class-independent interferer + white noise) for one
                      task -> accuracy vs SINR for S1 / S2 / S3.
  mode 'plot'       : English charts from the JSONs.
Same coupled architecture as s3_coupled (dict branch + gated learned branch, warm-start).
"""
import sys, os, json, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import wave_extractors as W
from learned_transform import UnitaryClassifier, train as train_uni
from warmstart import dft_matrix, warm_start_flat, train_ws

N = 160; K = 16
JC = os.path.join(HERE, "robust_complex.json")
JS = os.path.join(HERE, "robust_sinr.json")


# ================= generators (return CLEAN signals) =================
def _split(X, y, seed, tf=0.3):
    rng = np.random.default_rng(seed); idx = rng.permutation(len(X)); nte = int(len(X)*tf)
    te, tr = idx[:nte], idx[nte:]
    return X[tr], y[tr], X[te], y[te], int(np.unique(y).size)

def _chirp(N, f0, f1, ph):
    t = np.arange(N); inst = (f0 + (f1-f0)*t/(N-1))/N
    return np.cos(2*np.pi*np.cumsum(inst) + ph)

def g_chirp_multi(npc=600, nc=6, seed=0):
    """Each signal = sum of TWO chirps; the pair of chirp-rates encodes the class."""
    rng = np.random.default_rng(seed); rates = np.linspace(-30, 30, nc)
    X, y = [], []
    for c in range(nc):
        for _ in range(npc):
            f0 = rng.uniform(10, 30); s = _chirp(N, f0, f0+rates[c], rng.uniform(0, 6.28))
            f0b = rng.uniform(40, 60); s += 0.8*_chirp(N, f0b, f0b-rates[c]/2, rng.uniform(0, 6.28))
            X.append(s); y.append(c)
    return np.array(X), np.array(y)

def g_hidden_hard(npc=600, nc=8, active=4, seed=0):
    """8 classes separated by active coords in a fixed random orthogonal basis, with
    OVERLAP between classes (shared coords) -> harder."""
    fix = np.random.default_rng(2024); Q, _ = np.linalg.qr(fix.normal(size=(N, N)))
    pool = fix.permutation(N)[:nc+active]
    coords = [pool[c:c+active] for c in range(nc)]                  # overlapping windows
    rng = np.random.default_rng(seed); X, y = [], []
    for c in range(nc):
        for _ in range(npc):
            z = np.zeros(N); z[coords[c]] += rng.uniform(1.2, 2.2, active)*rng.choice([-1., 1.], active)
            X.append(Q.T@z); y.append(c)
    return np.array(X), np.array(y)

def g_wavelet_multi(npc=600, nc=4, seed=0):
    """Several localized packets whose positions encode the class."""
    rng = np.random.default_rng(seed); t = np.arange(N); X, y = [], []
    centers = [[0.2, 0.5], [0.3, 0.7], [0.15, 0.85], [0.5, 0.6]]
    for c in range(nc):
        for _ in range(npc):
            s = np.zeros(N)
            for pc in centers[c]:
                p = pc*N + rng.uniform(-6, 6); w = rng.uniform(5, 9); f = rng.uniform(10, 26)
                s += np.exp(-((t-p)**2)/(2*w**2))*np.cos(2*np.pi*f*t/N + rng.uniform(0, 6.28))
            X.append(s); y.append(c)
    return np.array(X), np.array(y)

def g_composite(npc=700, seed=0):
    """4 classes = 2 bits: a SPECTRAL bit (which tone) x a HIDDEN bit (rotated coords).
    Dictionary sees only the spectral bit; a learned transform sees only the hidden bit;
    only using BOTH branches recovers all 4 classes."""
    fix = np.random.default_rng(7); Q, _ = np.linalg.qr(fix.normal(size=(N, N))); hc = fix.permutation(N)[:3]
    rng = np.random.default_rng(seed); t = np.arange(N); X, y = [], []
    for sb in (0, 1):
        for hb in (0, 1):
            for _ in range(npc):
                f = 18 if sb == 0 else 33
                s = np.cos(2*np.pi*f*t/N + rng.uniform(0, 6.28))               # spectral component
                z = np.zeros(N)
                if hb == 1: z[hc] += rng.uniform(1.5, 2.5, 3)*rng.choice([-1., 1.], 3)
                s = s + Q.T@z                                                   # + hidden component
                X.append(s); y.append(2*sb + hb)
    return np.array(X), np.array(y)

GENS = {"chirp_multi (6cl)": g_chirp_multi, "hidden_hard (8cl)": g_hidden_hard,
        "wavelet_multi (4cl)": g_wavelet_multi, "composite (spectral x hidden)": g_composite}


# ================= corruption: interferer + white noise at target SINR =================
def corrupt(Xc, sinr_db, seed, int_ratio=0.12, fint=25.0):
    rng = np.random.default_rng(seed); t = np.arange(N); n = len(Xc)
    Ps = (Xc**2).mean()
    Pi = int_ratio*Ps; amp = np.sqrt(2*Pi)
    interf = amp*np.cos(2*np.pi*fint*t/N + rng.uniform(0, 6.28, (n, 1)))        # class-independent
    Pn = max(Ps/(10**(sinr_db/10.0)) - Pi, 1e-6*Ps)
    X = Xc + interf + np.sqrt(Pn)*rng.standard_normal(Xc.shape)
    return (X - X.mean(1, keepdims=True))/(X.std(1, keepdims=True)+1e-9)


# ================= pipelines =================
def f_mp(X):
    Xf = np.fft.rfft(X, axis=1); m = np.abs(Xf); p = np.angle(Xf)
    return np.concatenate([m, m*np.cos(p), m*np.sin(p)], 1)
DICT = {"F": f_mp, "D": lambda X: W.dwt_features(X, "db4"), "C": W.cwt_mag}

def fscore(Fm, y, nc):
    n, D = Fm.shape; g = Fm.mean(0); sb = np.zeros(D); sw = np.zeros(D)
    for c in range(nc):
        Fc = Fm[y == c]; sb += len(Fc)*(Fc.mean(0)-g)**2; sw += ((Fc-Fc.mean(0))**2).sum(0)
    return (sb/(nc-1))/(sw/(n-nc)+1e-9)
def sel(P1, y, P2, nc):
    idx = np.argsort(fscore(P1, y, nc))[::-1][:min(K, P1.shape[1])]
    A, B = P1[:, idx], P2[:, idx]; mu, sd = A.mean(0), A.std(0)+1e-9
    return (A-mu)/sd, (B-mu)/sd

def s1_feats(Xtr, ytr, Xte, nc):
    P1 = np.concatenate([f(Xtr) for f in DICT.values()], 1)
    P2 = np.concatenate([f(Xte) for f in DICT.values()], 1)
    return sel(P1, ytr, P2, nc)

def s2_feats(Xtr, ytr, Xte, yte, nc, seed):
    F1, F2 = Xtr.astype(np.float64), Xte.astype(np.float64)
    m = UnitaryClassifier(N, nc, seed=seed); warm_start_flat(m.U, dft_matrix(N))
    train_ws(m, F1, ytr, F2, yte, epochs=150)
    with torch.no_grad():
        Z1 = m.features(torch.tensor(F1)).numpy(); Z2 = m.features(torch.tensor(F2)).numpy()
    return sel(Z1, ytr, Z2, nc)

class GatedResidual(nn.Module):
    def __init__(self, Kd, C, h=32):
        super().__init__(); self.lin = nn.Linear(Kd, C)
        self.nl = nn.Sequential(nn.Linear(Kd, h), nn.ReLU(), nn.Linear(h, C)); self.g = nn.Parameter(torch.tensor(1.0))
    def forward(self, x): return self.lin(x) + self.g*self.nl(x)
def fit_head(A, ytr, B, yte, nc, lam=0.25, ep=350):
    A = torch.tensor(A, dtype=torch.float32); B = torch.tensor(B, dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte); net = GatedResidual(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr=5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(A), yt)+lam*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return (net(B).argmax(1) == ye).float().mean().item()

class S3Head(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); self.lin_d = nn.Linear(Kd, C)
        self.nl = nn.Sequential(nn.Linear(Kd, h), nn.ReLU(), nn.Linear(h, C)); self.lin_s2 = nn.Linear(Kl, C)
        self.g_nl = nn.Parameter(torch.tensor(1.0)); self.g_s2 = nn.Parameter(torch.tensor(1.0))
    def forward(self, xd, xl): return self.lin_d(xd) + self.g_nl*self.nl(xd) + self.g_s2*self.lin_s2(xl)
def fit_s3(Ad, Al, ytr, Bd, Bl, yte, nc, lam=0.25, ep=350):
    Ad = torch.tensor(Ad, dtype=torch.float32); Al = torch.tensor(Al, dtype=torch.float32)
    Bd = torch.tensor(Bd, dtype=torch.float32); Bl = torch.tensor(Bl, dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte); net = S3Head(Ad.shape[1], Al.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr=5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(Ad, Al), yt)+lam*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad():
        return (net(Bd, Bl).argmax(1) == ye).float().mean().item(), float(net.g_s2.abs())

def evaluate(Xtr, ytr, Xte, yte, nc, seed):
    Ad, Bd = s1_feats(Xtr, ytr, Xte, nc); s1 = fit_head(Ad, ytr, Bd, yte, nc)
    Al, Bl = s2_feats(Xtr, ytr, Xte, yte, nc, seed); s2 = fit_head(Al, ytr, Bl, yte, nc)
    s3, g = fit_s3(Ad, Al, ytr, Bd, Bl, yte, nc)
    return s1, s2, s3, g


SEEDS = 5

def run_complex(sinr=6.0, seeds=SEEDS):
    out = json.load(open(JC)) if os.path.exists(JC) else {}
    print(f"Complex tasks at SINR={sinr} dB, {seeds} seeds, N={N}\n  {'task':30s} {'S1':>13s} {'S2':>13s} {'S3':>13s} {'g':>5s}")
    for name, gen in GENS.items():
        S1, S2, S3, G = [], [], [], []
        for s in range(seeds):
            Xc, y = gen(seed=s); Xtr, ytr, Xte, yte, nc = _split(Xc, y, s)
            Xtr = corrupt(Xtr, sinr, s); Xte = corrupt(Xte, sinr, s+50)
            a, b, c, g = evaluate(Xtr, ytr, Xte, yte, nc, s); S1.append(a); S2.append(b); S3.append(c); G.append(g)
        out[name] = {"S1": S1, "S2": S2, "S3": S3, "g": G, "ntr": len(ytr)}
        ms = lambda v: f"{np.mean(v):.3f}+/-{np.std(v):.3f}"
        print(f"  {name:30s} {ms(S1):>13s} {ms(S2):>13s} {ms(S3):>13s} {np.mean(G):>5.2f}")
        json.dump(out, open(JC, "w"), indent=1)


def run_sinr(name, seeds=SEEDS):
    out = json.load(open(JS)) if os.path.exists(JS) else {}
    levels = [-12, -6, 0, 6, 12]
    acc = {k: {db: [] for db in levels} for k in ("S1", "S2", "S3")}
    for s in range(seeds):
        Xc, y = GENS[name](seed=s); Xtr0, ytr, Xte0, yte, nc = _split(Xc, y, s)
        for db in levels:
            Xtr = corrupt(Xtr0, db, s); Xte = corrupt(Xte0, db, s+50)
            a, b, c, _ = evaluate(Xtr, ytr, Xte, yte, nc, s)
            acc["S1"][db].append(a); acc["S2"][db].append(b); acc["S3"][db].append(c)
        print(f"  {name:30s} seed {s} done")
    rec = {"sinr": levels}
    for k in ("S1", "S2", "S3"):
        rec[k] = [float(np.mean(acc[k][db])) for db in levels]
        rec[k+"_sd"] = [float(np.std(acc[k][db])) for db in levels]
    out[name] = rec; json.dump(out, open(JS, "w"), indent=1)
    print(f"  {name}: saved ({seeds} seeds)")


def plot():
    if os.path.exists(JC):
        out = json.load(open(JC)); names = list(out); x = np.arange(len(names)); w = 0.26
        m = lambda t, k: float(np.mean(out[t][k])); sd = lambda t, k: float(np.std(out[t][k]))
        ns = len(out[names[0]]["S1"])
        fig, ax = plt.subplots(figsize=(10, 4.6))
        ax.bar(x-w, [m(t,"S1") for t in names], w, yerr=[sd(t,"S1") for t in names], capsize=3, color="#555555", label="S1 dictionary")
        ax.bar(x,   [m(t,"S2") for t in names], w, yerr=[sd(t,"S2") for t in names], capsize=3, color="#d62728", label="S2 learned")
        ax.bar(x+w, [m(t,"S3") for t in names], w, yerr=[sd(t,"S3") for t in names], capsize=3, color="#1f77b4", label="S3 coupled")
        for i, t in enumerate(names):
            ax.annotate(f"g={m(t,'g'):.2f}", (x[i]+w, m(t,"S3")+sd(t,"S3")), fontsize=7, ha="center", va="bottom", color="#1f77b4")
        ax.set_xticks(x); ax.set_xticklabels(names, rotation=18, ha="right", fontsize=8); ax.set_ylim(0, 1.08)
        ax.set_ylabel("Test accuracy"); ax.set_title(f"Robustness on complex tasks (mean +/- std, {ns} seeds; more components, classes, larger N)")
        ax.legend(fontsize=8); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
        plt.savefig(os.path.join(HERE, "robust_complex.png"), dpi=130); print("saved robust_complex.png")
    if os.path.exists(JS):
        out = json.load(open(JS)); names = list(out)
        fig, axs = plt.subplots(1, len(names), figsize=(4.6*len(names), 3.8), sharey=True)
        if len(names) == 1: axs = [axs]
        cols = {"S1": "#555555", "S2": "#d62728", "S3": "#1f77b4"}; mk = {"S1": "o", "S2": "s", "S3": "^"}
        lab = {"S1": "S1 dictionary", "S2": "S2 learned", "S3": "S3 coupled"}
        for ax, t in zip(axs, names):
            r = out[t]; xs = r["sinr"]
            for k in ("S1", "S2", "S3"):
                y = np.array(r[k]); e = np.array(r.get(k+"_sd", [0]*len(xs)))
                ax.plot(xs, y, mk[k]+"-", color=cols[k], label=lab[k])
                ax.fill_between(xs, y-e, y+e, color=cols[k], alpha=0.15)
            ax.set_title(t, fontsize=9); ax.set_xlabel("SINR (dB)"); ax.grid(alpha=0.3)
        axs[0].set_ylabel("Test accuracy"); axs[0].legend(fontsize=8)
        fig.suptitle("Accuracy vs SINR (mean +/- std; class-independent interferer + white noise)")
        plt.tight_layout(); plt.savefig(os.path.join(HERE, "robust_sinr.png"), dpi=130); print("saved robust_sinr.png")


if __name__ == "__main__":
    if sys.argv[1] == "complex": run_complex()
    elif sys.argv[1] == "sinr": run_sinr(sys.argv[2])
    elif sys.argv[1] == "plot": plot()
