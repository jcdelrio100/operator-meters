"""Self-organizing classifier head: starts as an exact linear readout and lets
nonlinear residual blocks switch themselves ON only if they earn their cost.

    y = W x + sum_l  g_l * f_l(x)

f_l : small MLP block; g_l : learnable scalar gate initialised to 0 (so the model
boots up exactly linear). An L1 penalty lambda*sum|g_l| keeps a block off unless it
buys enough accuracy. The trained gate magnitudes are a free 'how nonlinear was this
data' diagnostic, in the same spirit as the atom-provenance read-out.

We feed every head the SAME K matched-selected coordinates per modality, so the only
thing that changes is the head. A synthetic XOR task (two informative coords whose
class is their parity) is added as a litmus test: linear must fail, the gates must open.
"""
import sys, json, numpy as np
sys.path.insert(0,'.'); sys.path.insert(0,'../Estudio_Wavelets')
import torch, torch.nn as nn, torch.nn.functional as F
import harness as H, modal_eb as M
torch.set_num_threads(4)

# ---------------- selected-feature builders ----------------
def select_feats(Xtr,ytr,Xte,yte,reps,nc,K=16):
    P1=np.concatenate([fn(Xtr) for fn in reps.values()],1)
    P2=np.concatenate([fn(Xte) for fn in reps.values()],1)
    idx=np.argsort(H.fscore(P1,ytr,nc))[::-1][:K]
    A,B=P1[:,idx],P2[:,idx]
    mu,sd=A.mean(0),A.std(0)+1e-9
    return (A-mu)/sd,ytr,(B-mu)/sd,yte,nc

def modality_feats(name,seed,K=16):
    if name=='1-D localized': Xtr,ytr,nc=M.loc(900,seed); Xte,yte,_=M.loc(500,seed+100); reps=M.reps1d
    elif name=='1-D global':  Xtr,ytr,nc=M.glob(900,seed); Xte,yte,_=M.glob(500,seed+100); reps=M.reps1d
    elif name=='image (digits)': Xtr,ytr,Xte,yte,nc=M.digits_split(seed); reps=M.img_reps
    elif name=='texture (28x28)': Xtr,ytr,nc=M.texture(900,seed); Xte,yte,_=M.texture(500,seed+100); reps=M.img_reps
    elif name=='text (topic)': Xtr,ytr,nc=M.seqt(1600,seed); Xte,yte,_=M.seqt(800,seed+100); reps=M.seq_reps
    elif name=='video (motion)': Xtr,ytr,nc=M.vid(500,seed); Xte,yte,_=M.vid(400,seed+100); reps=M.vid_reps
    return select_feats(Xtr,ytr,Xte,yte,reps,nc,K)

def xor_feats(seed,K=16,n=1600,nte=800):
    # true XOR: class = parity of the signs of two informative coords -> NOT linearly separable
    rng=np.random.default_rng(seed)
    def make(m):
        Z=rng.normal(0,1,(m,K))                       # K standardized coords, mostly noise
        y=((Z[:,0]>0) ^ (Z[:,1]>0)).astype(int)       # XOR of two coords (2 classes)
        return Z.astype('float64'),y
    Xtr,ytr=make(n); Xte,yte=make(nte); return Xtr,ytr,Xte,yte,2

# ---------------- heads ----------------
class GatedResidual(nn.Module):
    def __init__(self,K,C,blocks=2,h=32,init_g=1.0):
        super().__init__()
        self.lin=nn.Linear(K,C)
        self.blocks=nn.ModuleList([nn.Sequential(nn.Linear(K,h),nn.ReLU(),nn.Linear(h,C)) for _ in range(blocks)])
        # gates start OPEN so the nonlinear blocks receive gradient and can learn;
        # the L1 penalty then prunes any gate the data does not need -> collapses to linear.
        self.gates=nn.Parameter(torch.full((blocks,),float(init_g)))
        self.K,self.C,self.h,self.nb=K,C,h,blocks
    def forward(self,x):
        out=self.lin(x)
        for g,b in zip(self.gates,self.blocks): out=out+g*b(x)
        return out
    def block_params(self): return self.K*self.h+self.h + self.h*self.C+self.C
    def lin_params(self):   return self.K*self.C+self.C

def fit_head(A,ytr,B,yte,nc,lam=0.25,ep=600,lr=5e-3,blocks=2,h=32,eps=0.15):
    A=torch.tensor(A,dtype=torch.float32); B=torch.tensor(B,dtype=torch.float32)
    yt=torch.tensor(ytr); ye=torch.tensor(yte)
    net=GatedResidual(A.shape[1],nc,blocks,h)
    opt=torch.optim.Adam(net.parameters(),lr=lr,weight_decay=1e-4)
    for _ in range(ep):
        net.train(); opt.zero_grad()
        loss=F.cross_entropy(net(A),yt)+lam*net.gates.abs().sum()
        loss.backward(); opt.step()
    net.eval()
    with torch.no_grad():
        acc=(net(B).argmax(1)==ye).float().mean().item()
        gates=net.gates.abs().tolist()
    eff=net.lin_params()+sum(net.block_params() for g in gates if g>eps)
    return acc,gates,eff

def fit_linear(A,ytr,B,yte,nc):
    return H.linread(A,ytr,B,yte,nc)

# ---------------- run ----------------
MODS=['1-D localized','1-D global','image (digits)','texture (28x28)','text (topic)','video (motion)','XOR (litmus)']
SEEDS=3
def main():
    out={}
    for name in MODS:
        accs_lin=[]; accs_gate=[]; gate_open=[]; effs=[]
        for s in range(SEEDS):
            if name=='XOR (litmus)': A,ytr,B,yte,nc=xor_feats(s)
            else: A,ytr,B,yte,nc=modality_feats(name,s)
            accs_lin.append(fit_linear(A,ytr,B,yte,nc))
            a,g,eff=fit_head(A,ytr,B,yte,nc)
            accs_gate.append(a); gate_open.append(max(g)); effs.append(eff)
        out[name]={'linear':[round(np.mean(accs_lin),3),round(np.std(accs_lin),3)],
                   'gated':[round(np.mean(accs_gate),3),round(np.std(accs_gate),3)],
                   'gate_open':round(float(np.mean(gate_open)),3),
                   'eff_params':int(np.median(effs))}
        print(f"{name:16} linear={out[name]['linear'][0]:.3f}  gated={out[name]['gated'][0]:.3f}  "
              f"max|gate|={out[name]['gate_open']:.2f}  eff_params={out[name]['eff_params']}")
    json.dump(out,open('gated_results.json','w'),indent=1)
    print('saved gated_results.json')

if __name__=='__main__':
    main()
