"""
Does adding a DIRECTIONAL (shearlet-like) branch to the S1 dictionary help on 2-D
directional tasks (texture, real digits, video-motion)? We compare, 5 seeds:
  S1            : current dictionary (Fourier2D/3D + pixels/per-frame)
  S1+shear      : same dictionary AUGMENTED with the shearlet directional branch
  S2            : learned transform (warm-start), unchanged
  S3+           : coupling with the BASE S1
  S3+shear      : coupling with the shear-augmented S1
Reports accuracy and the S3+ gate g_s2 (does directional S1 make the learned branch
less necessary?). Resumable via shearlet_study.json.
"""
import sys, os, json, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3
from shearlets import shearlet_feats, shearlet_feats_video

SEEDS = 5
TASKS = ["texture (28x28)", "image digits (real)", "video (motion)"]
JS = os.path.join(HERE, "shearlet_study.json")

class S3plus(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); D = Kd + Kl
        self.lin = nn.Linear(D, C); self.nl = nn.Sequential(nn.Linear(D, h), nn.ReLU(), nn.Linear(h, C))
        self.g_nl = nn.Parameter(torch.tensor(1.0)); self.g_s2 = nn.Parameter(torch.tensor(1.0))
    def forward(self, xd, xl): x = torch.cat([xd, self.g_s2 * xl], 1); return self.lin(x) + self.g_nl * self.nl(x)

def fit_s3plus(Ad, Al, ytr, Bd, Bl, yte, nc, ep=350):
    Ad, Al, Bd, Bl = [torch.tensor(z, dtype=torch.float32) for z in (Ad, Al, Bd, Bl)]
    yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = S3plus(Ad.shape[1], Al.shape[1], nc); opt = torch.optim.Adam(net.parameters(), 5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(Ad, Al), yt) + 0.25 * (net.g_nl.abs() + net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad(): return (net(Bd, Bl).argmax(1) == ye).float().mean().item(), float(net.g_s2.abs())

def shear_reps(name):
    if name == "video (motion)":
        return {"shear": lambda X: shearlet_feats_video(X)}
    return {"shear": lambda X: shearlet_feats(X)}

def run():
    out = json.load(open(JS)) if os.path.exists(JS) else {}
    print(f"{SEEDS} seeds")
    for name in TASKS:
        if name in out: print("skip", name); continue
        R = {k: [] for k in ("S1", "S1sh", "S2", "S3", "S3sh", "g", "gsh")}
        for s in range(SEEDS):
            Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
            reps_sh = {**reps, **shear_reps(name)}
            Ad, Bd, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
            Ads, Bds, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps_sh)
            Al, Bl = S3.learned_branch(name, Xtr, ytr, Xte, yte, nc, s)
            R["S1"].append(MM.fit_head(Ad, ytr, Bd, yte, nc)[0])
            R["S1sh"].append(MM.fit_head(Ads, ytr, Bds, yte, nc)[0])
            R["S2"].append(MM.fit_head(Al, ytr, Bl, yte, nc)[0])
            a, g = fit_s3plus(Ad, Al, ytr, Bd, Bl, yte, nc); R["S3"].append(a); R["g"].append(g)
            a, g = fit_s3plus(Ads, Al, ytr, Bds, Bl, yte, nc); R["S3sh"].append(a); R["gsh"].append(g)
        out[name] = R; json.dump(out, open(JS, "w"), indent=1)
        f = lambda k: f"{np.mean(R[k]):.3f}"
        print(f"  {name:20s} S1={f('S1')} S1+sh={f('S1sh')} S2={f('S2')} "
              f"S3={f('S3')}(g{np.mean(R['g']):.2f}) S3+sh={f('S3sh')}(g{np.mean(R['gsh']):.2f})")
    return out

def plot(out):
    names = [t for t in TASKS if t in out]; x = np.arange(len(names)); w = 0.16
    m = lambda t, k: float(np.mean(out[t][k])); sd = lambda t, k: float(np.std(out[t][k]))
    Y0 = 0.5
    fig, ax = plt.subplots(figsize=(11, 5))
    series = [("S1", "#555555", "S1 dictionary"), ("S1sh", "#8c564b", "S1 + shearlets"),
              ("S2", "#d62728", "S2 learned"), ("S3", "#1f77b4", "S3+ (base S1)"),
              ("S3sh", "#2ca02c", "S3+ (S1 + shearlets)")]
    off = {k: (i - (len(series) - 1) / 2) * w for i, (k, _, _) in enumerate(series)}
    for k, col, lab in series:
        ax.bar(x + off[k], [m(t, k) for t in names], w, yerr=[sd(t, k) for t in names],
               capsize=2, color=col, label=lab)
    for i, t in enumerate(names):
        ax.annotate(f"g={m(t,'g'):.2f}", (x[i] + off['S3'], m(t, "S3") + sd(t, "S3") + 0.004), fontsize=7, ha="center", color="#1f77b4")
        ax.annotate(f"g={m(t,'gsh'):.2f}", (x[i] + off['S3sh'], m(t, "S3sh") + sd(t, "S3sh") + 0.004), fontsize=7, ha="center", color="#2ca02c")
    ax.set_xticks(x); ax.set_xticklabels(names, fontsize=9)
    ax.set_ylabel("Test accuracy"); ax.set_ylim(Y0, 1.02); ax.axhline(Y0, color="k", lw=0.6)
    ax.set_title(f"Adding a directional (shearlet-like) branch to S1 on 2-D tasks "
                 f"(mean +/- std, {SEEDS} seeds; y-axis starts at {Y0})")
    ax.legend(fontsize=8, ncol=2, loc="lower left"); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(HERE, "shearlet_study.png"), dpi=130); print("saved shearlet_study.png")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "plot": plot(json.load(open(JS)))
    else: plot(run())
