"""
P1: locality prior -> sharper, wavelet/Gabor-like atoms.
On a task with LOCALIZED structure (1D localized), compare the discovered top atom under:
  cls              : classification only (noisy)
  discovery        : + sparsity + TV (clean but can stay global)
  discovery + loc  : + time-locality prior (Gabor/wavelet-like localized atoms)
Metrics: accuracy, spectral flatness (clean=0), time-spread (localized=0). Also on the Fourier
task, to show locality is a *chosen* prior (it localizes even a global-tone task, with a trade-off).
"""
import os, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import disc_common as D
import superstructure_multimodal as MM
from learned_transform import atom_flatness
HERE = os.path.dirname(os.path.abspath(__file__))

MODES = [("cls", dict(sparse=0, tv=0, loc=0)),
         ("discovery", dict(sparse=0.15, tv=0.3, loc=0)),
         ("discovery+loc", dict(sparse=0.15, tv=0.3, loc=0.6))]
TASKS = [("1D localized (wavelet)", "load"), ("1D global (Fourier)", "load")]

fig, axes = plt.subplots(len(TASKS), len(MODES), figsize=(12, 6.4))
print(f"{'task':22s} {'mode':16s} {'acc':>6s} {'flat':>6s} {'tspread':>8s}")
for r, (name, kind) in enumerate(TASKS):
    Xtr, ytr, Xte, yte, nc, _ = MM.load(name, 0)
    for c, (mode, kw) in enumerate(MODES):
        m, U, coeff, acc = D.discover(Xtr, ytr, Xte, yte, nc, epochs=160, warm=True, **kw)
        top = D.top_atoms(coeff, ytr, nc, k=3)
        flat = atom_flatness(U, top); ts = float(np.mean([D.time_spread(U[i]) for i in top]))
        print(f"{name:22s} {mode:16s} {acc:>6.3f} {flat:>6.2f} {ts:>8.2f}")
        a = U[top[0]]; ax = axes[r, c]
        ax.plot(a.real, color="#1f77b4", lw=1.3); ax.plot(a.imag, color="#d62728", lw=0.8, alpha=0.6)
        ax.set_title(f"{mode}\nacc={acc:.2f} flat={flat:.2f} tspread={ts:.2f}", fontsize=8.5)
        ax.set_xticks([]); ax.set_yticks([])
        if c == 0: ax.set_ylabel(name, fontsize=9)
fig.suptitle("P1 - locality prior yields localized (Gabor/wavelet-like) atoms "
             "(tspread: 0=localized, 1=global)", fontsize=11)
plt.tight_layout(rect=[0, 0, 1, 0.94]); plt.savefig(os.path.join(HERE, "p1_locality.png"), dpi=130)
print("saved p1_locality.png")
