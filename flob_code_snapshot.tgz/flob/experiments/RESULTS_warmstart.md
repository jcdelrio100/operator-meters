# Warm-starting the learned transform from the fixed transform

Your argument — the learned transform should be able to *be* Fourier/wavelet and then improve — is exactly right, and the fix is to **initialize** it there instead of at random. We set the generator `G = log(U0)` (skew-Hermitian) so that `exp(C−C^H) = U0` for a chosen fixed unitary `U0` (the DFT for 1-D; per-axis DFTs = 2-D/3-D Fourier for structured data), then train end-to-end for the task (no weight-decay on the transform, so it is not pulled back toward identity). Verified: `exp(G) = DFT` to 1e-14.

## Results (2 seeds, same head, K=16)

| task | S1 dictionary | best single fixed | S2 random-init + task | **S2 warm-start + task** |
|---|---|---|---|---|
| 1D localized | 0.999 | 0.999 (Fourier) | 0.909 | **0.994** |
| video (motion) | 1.000 | 1.000 (Fourier) | 0.819 | **0.990** |
| hidden basis (rotated) | 0.670 | 0.788 (DWT) | 0.985 | **0.963** |
| texture (28×28) | 0.953 | 0.951 (Fourier) | 0.926 | 0.896 |

(warm@0, i.e. the warm-started transform *before* any training, already scores ≈ the fixed transform: 0.976 / 0.959 / 0.906 — the sanity check that it truly starts at Fourier.)

## What this shows

- **Warm-start closes the gap.** On the modalities where the random-init learned transform lost badly, initializing from Fourier and training for the task jumps it to near the dictionary: localized 0.909 → **0.994** (vs dict 0.999), video 0.819 → **0.990** (vs dict 1.000). This confirms the earlier deficit was **initialization + objective**, not a fundamental limit — exactly your point.
- **It keeps the flexibility.** On `hidden_basis`, starting from the (wrong) DFT and training still rotates the transform to 0.963 — far above the dictionary's 0.670. So warm-start does not cost the non-classical win.
- **Net:** the learned transform, warm-started from the dictionary's best fixed transform, becomes ≈ a **strict generalization** of it: it starts at the fixed transform's accuracy and moves toward a better basis when one exists.

## Honest wrinkles

- warm@0 is a hair below the pure fixed transform (0.976 vs 0.999 on localized) because `|Ux|` with `U=DFT` reproduces the Fourier *magnitude* branch but not its phase features; the dictionary also carries phase.
- **texture** actually regressed slightly under training (0.906 → 0.896, below the dictionary's 0.953): end-to-end training can drift away from a good init, so early stopping / smaller learning rate on the transform is needed. One clean case where warm-start alone was not enough.
- On `hidden_basis` warm-start (0.963) is slightly below random-init (0.985): starting at the DFT (far from the hidden basis) is a worse launch point than random for a genuinely non-classical target. The ideal is to warm-start from the *best-matching* fixed transform per task (or from several inits and keep the best).

## Takeaway for the paper

This resolves the apparent paradox. Expressivity was never the issue; reachability was. Warm-starting from the fixed transform makes the learned transform match the dictionary where a matched transform exists and beat it where none does — turning it from a *replacement* (which loses on classical modalities) into a *generalization* (which does not). The practical recipe: **initialize the learned transform from the pooled dictionary's best transform, then fine-tune for the task**, with early stopping to avoid drifting off a good basis.
