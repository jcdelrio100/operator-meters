# Evolutionary search over matched-transform dictionaries — first results

**Date:** 2026-08-14 · seed 0 · CPU only · code in `evo/`

> **Correction (run 3).** Runs 1 and 2 below searched **S1 only** — no learned
> unitary branch, no S3+ head — so their "+0.06 to +0.18" is a gain over the
> fixed **S1** dictionary, *not* over S3+. Run 3 puts the S2 branch in the
> genotype and S3+ in the head, and adds all three hand-designed
> superstructures as baselines. **Read run 3 for the real deltas.** The
> conclusions about evolution vs random search and about mutation neutrality
> are unchanged.

## What was built

The genotype is the **discrete** part of the S1 pipeline — the part gradient
descent cannot reach. Everything downstream (the GatedResidual head) is still
trained by gradient. Evolution and gradients do not compete for the same
variables:

```
genotype = { genes: [ (family, params) × 1..6 ],  K,  blocks,  h }
```

Gene families: `fourier`, `raw`, `frft(a)`, `chirplet(rate,win,hop)`,
`dwt(wavelet,level)`, `cwt(flo,fhi,nf,nc,pool)`, `scatter(...)`, `stft(win,hop)`.

Mutation operators: **`duplicate`** (copy a gene and jitter its parameters —
Ohno's duplication-then-divergence, the operator from the original idea),
`add`, `delete`, `tweak`, `head`.

Search: regularized evolution (Real et al. 2019) — population 12, tournament 4,
**evict the oldest, not the worst**.

New module `frft.py`: exact DFrFT via the Dickinson–Steiglitz commuting matrix,
verified to machine precision on five properties (`F⁰=I`, `F¹=DFT`, `F⁴=I`,
`F^0.3F^0.7=F¹`, unitarity) for N = 16, 17, 64, 128.

## Protocol

Three-way split. **The search only ever sees validation; test is touched once**,
for the champion of each method. Every method gets the **same number of genome
evaluations** and the same head-training schedule, so the x-axis is compute.
Baselines: the hand-designed S1 dictionary (Fourier + db4 DWT + Morlet CWT), and
random search over the *same* genotype space.

Task difficulty was recalibrated first: with the original settings the fixed
dictionary already scored 1.000 on 4 of 5 tasks. **A saturated benchmark cannot
separate search methods.** Noise and sample counts were tuned so the fixed
dictionary lands near 0.80.

## Results

### Run 1 — single validation split, 150 evaluations per method

| task | fixed (val/test) | random | evolution | test winner |
|---|---|---|---|---|
| chirp direction | 0.796 / 0.784 | 0.904 / **0.864** | 0.876 / 0.840 | random |
| chirp rate | 0.807 / 0.785 | 0.952 / **0.968** | 0.955 / 0.950 | random |
| 1D global | 0.856 / 0.851 | 0.904 / **0.891** | 0.913 / 0.880 | random |
| 1D localized | 0.871 / 0.849 | 0.902 / 0.900 | 0.916 / **0.909** | evolution |

mean val−test gap: random **+0.010**, evolution **+0.020**

### Run 2 — 4-fold CV fitness, 110 evaluations per method

| task | fixed | random | evolution | test winner |
|---|---|---|---|---|
| chirp rate | 0.792 / 0.800 | 0.965 / **0.970** | 0.968 / 0.965 | random |
| 1D global | 0.864 / 0.884 | 0.896 / **0.911** | 0.895 / 0.887 | random |
| chirp direction | 0.771 / 0.820 | 0.894 / **0.912** | 0.896 / 0.896 | random |

mean val−test gap: random **−0.013**, evolution **+0.004**

### Run 3 — S2 in the genotype, S3+ head, all three superstructures as baselines

Genotype gains an `s2` slot (off / bandwidth 2 / 8 / full) and an `s2` mutation
operator; the head becomes `S3PlusHead` — joint readout over
`[x_dict ; g_s2 · x_learn]` with the L1-penalised protective gate. With
`s2 = None` it reduces to the original GatedResidual bit for bit. The learned
unitary is trained for 150 epochs (the article's `STAGE1_EP`) on the training
fold only, and **cached by (bandwidth, fold)** — it does not depend on the
dictionary genes, which is what makes S2-in-the-genotype affordable.

3-fold CV fitness, 110 evaluations per method. All numbers are held-out test:

| task | S1 | S2 | S3+ | random | evolution | best hand-designed | Δ search |
|---|---|---|---|---|---|---|---|
| chirp direction | 0.820 | 0.540 | 0.788 | **0.912** | 0.900 | 0.820 | **+0.092** |
| chirp rate | 0.800 | 0.877 | 0.890 | **0.955** | 0.950 | 0.890 | **+0.065** |
| 1D global | 0.884 | 0.384 | 0.869 | **0.900** | 0.896 | 0.884 | **+0.016** |
| 1D localized | 0.869 | 0.302 | 0.867 | **0.927** | 0.924 | 0.869 | **+0.058** |

mean val−test gap: random −0.015, evolution −0.008. Test wins: random 4,
evolution 0.

**The corrected headline number: +0.016 to +0.092 over the best of the three
hand-designed superstructures** (mean +0.058), not the +0.06/+0.18 over S1
alone reported in runs 1–2.

Two further observations from this run:

- **S3+ ≥ max(S1, S2): re-checked properly in run 6 — see below.** The
  single-seed deltas quoted here (−0.032, +0.013, −0.016, −0.002) were smaller
  than the standard error of the test sets they came from, so "did not reproduce
  on 3 of 4" was an over-claim. With 10 seeds the correct statement is **2 of 4
  significant**, and the mechanism is specific.
- **Evolution switches S2 off where S2 is useless.** On chirp direction (S2 at
  0.540, near chance) the champion dropped the branch via the `s2` operator; on
  chirp rate (S2 at 0.877, genuinely informative) the champion kept it at
  bandwidth 8. The genotype reads as a correct diagnosis of each task.

### Run 4 — hybrid gradient/mutation operator

`tweak` no longer jitters blindly. It finds which top-K columns come from the
target gene, freezes the selection and the other genes' columns, fits a linear
readout in closed form, and **backpropagates the cross-entropy into the gene's
continuous parameters**. Reachable by gradient: `frft.a`, `chirplet.rate`,
`cwt/scatter.{flo,fhi,nc}` — verified against finite differences to ~1e-4
relative. If the predicted loss change over one mutation-sized step is below
2e-3 the parameter is declared INERT and the operator falls back to the random
jitter.

Same protocol, same seeds, same budget as run 3.

| task | S3+ | random | evolution | evolution+grad |
|---|---|---|---|---|
| chirp direction | 0.788 | **0.912** | 0.900 | 0.876 |
| chirp rate | 0.890 | **0.955** | 0.950 | 0.927 |
| 1D global | 0.869 | **0.900** | 0.896 | **0.900** |
| 1D localized | 0.867 | **0.927** | 0.924 | 0.924 |

**mean Δ(evolution+grad − evolution) = −0.011.** Cost is unchanged (the gradient
steps are cheap next to head training).

Hit rate per operator, pooled over the four tasks:

| operator | n | improved val | mean Δval |
|---|---|---|---|
| **grad** | 25 | **44.0 %** | −0.005 |
| s2 | 46 | 28.3 % | −0.002 |
| add | 59 | 13.6 % | −0.010 |
| tweak → unexpressed | 15 | 13.3 % | −0.014 |
| head | 62 | 12.9 % | −0.016 |
| delete | 49 | 8.2 % | −0.113 |
| tweak → noimprove | 39 | 5.1 % | −0.004 |
| duplicate | 43 | 2.3 % | −0.032 |
| tweak → nograd | 48 | **0.0 %** | −0.004 |
| tweak → inert | 6 | **0.0 %** | −0.004 |

**The gradient is by far the best local move — and it still does not help.**
`grad` improves 44 % of the time, five times the rate of any blind operator, yet
the run ends 0.011 *below* plain evolution. The improvements are real but small
and local: refining a parameter inside a basin, while the budget it consumes was
the only thing exploring other basins. In a landscape where the champion is
found in the first ~30 evaluations, better polishing is not the binding
constraint. Coverage is. This is the same conclusion as findings 1 and 2,
arrived at from a third direction.

**What the gradient IS good for: predicting which mutations are worthless.**
Every move the operator flagged as inert or gradient-unreachable had a **0 %**
success rate (n = 54), against 44 % for the moves it flagged as informative.
That separation is clean and it is information no black-box search can obtain.
The right use is therefore not as an operator but as a **filter on the
catalogue**: `|dL/dp| ~ 0` means the gene is decorative and should be pruned
from the search space entirely, which shrinks the space instead of refining
moves within it.

Concretely, that already fired once: `chirplet.rate` has a predicted |dL| of
6e-5 at win=32 and 9e-4 at win=128, i.e. inert. A parameter scan confirms it —
the loss varies by 0.0007 over rate ∈ [−40, 40] at win=32. Short-window
magnitude spectra are nearly dechirp-invariant. **This retroactively explains a
run-3 result**: evolution never found a meaningful chirplet rate and kept
converging on plain `stft`, which is chirplet with rate = 0. The gene was
decorative and the search was right to ignore it — a fact only the gradient
could have told us in advance.

### Run 5 — successive halving

Two changes, both aimed at coverage. (a) **Test is no longer scored per genome**
— runs 1–4 refit the head on the full pool for every candidate, purely for
logging; that was ~40 % of the search cost and is not part of the search. (b)
**Rungs [30, 90, 270] with η = 3**: a genome is promoted only if it beats the
top-third cutoff of its rung. Per-fold feature blocks are built once per genome
and reused across rungs, otherwise the rungs re-pay the extraction overhead.

Budget is **wall-clock seconds**, not epochs — a per-epoch budget would be
dishonest here, because each evaluation pays a fixed feature/selection cost that
does not shrink with the rung. Champions are chosen among top-rung genomes only
(ASHA).

| task | 300 ep · random | SHA · random | 300 ep · evolution | SHA · evolution |
|---|---|---|---|---|
| | genomes / test | genomes / test | genomes / test | genomes / test |
| chirp direction | 162 / 0.892 | 461 / 0.892 | 128 / 0.900 | 131 / 0.880 |
| chirp rate | 148 / 0.945 | 410 / **0.975** | 124 / 0.950 | 165 / 0.968 |
| 1D global | 150 / 0.900 | 424 / 0.900 | 327 / 0.889 | 300 / 0.876 |
| 1D localized | 142 / 0.927 | 386 / 0.924 | 154 / 0.922 | 234 / 0.918 |

**Coverage delivered: 2.0× more genomes at equal wall clock** (2.8× for random
search, only 1.2× for evolution — SHA saves compute by culling bad candidates,
and evolution mostly proposes decent ones, so there is little to cull).

**Accuracy delivered: essentially nothing.** Mean Δtest = **+0.007** for random
(all of it from one task) and **−0.005** for evolution. On chirp direction,
random search at 461 genomes converged on the *identical* champion it had
already found at 162.

**This corrects the diagnosis from runs 1–4.** I read "the binding constraint is
coverage, not the quality of local moves" — that was half right. Tripling the
coverage changes almost nothing, so the constraint is not coverage either: **the
search space is simply small enough that ~150 random draws exhaust it.** With
≤ 6 genes over 8 families and one S2 slot, there is no more accuracy in there to
find. Better moves do not help, more samples do not help, because the ceiling is
the space itself.

That makes the next step unambiguous, and it is not an algorithmic one: **grow
the search space** — more families (shearlets, s2frame, learnable Gabor α,
second-order scattering), more genes, per-branch K, and the discrete choices
currently frozen (lam, the selector itself). Only when random search stops
saturating does any smarter search method have room to demonstrate a difference.

### Run 6 — is the S3+ violation real? (10 seeds, paired)

Run 3 reported the S3+ deltas from **one seed** on test sets of 125–225 samples.
The standard error of an accuracy of 0.8 on 125 samples is 0.036 — larger than
every delta quoted. So the claim needed repetition before it meant anything.
Paired over 10 seeds, with bootstrap CIs:

| task | S1 | S2 | S3+ | S3+ − max(S1,S2) | CI95 | significant? |
|---|---|---|---|---|---|---|
| chirp direction | 0.802±.028 | 0.552±.073 | 0.773±.030 | **−0.029** | [−0.052, −0.008] | **yes** |
| chirp rate | 0.772±.047 | 0.857±.019 | 0.863±.020 | +0.006 | [−0.014, +0.023] | no |
| 1D global | 0.860±.031 | 0.283±.035 | 0.845±.046 | **−0.015** | [−0.026, −0.004] | **yes** |
| 1D localized | 0.864±.025 | 0.277±.028 | 0.862±.021 | −0.002 | [−0.011, +0.007] | no |

**My run-3 claim was half wrong and half right.** Wrong: it is 2 of 4, not 3 of
4 — I read single-seed noise. Right: two of them survive 10 seeds with CIs that
exclude zero, so there is a real effect and it is not a fluke.

**The mechanism is clean.** The one task where S3+ works is the only one where
the learned branch is genuinely informative (S2 = 0.857, i.e. +0.607 over
chance). On the other three S2 is at or near chance (+0.027 to +0.052 over
chance) and coupling costs accuracy. Across tasks the deficit tracks how far S2
sits above chance, Pearson r = 0.67. A chance-level branch still hands the head
K_l coordinates it can use to fit the *training* set, and the L1 term — which
only sees training loss — is not a strong enough counterweight on small samples.

**A second, separable finding: |g_s2| is not a valid "branch is off" readout.**
Since `lin(g_s2 · x_l) = (g_s2 · W_l) x_l`, the gate and the readout weights on
the learned block trade off exactly, so L1 on the gate alone can be absorbed by
growing W_l. Measured: at g_s2 ≈ 0.17–0.22 the *effective* learned contribution
g_s2·‖W_l‖ is still **23–40 %** of the dictionary's ‖W_d‖. The quantity the gate
is meant to control is the effective scale, and that is what should be reported.

**What this does and does not say about the article.** It is not a refutation.
The article's evidence spans S2 ∈ [0.858, 1.000] — it never tests a chance-level
learned branch, which is exactly the regime where the protection fails. The
correct action is to scope the claim, not withdraw it. Edits applied to
`paper/superstructures.tex` (diff in `superstructures_edits.diff`):

1. Table 2, ECG row: S3+ (0.978) was bolded as best while S2 (0.982) is higher.
   Both are now bolded and the caption defines "tied" as within one std. The
   body text says explicitly that S3+ recovers the better branch there rather
   than exceeding it. *(This one is internal to the article — its own numbers
   did not match its own bolding rule.)*
2. "coupling never hurts" → "does not hurt across the regimes tested here",
   with a pointer to the limitations section.
3. A new limitations paragraph stating the verified regime, the two significant
   violations with CIs, the mechanism, and the g_s2 identifiability caveat.

## Seven findings

**1. Searching the dictionary is worth a lot; the evolutionary operators are
not.** Both searches beat the best hand-designed superstructure — including
S3+ — on every task (+0.016 to +0.092, mean +0.058, run 3). But **evolution
never won on test in 11 comparisons across the three runs** (random wins 10,
ties 1). The gain comes from searching the dictionary at all —
not from mutation and selection. This is the documented failure mode of
evolutionary NAS (Li & Talwalkar, 2019), reproduced here.

**2. Evolution overfits validation exactly twice as hard as random search.**
With a single split, evolution's val−test gap is +0.020 vs random's +0.010: it
optimises harder against the validation set, so it captures more of the noise.
Three of four tasks show the inversion — evolution wins on validation and loses
on test. With 4-fold CV fitness the gap collapses to +0.004, confirming the
diagnosis was fitness noise, not a search-space problem. **Any future run must
use CV fitness.**

**3. The neutrality prediction is confirmed and measured** (and the `s2`
operator is the exception that proves it: toggling the learned branch changes
the phenotype 79–94 % of the time, because it bypasses the top-K filter). Because features are
pooled and then filtered to the top-K by F-score, adding a gene whose columns do
not beat the incumbents leaves the phenotype bit-for-bit unchanged. Measured:
**56–78 % of `add` mutations and 42–70 % of `duplicate` mutations changed
validation accuracy by exactly zero.** Duplication is nearly free, and the copy
can drift under `tweak` until it becomes competitive. This architecture supplies
its own neutral network — no NEAT-style speciation needed to protect innovation.

**4. The gradient reaches the genotype, is the best local move, and still does
not help — but it predicts dead ends perfectly.** See run 4: 44 % hit rate
versus 0 % for the moves it flags as inert, yet −0.011 end to end. Use it to
prune the catalogue, not to steer the search.

**5. Neither better moves nor more coverage is the constraint — the space is.**
Successive halving delivers a real 2.0× coverage gain at equal wall clock and
converts it into +0.007 accuracy. Random search at 461 genomes rediscovers the
champion it had at 162. The catalogue is exhausted; the only lever left is a
bigger one. See run 5.

**6. The article's protective gate is verified only for an informative learned
branch.** With a chance-level S2 the gate does not close and S3+ falls
significantly below the better branch on 2 of 4 tasks (10 seeds, CIs excluding
zero). And |g_s2| under-reports the branch's real contribution, because the gate
trades off exactly against the readout weights. See run 6.

**7. The search rediscovers the right physics, and it is readable.** On the
tonal task the champion is `fourier + fourier + scatter + fourier` — plain
Fourier, replicated by the duplication operator, is what the data wants. On both
chirp tasks the champions are `stft` variants at the window length that resolves
the sweep. The genotype is a legible statement about the signal, which the S2
learned unitary is not.

## What this means for the paper

The honest headline is **not** "evolution improves matched dictionaries". It is:

> The discrete choice of dictionary is worth far more than the community's focus
> on learned transforms suggests (+0.016 to +0.092 over the best hand-designed
> superstructure, S3+ included), *and* the obvious way to exploit that —
> evolutionary search —
> buys nothing over random sampling at equal compute, while doubling the
> validation-overfitting. The architecture's top-K selector makes structural
> mutations neutral by construction, which is elegant but also means the
> operators carry little information.

That is a publishable negative-plus-positive result and it is more defensible
than a marginal win would have been. Two routes forward:

- **Make the operators informative.** They are currently blind. Use the F-score
  provenance already computed to bias mutation toward gene families whose
  columns are actually being selected — an informed proposal distribution is the
  only thing that can beat random sampling in a space this flat.
- **Scale the search space until random search fails.** Run 5 settles this: 461
  random draws find the same champion as 162. With ≤ 6 genes over 8 families the
  space is exhausted, which is why every algorithmic refinement tried here —
  evolutionary operators, gradient-informed mutation, successive halving — lands
  within noise of plain random sampling. Growing the catalogue is a
  precondition for any further search work, not an afterthought.

## Files

| file | contents |
|---|---|
| `frft.py` | exact DFrFT + self-test |
| `genome.py` | gene families, genotype, mutation operators |
| `evolve.py` | evaluator (single-split and k-fold CV), regularized evolution, random search, baselines |
| `plot_evo.py` | figures |
| `res_s0.json`, `res_cv.json`, `res_s3plus.json` | full results including per-mutation deltas |
| `fig_evo_search.png`, `fig_evo_search_cv.png` | convergence + test-vs-val |
| `fig_evo_neutrality.png` | operator neutrality and mean effect |
| `fig_evo_vs_s3plus.png` | **run 3**: searched vs S1 / S2 / S3+ |
| `fig_operator_hitrate.png` | **run 4**: hit rate per mutation operator |
| `torch_families.py`, `gradtweak.py` | differentiable families + hybrid operator |
| `res_hybrid.json` | run 4 results |
| `evolve_sha.py`, `res_sha.json`, `fig_sha.png` | **run 5**: successive halving |
| `check_s3plus.py`, `res_s3check.json` | **run 6**: 10-seed paired S3+ check |
| `superstructures_edits.diff` | the three corrections applied to the article |

## Caveats

Single seed (0) for the split and the search. The task suite is synthetic 1-D
and is NOT the article's suite — the S3+ comparison here is indicative, not a
replication.
Before any of this goes in a paper it needs ≥5 seeds with error bars — the
differences reported here are of the same order as the seed-to-seed variation.
