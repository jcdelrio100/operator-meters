"""
Parameters and convergence: S1 / S2 / S3 vs the article-1 baselines (spiking LIF
network and a deep MLP on the raw signal).
  mode 'params'  : total trainable parameters per model across tasks (deterministic).
  mode 'conv'    : test-accuracy vs epoch + wall-clock on the two 1-D tasks.
  mode 'plot'    : English charts.
"""
import sys, os, json, time, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3
from snn_lif import SNN_LIF, n_params

JP = os.path.join(HERE, "paramcount.json"); JCV = os.path.join(HERE, "convergence.json")
K = 16

# ---------------- deterministic parameter formulas ----------------
def head_params(K, C, h=32):            # article-1 gated head (lin + one nonlinear block + gate)
    return (K*C+C) + (K*h+h+h*C+C) + 1
def s3_params(K, C, tparams, h=32):     # dict branch + gated NL + gated S2 branch + gates + transform
    return (K*C+C) + (K*h+h+h*C+C) + (K*C+C) + 2 + tparams
def snn_params(din, C, hid=64):
    return din*hid+hid + hid*C+C
def deep_params(din, C, h=64, layers=3):
    return (din*h+h) + (layers-1)*(h*h+h) + (h*C+C)

TASKS_PARAM = [("1D localized",128,(128,),4), ("hidden basis",128,(128,),4),
               ("texture 28x28",784,(28,28),4), ("text (topic)",1440,(60,24),4),
               ("video (motion)",3072,(12,16,16),4)]
def tparams(name, shape):               # learned-transform DOF: flat N^2 vs separable sum d_k^2
    return int(np.prod(shape))**2 if len(shape) == 1 else int(sum(int(d)**2 for d in shape))

def run_params():
    out = {}
    print(f"  {'task':16s} {'S1':>7s} {'S3':>8s} {'SNN':>9s} {'deepMLP':>9s}")
    for name, din, shape, C in TASKS_PARAM:
        s1 = head_params(K, C); s3 = s3_params(K, C, tparams(name, shape))
        snn = snn_params(din, C); dp = deep_params(din, C)
        out[name] = {"S1": s1, "S3": s3, "SNN": snn, "deepMLP": dp}
        print(f"  {name:16s} {s1:>7d} {s3:>8d} {snn:>9d} {dp:>9d}")
    json.dump(out, open(JP, "w"), indent=1); print("saved paramcount.json")

# ---------------- convergence (train, record test-acc vs epoch) ----------------
class GatedResidual(nn.Module):
    def __init__(self, Kd, C, h=32):
        super().__init__(); self.lin = nn.Linear(Kd, C)
        self.nl = nn.Sequential(nn.Linear(Kd, h), nn.ReLU(), nn.Linear(h, C)); self.g = nn.Parameter(torch.tensor(1.0))
    def forward(self, x): return self.lin(x) + self.g*self.nl(x)
class S3Head(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); self.lin_d = nn.Linear(Kd, C)
        self.nl = nn.Sequential(nn.Linear(Kd, h), nn.ReLU(), nn.Linear(h, C)); self.lin_s2 = nn.Linear(Kl, C)
        self.g_nl = nn.Parameter(torch.tensor(1.0)); self.g_s2 = nn.Parameter(torch.tensor(1.0))
    def forward(self, xd, xl): return self.lin_d(xd) + self.g_nl*self.nl(xd) + self.g_s2*self.lin_s2(xl)
class MLP(nn.Module):
    def __init__(self, din, C, h=64, layers=3):
        super().__init__(); L = [nn.Linear(din, h), nn.ReLU()]
        for _ in range(layers-1): L += [nn.Linear(h, h), nn.ReLU()]
        L += [nn.Linear(h, C)]; self.net = nn.Sequential(*L)
    def forward(self, x): return self.net(x)

def _acc(net, B, ye, s3=False, extra=None):
    net.eval()
    with torch.no_grad():
        o = net(B, extra) if s3 else net(B)
        return (o.argmax(1) == ye).float().mean().item()

def train_curve(kind, data, nc, ep, lr, rec=5):
    """Returns (curve[(epoch,acc)], final_acc, wall_seconds, params)."""
    lossf = nn.CrossEntropyLoss(); curve = []; t0 = time.time()
    if kind == "S1":
        A, ytr, B, yte = data; A = torch.tensor(A, dtype=torch.float32); B = torch.tensor(B, dtype=torch.float32)
        yt = torch.tensor(ytr); ye = torch.tensor(yte); net = GatedResidual(A.shape[1], nc)
        opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-4)
        for e in range(ep):
            net.train(); opt.zero_grad(); (lossf(net(A), yt)+0.25*net.g.abs()).backward(); opt.step()
            if e % rec == 0 or e == ep-1: curve.append((e, _acc(net, B, ye)))
        return curve, curve[-1][1], time.time()-t0, n_params(net)
    if kind == "S3":
        Ad, Al, ytr, Bd, Bl, yte = data
        Ad = torch.tensor(Ad, dtype=torch.float32); Al = torch.tensor(Al, dtype=torch.float32)
        Bd = torch.tensor(Bd, dtype=torch.float32); Bl = torch.tensor(Bl, dtype=torch.float32)
        yt = torch.tensor(ytr); ye = torch.tensor(yte); net = S3Head(Ad.shape[1], Al.shape[1], nc)
        opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-4)
        for e in range(ep):
            net.train(); opt.zero_grad(); (lossf(net(Ad, Al), yt)+0.25*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
            if e % rec == 0 or e == ep-1: curve.append((e, _acc(net, Bd, ye, s3=True, extra=Bl)))
        return curve, curve[-1][1], time.time()-t0, n_params(net)
    # raw-signal baselines
    Xtr, ytr, Xte, yte = data; Xt = torch.tensor(Xtr, dtype=torch.float32); Xe = torch.tensor(Xte, dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = SNN_LIF(Xt.shape[1], 64, nc) if kind == "SNN" else MLP(Xt.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-4)
    for e in range(ep):
        net.train(); opt.zero_grad(); lossf(net(Xt), yt).backward(); opt.step()
        if e % rec == 0 or e == ep-1: curve.append((e, _acc(net, Xe, ye)))
    return curve, curve[-1][1], time.time()-t0, n_params(net)

def run_conv():
    out = json.load(open(JCV)) if os.path.exists(JCV) else {}
    for name in ["1D localized (wavelet)", "hidden basis (rotated)"]:
        Xtr, ytr, Xte, yte, nc, reps = MM.load(name, 0)
        Ad, Bd, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
        Al, Bl = S3.learned_branch(name, Xtr, ytr, Xte, yte, nc, 0)
        raw_tr = (Xtr.reshape(len(Xtr), -1)); raw_te = (Xte.reshape(len(Xte), -1))
        mu, sd = raw_tr.mean(0), raw_tr.std(0)+1e-9; raw_tr = (raw_tr-mu)/sd; raw_te = (raw_te-mu)/sd
        res = {}
        shape = Xtr.shape[1:]
        for kind, data, ep, lr in [("S1", (Ad, ytr, Bd, yte), 300, 5e-3),
                                    ("S3", (Ad, Al, ytr, Bd, Bl, yte), 300, 5e-3),
                                    ("SNN", (raw_tr, ytr, raw_te, yte), 120, 2e-3),
                                    ("deepMLP", (raw_tr, ytr, raw_te, yte), 120, 2e-3)]:
            c, fa, wc, p = train_curve(kind, data, nc, ep, lr)
            if kind == "S3": p += tparams(name, shape)      # count the learned transform too
            res[kind] = {"curve": c, "final": fa, "sec": wc, "params": p}
            print(f"  {name:24s} {kind:8s} acc={fa:.3f} params={p} time={wc:.1f}s")
        out[name] = res; json.dump(out, open(JCV, "w"), indent=1)

def plot():
    if os.path.exists(JP):
        out = json.load(open(JP)); names = list(out); x = np.arange(len(names)); w = 0.2
        models = ["S1", "S3", "SNN", "deepMLP"]; cols = {"S1": "#555555", "S3": "#1f77b4", "SNN": "#9467bd", "deepMLP": "#e377c2"}
        fig, ax = plt.subplots(figsize=(10, 4.4))
        for k, mdl in enumerate(models):
            ax.bar(x+(k-1.5)*w, [out[t][mdl] for t in names], w, color=cols[mdl], label=mdl)
        ax.set_yscale("log"); ax.set_xticks(x); ax.set_xticklabels(names, rotation=18, ha="right", fontsize=8)
        ax.set_ylabel("Total trainable parameters (log)")
        ax.set_title("Model size: S1 / S3 vs spiking network (SNN) and deep MLP")
        ax.legend(fontsize=8); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
        plt.savefig(os.path.join(HERE, "paramcount.png"), dpi=130); print("saved paramcount.png")
    if os.path.exists(JCV):
        out = json.load(open(JCV)); names = list(out)
        fig, axs = plt.subplots(1, len(names), figsize=(5.2*len(names), 3.8), sharey=True)
        if len(names) == 1: axs = [axs]
        cols = {"S1": "#555555", "S3": "#1f77b4", "SNN": "#9467bd", "deepMLP": "#e377c2"}
        for ax, t in zip(axs, names):
            for mdl, r in out[t].items():
                e = [c[0] for c in r["curve"]]; a = [c[1] for c in r["curve"]]
                ax.plot(e, a, "-", color=cols[mdl], lw=1.6,
                        label=f"{mdl} ({r['params']}p, {r['sec']:.1f}s)")
            ax.set_title(t, fontsize=9); ax.set_xlabel("epoch"); ax.grid(alpha=0.3); ax.legend(fontsize=7)
        axs[0].set_ylabel("Test accuracy")
        fig.suptitle("Convergence (test accuracy vs epoch; legend: total params, wall-clock)")
        plt.tight_layout(); plt.savefig(os.path.join(HERE, "convergence.png"), dpi=130); print("saved convergence.png")

if __name__ == "__main__":
    m = sys.argv[1]
    if m == "params": run_params()
    elif m == "conv": run_conv()
    elif m == "plot": plot()
