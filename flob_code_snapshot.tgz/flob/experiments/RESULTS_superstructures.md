# Superstructure comparison — Pooled Dictionary (S1) vs Learned Transform (S2)

Same network as article 1 (the self-organizing `GatedResidual` head), same tasks, seeds (3), K=16, epochs, feature selection. Only the front-end differs:

- **S1 — Pooled dictionary:** fixed transforms {Fourier, DWT, |CWT|, scattering} → F-ANOVA top-K → head. Transform = 0 trainable params (algorithmic).
- **S2 — Learned transform:** Stage 1 learns a unitary U from scratch (no predefined transform, hybrid CE+sparsity); Stage 2 injects |Ux| → top-K → the SAME head. `S2 full` = free unitary; `S2 compact` = band-limited generator (band 8).

## Results (mean ± std over 3 seeds)

| task | S1 acc | S2 full acc | S2 compact acc | S1 params | S2 full params | S2 compact params |
|---|---|---|---|---|---|---|
| chirp_rate | 0.998 ± 0.002 | 0.999 ± 0.002 | 0.998 ± 0.003 | **68** | 16 452 | 2 172 |
| narrowband_tones | 1.000 ± 0.000 | 1.000 ± 0.000 | 1.000 ± 0.000 | **34** | 16 418 | 2 138 |
| **hidden_basis** | 0.660 ± 0.018 | **1.000 ± 0.000** | 0.959 ± 0.003 | 1 420 | 16 452 | 2 848 |

(`hidden_basis` = class separated by a few active coordinates in a fixed **random orthogonal basis**, unknown to the dictionary — not Fourier, not wavelet.)

Figures (English): `superstructure_accuracy.png`, `superstructure_convergence.png`, `superstructure_params.png`.

## Reading — the two superstructures are complementary

**Accuracy.** When the signal matches a transform the dictionary already contains, the two tie at ceiling: chirp_rate (via |CWT|) and narrowband (via Fourier) are ~1.000 for both. The learned transform wins **decisively only when no known transform fits**: on `hidden_basis`, S2 reaches 1.000 while the pooled dictionary is stuck at 0.66 — Fourier/wavelet cannot compact a signal that is sparse in an arbitrary rotated basis, but the learned transform rediscovers that basis.

**Convergence.** Where both can solve the task, the shared head converges almost identically fast (both hit ceiling in <20 epochs). On `hidden_basis` the dictionary head plateaus at 0.66 no matter how long it trains, while the learned front-end lets the same head reach 1.000. Caveat (honest): S2 pays an extra **Stage-1 cost** — training the transform (~200 epochs of the unitary) — which the head-convergence curves do not include.

**Total parameters.** This is where the dictionary shines: when it works, it works with a tiny head (34–68 params) because its transforms are free/algorithmic. The learned transform costs 16 k (full) or ~2 k (compact). On `hidden_basis` the dictionary head even bloats to 1 420 params (the gated blocks switch on trying to compensate) and still fails, whereas the **compact** learned transform reaches 0.959 at 2 848 params — a fraction of the full one.

## Conclusion (for the paper)

Neither superstructure dominates; they occupy complementary regimes. The **pooled dictionary** is the efficient choice when the discriminative structure matches a known transform: same accuracy at 1–2 orders of magnitude fewer parameters, because its transforms embed hand-designed prior knowledge for free. The **learned transform** is necessary — and wins outright — when the optimal representation is *not* any classical transform (`hidden_basis`): it discovers the basis from scratch, and even a compact (band-limited) learned transform captures most of the gain at far fewer parameters than the free unitary. The practical rule: use the dictionary when the matched transform is known; learn the transform when it is not.
