"""
P4: catalogue the transforms S3+ discovers, placed on the time-frequency LOCALIZATION plane
(the phase-space that indexes the x-let zoo) and matched to known archetypes.
Axes: time-spread (0=localized in time) x freq-spread (0=localized in frequency / tonal).
Archetypes: pure tone (tonal, global), impulse (time-localized, broadband), Gabor/wavelet
(jointly localized), noise (delocalized both). We train discovery-mode U on several sources,
take the top discriminative atoms, and drop them on this map -> a catalogue of discovered atoms.
"""
import os, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import disc_common as D
import superstructure_multimodal as MM
N = 128

def ts_fs(a): return D.time_spread(a), D.freq_spread(a)

# archetypes
t = np.arange(N)
arch = {}
arch["pure tone"] = np.cos(2 * np.pi * 10 * t / N)
imp = np.zeros(N); imp[N // 2] = 1.0; arch["impulse"] = imp
g = np.exp(-0.5 * ((t - N/2) / 6) ** 2); arch["Gabor"] = g * np.cos(2 * np.pi * 12 * t / N)
arch["wavelet"] = np.exp(-0.5 * ((t - N/2) / 4) ** 2) * np.cos(2 * np.pi * 20 * t / N)
arch["noise"] = np.random.default_rng(0).standard_normal(N)

# discovered atoms per source
SRC = [("Fourier", "1D global (Fourier)", dict(sparse=0.15, tv=0.3)),
       ("localized+loc", "1D localized (wavelet)", dict(sparse=0.15, tv=0.3, loc=0.6)),
       ("ECG", None, dict(sparse=0.15, tv=0.3)),
       ("hidden basis", "hidden basis (rotated)", dict(sparse=0.2, tv=0.1))]
disc = {}
for label, task, kw in SRC:
    if task is None: Xtr, ytr, Xte, yte, nc = D.ecg_task(seed=0)
    else: Xtr, ytr, Xte, yte, nc, _ = MM.load(task, 0)
    m, U, coeff, acc = D.discover(Xtr, ytr, Xte, yte, nc, epochs=160, warm=True, **kw)
    top = D.top_atoms(coeff, ytr, nc, k=2)
    disc[label] = [ts_fs(U[i]) for i in top]
    print(f"{label:16s} acc={acc:.3f}  (ts,fs) atoms:", [f"({a:.2f},{b:.2f})" for a, b in disc[label]])

fig, ax = plt.subplots(figsize=(8.6, 7))
for name, w in arch.items():
    ts, fs = ts_fs(w); ax.scatter(ts, fs, marker="*", s=260, color="#888", zorder=3)
    ax.annotate(name, (ts, fs), fontsize=9, color="#444", weight="bold", xytext=(6, 4), textcoords="offset points")
cols = {"Fourier": "#1f77b4", "localized+loc": "#2ca02c", "ECG": "#d62728", "hidden basis": "#9467bd"}
for label, pts in disc.items():
    P = np.array(pts); ax.scatter(P[:, 0], P[:, 1], s=90, color=cols[label], label=label, edgecolors="k", linewidths=0.5, zorder=4)
ax.set_xlabel("time-spread   (0 = localized in time  ->  1 = global)")
ax.set_ylabel("frequency-spread   (0 = tonal  ->  1 = broadband)")
ax.set_xlim(-0.05, 1.05); ax.set_ylim(-0.05, 1.05); ax.grid(alpha=0.3)
ax.set_title("P4 - catalogue of discovered transforms on the time-frequency localization plane\n"
             "(grey stars = classical archetypes; the x-let zoo lives in the lower/left; noise at top-right)", fontsize=10)
ax.legend(fontsize=9, loc="upper left", bbox_to_anchor=(0.30, 1.0), title="discovered (per source)", framealpha=0.95)
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), "p4_catalogue.png"), dpi=130)
print("saved p4_catalogue.png")
