"""
Exp B: is there an optimal anisotropy alpha per data type?
For each 2-D task, use the alpha-molecule directional bank (alpha_molecules.py) as the
transform feeding the shared head, sweep alpha in [0,1], report test accuracy vs alpha
(5 seeds). alpha=1 isotropic (wavelet-like), alpha=1/2 parabolic (curvelet/shearlet-like),
alpha->0 max-anisotropic (ridgelet-like). Optimal alpha per task is the argmax.
"""
import sys, os, json, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from alpha_molecules import alpha_feats, alpha_feats_video

SEEDS = 5
ALPHAS = [0.0, 0.25, 0.5, 0.75, 1.0]
TASKS = ["texture (28x28)", "image digits (real)", "video (motion)"]
JS = os.path.join(HERE, "alpha_sweep.json")

def feats(name, X, alpha):
    return alpha_feats_video(X, alpha=alpha) if name == "video (motion)" else alpha_feats(X, alpha=alpha)

def run():
    out = json.load(open(JS)) if os.path.exists(JS) else {}
    for name in TASKS:
        if name in out: print("skip", name); continue
        out[name] = {}
        for a in ALPHAS:
            accs = []
            for s in range(SEEDS):
                Xtr, ytr, Xte, yte, nc, _ = MM.load(name, s)
                A, B = MM.std_select(feats(name, Xtr, a), ytr, feats(name, Xte, a), nc)
                accs.append(MM.fit_head(A, ytr, B, yte, nc)[0])
            out[name][str(a)] = accs
            print(f"  {name:20s} alpha={a:.2f}  acc={np.mean(accs):.3f}+/-{np.std(accs):.3f}")
        json.dump(out, open(JS, "w"), indent=1)
    return out

def plot(out):
    fig, ax = plt.subplots(figsize=(8.5, 5))
    cols = {"texture (28x28)": "#2ca02c", "image digits (real)": "#1f77b4", "video (motion)": "#d62728"}
    for name in TASKS:
        if name not in out: continue
        m = [np.mean(out[name][str(a)]) for a in ALPHAS]; e = [np.std(out[name][str(a)]) for a in ALPHAS]
        ax.errorbar(ALPHAS, m, yerr=e, marker="o", capsize=3, color=cols[name], label=name)
        ia = int(np.argmax(m)); ax.scatter([ALPHAS[ia]], [m[ia]], s=160, facecolors="none",
                                            edgecolors=cols[name], linewidths=2, zorder=5)
        ax.annotate(f"  best alpha={ALPHAS[ia]:.2f}", (ALPHAS[ia], m[ia]), fontsize=8, color=cols[name])
    ax.axvline(0.5, ls=":", color="gray", lw=1); ax.text(0.5, ax.get_ylim()[0], " parabolic (shearlet/curvelet)", fontsize=7, color="gray", rotation=90, va="bottom")
    ax.set_xlabel(r"anisotropy $\alpha$  (1 = isotropic/wavelet, 1/2 = parabolic, 0 = ridgelet)")
    ax.set_ylabel("Test accuracy"); ax.set_title(f"alpha-molecule sweep: optimal anisotropy per task ({SEEDS} seeds)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(HERE, "alpha_sweep.png"), dpi=130); print("saved alpha_sweep.png")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "plot": plot(json.load(open(JS)))
    else: plot(run())
