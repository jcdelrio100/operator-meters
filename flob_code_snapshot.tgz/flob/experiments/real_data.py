"""
Real-data validation of S1 / S2 / S3+ on:
  - real handwritten digits (sklearn load_digits, 8x8 images, 10 classes)
  - a real ECG recording (scipy electrocardiogram, 360 Hz): QRS beat-detection task,
    labels derived from the signal's own R-peaks, train/test split by TIME (no leakage).
5 seeds; reports S1, S2 (warm), S3+ and the gate g_s2.
"""
import sys, os, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier
from structured_learned import MultilinearClassifier
from warmstart import dft_matrix, warm_start_flat, warm_start_separable, train_ws
SEEDS = 5

# ---------------- real ECG beat-detection task ----------------
_ECG = None
def _ecg():
    global _ECG
    if _ECG is None:
        from scipy.datasets import electrocardiogram
        e = electrocardiogram(); _ECG = (e - e.mean()) / (e.std() + 1e-9)
    return _ECG

def ecg_task(N=128, n_per_class=700, seed=0):
    from scipy.signal import find_peaks
    e = _ecg(); peaks, _ = find_peaks(e, height=1.0, distance=120)
    split = int(0.7 * len(e)); half = N // 2
    def build(pk, n):
        pk = [p for p in pk if half <= p < len(e) - half]
        mids = [(pk[i] + pk[i+1]) // 2 for i in range(len(pk) - 1)]
        mids = [m for m in mids if half <= m < len(e) - half]
        rng = np.random.default_rng(seed + (0 if n > 400 else 99)); X, y = [], []
        for _ in range(n):
            p = int(rng.choice(pk)) + int(rng.integers(-10, 11)); X.append(e[p-half:p+half]); y.append(1)
            m = int(rng.choice(mids)) + int(rng.integers(-10, 11)); X.append(e[m-half:m+half]); y.append(0)
        return np.array(X), np.array(y)
    Xtr, ytr = build(peaks[peaks < split], n_per_class)
    Xte, yte = build(peaks[peaks >= split], n_per_class // 2)
    zc = lambda X: (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-9)
    return zc(Xtr), ytr, zc(Xte), yte, 2

# ---------------- head ----------------
class S3plus(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); D=Kd+Kl; self.lin=nn.Linear(D,C); self.nl=nn.Sequential(nn.Linear(D,h),nn.ReLU(),nn.Linear(h,C))
        self.g_nl=nn.Parameter(torch.tensor(1.0)); self.g_s2=nn.Parameter(torch.tensor(1.0))
    def forward(self,xd,xl): x=torch.cat([xd,self.g_s2*xl],1); return self.lin(x)+self.g_nl*self.nl(x)
class GR(nn.Module):
    def __init__(self,K,C,h=32):
        super().__init__(); self.lin=nn.Linear(K,C); self.nl=nn.Sequential(nn.Linear(K,h),nn.ReLU(),nn.Linear(h,C)); self.g=nn.Parameter(torch.tensor(1.0))
    def forward(self,x): return self.lin(x)+self.g*self.nl(x)
def fit_head(A,ytr,B,yte,nc,ep=350):
    A=torch.tensor(A,dtype=torch.float32); B=torch.tensor(B,dtype=torch.float32); yt=torch.tensor(ytr); ye=torch.tensor(yte); net=GR(A.shape[1],nc)
    opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(A),yt)+0.25*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return (net(B).argmax(1)==ye).float().mean().item()
def fit_s3plus(Ad,Al,ytr,Bd,Bl,yte,nc,ep=350):
    Ad,Al,Bd,Bl=[torch.tensor(z,dtype=torch.float32) for z in (Ad,Al,Bd,Bl)]; yt=torch.tensor(ytr); ye=torch.tensor(yte)
    net=S3plus(Ad.shape[1],Al.shape[1],nc); opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(Ad,Al),yt)+0.25*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad(): return (net(Bd,Bl).argmax(1)==ye).float().mean().item(), float(net.g_s2.abs())

def s1_feats(Xtr,ytr,Xte,yte,nc,reps):
    P1=np.concatenate([f(Xtr) for f in reps.values()],1); P2=np.concatenate([f(Xte) for f in reps.values()],1)
    return MM.std_select(P1,ytr,P2,nc)
def learned_feats(kind,Xtr,ytr,Xte,yte,nc,seed):
    if kind=="flat":
        F1=Xtr.astype(np.float64); F2=Xte.astype(np.float64); m=UnitaryClassifier(F1.shape[1],nc,seed=seed); warm_start_flat(m.U,dft_matrix(F1.shape[1]))
    else:
        shape=Xtr.shape[1:]; mu=Xtr.mean(0,keepdims=True); sd=Xtr.std(0,keepdims=True)+1e-9
        F1=((Xtr-mu)/sd).astype(np.float64); F2=((Xte-mu)/sd).astype(np.float64); m=MultilinearClassifier(shape,nc,seed=seed)
        warm_start_separable(m.U,[dft_matrix(int(d)) for d in shape])
    train_ws(m,F1,ytr,F2,yte,epochs=150)
    with torch.no_grad(): Z1=m.features(torch.tensor(F1)).numpy(); Z2=m.features(torch.tensor(F2)).numpy()
    return MM.std_select(Z1,ytr,Z2,nc)

def fourier_mp(X):
    Xf=np.fft.rfft(X,axis=1); m=np.abs(Xf); p=np.angle(Xf); return np.concatenate([m,m*np.cos(p),m*np.sin(p)],1)
REPS1D={"Fourier":fourier_mp,"DWT":lambda X:MM.W.dwt_features(X,"db4"),"CWT":MM.W.cwt_mag}

# ---------------- real UCR datasets (bundled offline in pyts) ----------------
def _resplit(X, y, seed, frac=0.6):
    """Pool the (tiny) UCR train+test and re-split per seed for error bars."""
    rng = np.random.default_rng(seed); idx = rng.permutation(len(X)); X, y = X[idx], y[idx]
    n = int(frac * len(X)); nc = int(np.unique(y).size)
    zc = lambda A: (A - A.mean(1, keepdims=True)) / (A.std(1, keepdims=True) + 1e-9)
    return zc(X[:n]), y[:n], zc(X[n:]), y[n:], nc

def _ucr(loader, seed):
    Xtr, Xte, ytr, yte = loader(return_X_y=True)
    X = np.concatenate([Xtr, Xte], 0).astype(np.float64)
    y = np.concatenate([ytr, yte]); cls = np.unique(y); y = np.searchsorted(cls, y).astype(int)
    return _resplit(X, y, seed)

def gunpoint_task(seed=0):
    from pyts.datasets import load_gunpoint; return _ucr(load_gunpoint, seed)

def coffee_task(seed=0):
    from pyts.datasets import load_coffee; return _ucr(load_coffee, seed)

TASKS = {"real digits (8x8)": ("sep", None), "real ECG (beat detect)": ("flat", ecg_task),
         "real GunPoint (motion)": ("flat", gunpoint_task), "real Coffee (spectro)": ("flat", coffee_task)}
res={}
print(f"{SEEDS} seeds\n  {'dataset':24s} {'nc':>3s} {'S1':>13s} {'S2':>13s} {'S3+':>13s} {'g':>5s}")
for name,(kind,gen) in TASKS.items():
    S1,S2,S3,G=[],[],[],[]
    for s in range(SEEDS):
        if gen is None:
            from sklearn.datasets import load_digits
            d=load_digits(); X=(d.data.reshape(-1,8,8).astype(np.float64)); X=(X-X.mean())/(X.std()+1e-6); yv=d.target.astype(int)
            rng=np.random.default_rng(s); idx=rng.permutation(len(X)); X,yv=X[idx],yv[idx]; nsplit=1200
            Xtr,ytr,Xte,yte,nc=X[:nsplit],yv[:nsplit],X[nsplit:],yv[nsplit:],10; reps=MM.img_reps
        else:
            Xtr,ytr,Xte,yte,nc=gen(seed=s); reps=REPS1D
        Ad,Bd=s1_feats(Xtr,ytr,Xte,yte,nc,reps); S1.append(fit_head(Ad,ytr,Bd,yte,nc))
        Al,Bl=learned_feats(kind,Xtr,ytr,Xte,yte,nc,s); S2.append(fit_head(Al,ytr,Bl,yte,nc))
        acc,g=fit_s3plus(Ad,Al,ytr,Bd,Bl,yte,nc); S3.append(acc); G.append(g)
    res[name]={"S1":S1,"S2":S2,"S3+":S3,"g":float(np.mean(G))}
    ms=lambda v:f"{np.mean(v):.3f}+/-{np.std(v):.3f}"
    print(f"  {name:24s} {nc:>3d} {ms(S1):>13s} {ms(S2):>13s} {ms(S3):>13s} {np.mean(G):>5.2f}")

import json; json.dump(res, open(os.path.join(HERE,"real_data.json"),"w"), indent=1)
names=list(res); x=np.arange(len(names)); w=0.25
fig,ax=plt.subplots(figsize=(7,4.2)); m=lambda t,k:np.mean(res[t][k]); sd=lambda t,k:np.std(res[t][k])
ax.bar(x-w,[m(t,"S1") for t in names],w,yerr=[sd(t,"S1") for t in names],capsize=3,color="#555555",label="S1 dictionary")
ax.bar(x,[m(t,"S2") for t in names],w,yerr=[sd(t,"S2") for t in names],capsize=3,color="#d62728",label="S2 learned")
ax.bar(x+w,[m(t,"S3+") for t in names],w,yerr=[sd(t,"S3+") for t in names],capsize=3,color="#2ca02c",label="S3+ coupled")
for i,t in enumerate(names): ax.annotate(f"g={res[t]['g']:.2f}",(x[i]+w,m(t,"S3+")+sd(t,"S3+")),fontsize=7,ha="center",va="bottom",color="#2ca02c")
ax.set_xticks(x); ax.set_xticklabels(names,fontsize=9); ax.set_ylim(0.5,1.03); ax.set_ylabel("Test accuracy")
ax.set_title(f"Real-data validation (mean +/- std, {SEEDS} seeds)"); ax.legend(fontsize=8); ax.grid(axis="y",alpha=0.3)
plt.tight_layout(); plt.savefig(os.path.join(HERE,"real_data.png"),dpi=130); print("saved real_data.png, real_data.json")
