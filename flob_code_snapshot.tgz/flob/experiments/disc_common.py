"""Shared helpers for the transform-discovery suite (P1-P4)."""
import sys, os, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
from learned_transform import UnitaryClassifier, _tv, _concentration, atom_flatness
from warmstart import dft_matrix, warm_start_flat

# ---------- tasks ----------
_ECG = None
def ecg_task(N=128, n_per_class=700, seed=0):
    global _ECG
    from scipy.datasets import electrocardiogram
    from scipy.signal import find_peaks
    if _ECG is None:
        e = electrocardiogram(); _ECG = (e - e.mean()) / (e.std() + 1e-9)
    e = _ECG; peaks, _ = find_peaks(e, height=1.0, distance=120); split = int(0.7 * len(e)); half = N // 2
    def build(pk, n):
        pk = [p for p in pk if half <= p < len(e) - half]
        mids = [(pk[i] + pk[i + 1]) // 2 for i in range(len(pk) - 1)]; mids = [m for m in mids if half <= m < len(e) - half]
        rng = np.random.default_rng(seed + (0 if n > 400 else 99)); X, y = [], []
        for _ in range(n):
            p = int(rng.choice(pk)) + int(rng.integers(-10, 11)); X.append(e[p - half:p + half]); y.append(1)
            m = int(rng.choice(mids)) + int(rng.integers(-10, 11)); X.append(e[m - half:m + half]); y.append(0)
        return np.array(X), np.array(y)
    Xtr, ytr = build(peaks[peaks < split], n_per_class); Xte, yte = build(peaks[peaks >= split], n_per_class // 2)
    zc = lambda X: (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-9)
    return zc(Xtr), ytr, zc(Xte), yte, 2

def hidden_Q(N=128):
    fix = np.random.default_rng(12345); Q, _ = np.linalg.qr(fix.normal(size=(N, N))); return Q

# ---------- discovery trainer (CE + sparsity + TV smoothness + time-locality) ----------
def _locality(U):
    """circular spread of each atom's |.|^2 energy over time (periodic). 0=localized,1=spread."""
    N = U.shape[1]; p = (U.abs() ** 2); p = p / (p.sum(1, keepdim=True) + 1e-9)
    ang = 2 * np.pi * torch.arange(N, dtype=p.dtype) / N
    cx = (p * torch.cos(ang)).sum(1); cy = (p * torch.sin(ang)).sum(1)
    R = torch.sqrt(cx ** 2 + cy ** 2)
    return (1 - R).mean()

def discover(Xtr, ytr, Xte, yte, nc, epochs=150, lr=0.02, head_lr=0.01,
             sparse=0.0, tv=0.0, loc=0.0, warm=True, seed=0):
    d = Xtr.shape[1]; m = UnitaryClassifier(d, nc, seed=seed)
    if warm: warm_start_flat(m.U, dft_matrix(d))
    Xt = torch.tensor(Xtr.astype(np.float64)); yt = torch.tensor(ytr).long()
    Xe = torch.tensor(Xte.astype(np.float64)); ye = torch.tensor(yte).long()
    opt = torch.optim.Adam([{"params": list(m.U.parameters()), "lr": lr},
                            {"params": list(m.bn.parameters()) + list(m.head.parameters()), "lr": head_lr}],
                           weight_decay=1e-4)
    best = 0.0
    for _ in range(epochs):
        m.train(); opt.zero_grad(); feat = m.features(Xt); out = m.head(m.bn(feat))
        loss = Fn.cross_entropy(out, yt)
        if sparse > 0: loss = loss + sparse * _concentration(feat)
        if tv > 0:     loss = loss + tv * _tv(m.U.matrix())
        if loc > 0:    loss = loss + loc * _locality(m.U.matrix())
        loss.backward(); opt.step()
        m.eval()
        with torch.no_grad(): best = max(best, (m(Xe).argmax(1) == ye).float().mean().item())
    U = m.U.matrix().detach().numpy()
    with torch.no_grad(): coeff = m.features(Xt).numpy()
    return m, U, coeff, best

def fscore(F, y, nc):
    mu = F.mean(0); num = np.zeros(F.shape[1]); den = np.zeros(F.shape[1]) + 1e-9
    for c in range(nc):
        Fc = F[y == c]; num += len(Fc) * (Fc.mean(0) - mu) ** 2; den += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return num / den

def top_atoms(coeff, y, nc, k=3):
    return np.argsort(fscore(coeff, y, nc))[::-1][:k]

# ---------- atom metrics ----------
def time_spread(a):
    p = np.abs(a) ** 2; p = p / (p.sum() + 1e-12); N = len(a); ang = 2 * np.pi * np.arange(N) / N
    R = np.hypot((p * np.cos(ang)).sum(), (p * np.sin(ang)).sum()); return float(1 - R)

def freq_spread(a):
    s = np.abs(np.fft.fft(a)) ** 2; s = s / (s.sum() + 1e-12); N = len(a); ang = 2 * np.pi * np.arange(N) / N
    R = np.hypot((s * np.cos(ang)).sum(), (s * np.sin(ang)).sum()); return float(1 - R)
