"""
Warm-start figure (warmstart.png) WITH error bars, 5 seeds. Three bars per task:
  S1 pooled dictionary
  S2 learned, RANDOM init + task-trained end-to-end
  S2 learned, WARM-START from Fourier (DFT / per-axis DFT) + task-trained
Tasks: 1D localized & hidden basis (flat), video & texture (separable).
y-axis cut at 0.5 (bars near-saturated). Resumable via warmstart_fig.json.
"""
import sys, os, json, numpy as np, torch
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier
from structured_learned import MultilinearClassifier
from warmstart import dft_matrix, warm_start_flat, warm_start_separable, train_ws

SEEDS = 5
PLAN = [("1D localized (wavelet)", "flat"), ("hidden basis (rotated)", "flat"),
        ("video (motion)", "sep"), ("texture (28x28)", "sep")]
LABELS = {"1D localized (wavelet)": "1D localized", "hidden basis (rotated)": "hidden basis",
          "video (motion)": "video (motion)", "texture (28x28)": "texture (28x28)"}
JS = os.path.join(HERE, "warmstart_fig.json")

def head_of(m, F1, ytr, F2, yte, nc):
    with torch.no_grad():
        Z1 = m.features(torch.tensor(F1)).numpy(); Z2 = m.features(torch.tensor(F2)).numpy()
    A, B = MM.std_select(Z1, ytr, Z2, nc); return MM.fit_head(A, ytr, B, yte, nc)[0]

def learned(kind, Xtr, ytr, Xte, yte, nc, seed, warm):
    if kind == "flat":
        F1 = Xtr.astype(np.float64); F2 = Xte.astype(np.float64); d = F1.shape[1]
        m = UnitaryClassifier(d, nc, seed=seed)
        if warm: warm_start_flat(m.U, dft_matrix(d))
    else:
        shape = Xtr.shape[1:]; mu = Xtr.mean(0, keepdims=True); sd = Xtr.std(0, keepdims=True) + 1e-9
        F1 = ((Xtr - mu) / sd).astype(np.float64); F2 = ((Xte - mu) / sd).astype(np.float64)
        m = MultilinearClassifier(shape, nc, seed=seed)
        if warm: warm_start_separable(m.U, [dft_matrix(int(x)) for x in shape])
    train_ws(m, F1, ytr, F2, yte, epochs=150)
    return head_of(m, F1, ytr, F2, yte, nc)

def run():
    out = json.load(open(JS)) if os.path.exists(JS) else {}
    for name, kind in PLAN:
        if name in out: print("skip", name); continue
        S1, RND, WRM = [], [], []
        for s in range(SEEDS):
            Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
            A, B, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps); S1.append(MM.fit_head(A, ytr, B, yte, nc)[0])
            RND.append(learned(kind, Xtr, ytr, Xte, yte, nc, s, warm=False))
            WRM.append(learned(kind, Xtr, ytr, Xte, yte, nc, s, warm=True))
        out[name] = {"S1": S1, "rand": RND, "warm": WRM}
        json.dump(out, open(JS, "w"), indent=1)
        print(f"  {name:24s} S1={np.mean(S1):.3f} rand={np.mean(RND):.3f} warm={np.mean(WRM):.3f}")
    return out

def plot(out):
    names = [n for n, _ in PLAN if n in out]; x = np.arange(len(names)); w = 0.26
    m = lambda t, k: float(np.mean(out[t][k])); sd = lambda t, k: float(np.std(out[t][k]))
    Y0 = 0.5
    fig, ax = plt.subplots(figsize=(10, 4.8))
    ax.bar(x - w, [m(t, "S1") for t in names], w, yerr=[sd(t, "S1") for t in names], capsize=3,
           color="#555555", label="S1 Pooled dictionary")
    ax.bar(x,     [m(t, "rand") for t in names], w, yerr=[sd(t, "rand") for t in names], capsize=3,
           color="#d62728", label="S2 learned (random init + task)")
    ax.bar(x + w, [m(t, "warm") for t in names], w, yerr=[sd(t, "warm") for t in names], capsize=3,
           color="#2ca02c", label="S2 learned (warm-start from Fourier + task)")
    ax.set_xticks(x); ax.set_xticklabels([LABELS[n] for n in names], fontsize=9)
    ax.set_ylabel("Test accuracy"); ax.set_ylim(Y0, 1.02); ax.axhline(Y0, color="k", lw=0.6)
    ax.set_title(f"Warm-starting the learned transform from the fixed transform "
                 f"(mean +/- std, {SEEDS} seeds; y-axis starts at {Y0})")
    ax.legend(fontsize=8.5, loc="lower right"); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(HERE, "warmstart.png"), dpi=130); print("saved warmstart.png")

if __name__ == "__main__":
    out = run(); plot(out)
