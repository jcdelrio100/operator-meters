# Exp A (learned non-separable frame) & Exp B (alpha-molecule sweep) — 2-D tasks, 5 seeds

## Exp A — is S2's texture failure a *representation* limit, not expressivity? (`s2frame.png`)

We replace the single **separable unitary** S2 (Kronecker U_row⊗U_col, cannot represent a shear)
by a **learned overcomplete, non-separable directional frame**: a conv filter bank
(`ConvFrame`, M=40 kernels 7×7, non-separable 2-D kernels, overcomplete) trained end-to-end,
then |·| → average-pool → F-select K=16 → head — the *same* protocol as S2.

| task | S1 | S2 separable unitary | **S2frame** (non-sep., overcomplete) | S3+ (S1+S2frame) | conv params |
|---|---|---|---|---|---|
| texture (28×28)     | 0.960 | 0.896 | **1.000** | 0.992 (g=0.14) | 1 960 |
| image digits (real) | 0.935 | 0.864 | 0.871 | 0.953 (g=0.18) | 1 960 |
| video (motion)      | 1.000 | 0.992 | 0.957 | 1.000 (g=0.00) | 23 520 |

**Finding — confirmed.** On texture the separable unitary tops out at $0.896$, but the
**non-separable overcomplete frame reaches a perfect $1.000$** — at a *comparable* parameter count
($1\,960$ vs the unitary's ${\sim}1\,568$). So S2's deficit on directional texture is exactly what
theory predicted: a **representation limit** (one separable orthobasis cannot host a redundant,
non-separable, multi-orientation frame — the shear operation is literally outside a Kronecker
product), **not** a lack of expressivity or capacity. Give S2 the right *architecture* (overcomplete
+ non-separable) and it discovers the directional structure by itself.

**And it is specific.** The frame helps **only** where directionality is the missing ingredient:
on non-directional digits it does not improve ($0.871\approx0.864$), and on video (motion) the
spatial conv frame is actually *worse* than the separable unitary ($0.957$ vs $0.992$) — motion is
temporal, not spatial-directional, and the heavy 2-D frame ($23\,520$ params) overfits. This is the
honest, task-specific picture: non-separability buys the directional win and nothing else.

## Exp B — is there an optimal anisotropy alpha per task? (`alpha_sweep.png`)

We build the alpha-molecule directional bank (`alpha_molecules.py`) and sweep the anisotropy
$\alpha\in\{0,0.25,0.5,0.75,1\}$ ($\alpha{=}1$ isotropic/wavelet, $\alpha{=}1/2$ parabolic
curvelet/shearlet, $\alpha{\to}0$ ridgelet), each as the transform feeding the head.

| task | α=0 | α=0.25 | α=0.5 | α=0.75 | α=1.0 | best α |
|---|---|---|---|---|---|---|
| texture (28×28)     | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 | **any** (saturated) |
| image digits (real) | 0.857 | **0.892** | 0.879 | 0.883 | 0.890 | ≈0.25 (flat 0.25–1.0) |
| video (motion)      | 0.606 | **0.612** | 0.610 | 0.582 | 0.604 | ≈0.25 (shallow) |

**Finding — a real but *shallow* optimum.** A task-dependent best $\alpha$ exists, but it is weak in
these tasks: **texture is solved at every $\alpha$** (any oriented bank captures it — it is
$\alpha$-insensitive), and digits/video show only a mild peak around $\alpha\approx0.25$–$0.5$. The
one clear signal is that **maximal anisotropy $\alpha{=}0$ (ridgelet) is the worst** on the
non-directional digits ($0.857$) — over-committing to a single elongated orientation hurts when the
structure is not line-like. So the practical reading is *moderate anisotropy (α≈0.25–0.5) is a safe
default; extreme anisotropy only pays on genuinely line-like data*, which none of these three are
strongly. No dramatic per-task α selectivity emerged.

## Takeaway

Exp A is the clean, strong result: **the learned transform *can* match the directional dictionary
once it is allowed to be overcomplete and non-separable** — closing the texture gap that S2 (single
separable unitary) and even S1 left open, and confirming the limitation is representational. Exp B is
the honest, softer result: **the anisotropy exponent α has only a shallow task-dependent optimum
here** (moderate α safe; ridgelet-extreme α hurts non-directional data; directional texture is
α-insensitive). Both point to the same design lesson: what matters most for the learned branch is
*redundancy + non-separability + orientation*, more than the precise anisotropy schedule. Natural
next step: make **α (and the frame redundancy) learnable** so the branch selects its own anisotropy
per data source — the discovered-transform idea taken one level deeper.

(Method note: `ConvFrame` is a practical stand-in for a learned directional frame; `alpha_molecules`
is a frequency-domain α-parametrized directional bank, not a formal alpha-molecule system. The
qualitative conclusions — non-separability recovers texture; α-optimum is shallow — are what these
establish.)
