# Reading U & transform-discovery mode (`read_U_drift.png`, `transform_discovery.png`)

## Reading the learned transform (honest finding)

We extract the trained unitary $U=\exp(C-C^{\mathsf H})$ and inspect its most discriminative atoms
(rows), measuring novelty $=1-\max_j|\langle u,\mathrm{DFT}_j\rangle|$ (0 = pure Fourier mode) and drift
$\lVert U-U_0\rVert/\lVert U_0\rVert$.

- **Warm-start only:** on the Fourier task, novelty $=0.00$, drift $=0.00$ — $U$ is *exactly* the DFT
  (atoms are pure sinusoids).
- **After task-training (classification):** novelty $\approx0.75$, **drift $\approx1.43$** — $U$ moves far
  from Fourier to noisy, non-canonical atoms, *even though Fourier is the optimal transform here*.

**Why:** the classification objective is **under-constrained** — many unitaries separate the classes
equally, so nothing pins $U$ to a clean/recognizable basis. Classification fixes *performance*, not a
*transform*. Reading $U$ after classification alone gives a working but not-nameable rotation.

## Transform-discovery mode (the fix — and a first positive result)

Adding the objective the theory demands — coefficient sparsity ($\lVert Ux\rVert_1/\lVert Ux\rVert_2$) +
atom total-variation smoothness — makes reading $U$ yield **clean, reusable atoms** at no accuracy cost.

| task | cls acc | cls flatness | discovery acc | **discovery flatness** |
|---|---|---|---|---|
| 1D global (Fourier)    | 1.000 | 0.44 | 1.000 | **0.01** |
| 1D localized (wavelet) | 1.000 | 0.30 | 1.000 | **0.22** |
| real ECG (beat)        | 0.981 | 0.49 | 0.987 | **0.44** |

(flatness: 0 = clean tone, 1 = white noise; lower = cleaner/recognizable.)

- **Fourier is cleanly rediscovered:** flatness $0.44\to0.01$ — the discovery atom is a pure sinusoid —
  while accuracy stays $1.000$. This is the clean proof-of-concept: with the right regulariser, S3+ returns a
  *recognizable, reusable* transform, not a black-box front-end.
- On the localized (wavelet) and ECG tasks the atoms also get cleaner ($0.30\to0.22$, $0.49\to0.44$), less
  dramatically — ECG's discriminative structure is genuinely broadband (a QRS spike), so a "pure tone" is not
  the right target there; accuracy even improves slightly ($0.981\to0.987$).

## Status / next

This turns the paper's transform-discovery idea from pure future-work into a **demonstrated first step**:
the system can be run as a tool that *discovers a clean, data-specific transform* per source. Open threads
(project kept **open**, not closing): reconstruction/autoencoder objectives and locality priors for sharper
atoms; discovering genuinely *new* (non-Fourier/non-wavelet) clean transforms on ECG and rotated-basis data;
making anisotropy $\alpha$ and frame redundancy learnable (Exp B); and cataloguing the discovered atoms
against known bases and the $\alpha$-molecule continuum.
