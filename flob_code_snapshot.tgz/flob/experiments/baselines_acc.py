"""
Reference/placebo baselines for the S1/S2/S3 comparison: a spiking LIF network (SNN)
and a deep MLP, BOTH on the raw (flattened, z-scored) input -- i.e. no transform,
no discriminative selection. Appends per-task 5-seed accuracy lists ("SNN","deep")
into s3_results.json so the main comparison figure/table can show them as reference.
Resumable: skips a task if it already has both keys.
"""
import sys, os, json, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from snn_lif import SNN_LIF

SEEDS = 5
TASKS = ["1D global (Fourier)", "1D localized (wavelet)", "video (motion)", "texture (28x28)",
         "text (topic)", "XOR in hidden basis", "hidden basis (rotated)"]
JS = os.path.join(HERE, "s3_results.json")

class MLP(nn.Module):
    def __init__(self, din, C, h=64, layers=3):
        super().__init__()
        L = [nn.Linear(din, h), nn.ReLU()]
        for _ in range(layers - 2): L += [nn.Linear(h, h), nn.ReLU()]
        L += [nn.Linear(h, C)]; self.net = nn.Sequential(*L)
    def forward(self, x): return self.net(x)

def _flat(X):
    X = X.reshape(X.shape[0], -1).astype(np.float32)
    mu = X.mean(0, keepdims=True); sd = X.std(0, keepdims=True) + 1e-6
    return (X - mu) / sd

def fit(kind, Xtr, ytr, Xte, yte, nc, seed, ep=220, lr=2e-3):
    torch.manual_seed(seed)
    A = torch.tensor(_flat(Xtr)); B = torch.tensor(_flat(Xte)); yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = SNN_LIF(A.shape[1], 64, nc) if kind == "SNN" else MLP(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr, weight_decay=1e-4)
    for _ in range(ep):
        net.train(); opt.zero_grad(); Fn.cross_entropy(net(A), yt).backward(); opt.step()
    net.eval()
    with torch.no_grad(): return (net(B).argmax(1) == ye).float().mean().item()

def run(tasks=None):
    tasks = tasks or TASKS
    out = json.load(open(JS)) if os.path.exists(JS) else {}
    for name in tasks:
        if name in out and "SNN" in out[name] and "deep" in out[name]:
            print(f"skip {name} (done)"); continue
        SNN, DEEP = [], []
        for s in range(SEEDS):
            Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
            SNN.append(fit("SNN", Xtr, ytr, Xte, yte, nc, s))
            DEEP.append(fit("deep", Xtr, ytr, Xte, yte, nc, s))
        out.setdefault(name, {})["SNN"] = SNN; out[name]["deep"] = DEEP
        json.dump(out, open(JS, "w"), indent=1)
        print(f"  {name:24s} SNN={np.mean(SNN):.3f}+/-{np.std(SNN):.3f}  deep={np.mean(DEEP):.3f}+/-{np.std(DEEP):.3f}")

if __name__ == "__main__":
    run(sys.argv[1].split(";") if len(sys.argv) > 1 else None)
