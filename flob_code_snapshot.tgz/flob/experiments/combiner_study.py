"""
Is S3 leaving 'complementary' accuracy on the table? Measure the ORACLE UNION
(fraction correct by S1 OR S2 -- the ceiling of a per-sample selector) and test
better combiners than the single global L1 gate:
  - S3 additive gate (current)
  - CONCAT: one nonlinear head over [x_dict ; x_learn]  (32 feats, free combination)
  - MoE  : per-sample soft router between the two branches' logits
Report acc(S1), acc(S2), max, oracle-union, and each combiner. 2 seeds.
"""
import sys, os, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3

SEEDS = 2

class GR(nn.Module):
    def __init__(self, K, C, h=32):
        super().__init__(); self.lin = nn.Linear(K, C)
        self.nl = nn.Sequential(nn.Linear(K, h), nn.ReLU(), nn.Linear(h, C)); self.g = nn.Parameter(torch.tensor(1.0))
    def forward(self, x): return self.lin(x) + self.g*self.nl(x)

class MoE(nn.Module):
    """Per-sample soft router between a dict expert and a learned-branch expert."""
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__()
        self.ed = GR(Kd, C); self.el = nn.Linear(Kl, C)
        self.gate = nn.Sequential(nn.Linear(Kd+Kl, h), nn.ReLU(), nn.Linear(h, 2))
    def forward(self, xd, xl):
        w = torch.softmax(self.gate(torch.cat([xd, xl], 1)), 1)     # (B,2) per-sample
        return w[:, :1]*self.ed(xd) + w[:, 1:]*self.el(xl)

def _to(*a): return [torch.tensor(x, dtype=torch.float32) if x.dtype != np.int64 else torch.tensor(x) for x in a]

def fit_preds(A, ytr, B, yte, nc, ep=350):
    A = torch.tensor(A, dtype=torch.float32); B = torch.tensor(B, dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte); net = GR(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr=5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); (Fn.cross_entropy(net(A), yt)+0.25*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return net(B).argmax(1).numpy()

def fit_concat(Ad, Al, ytr, Bd, Bl, yte, nc, ep=350):
    A = torch.tensor(np.concatenate([Ad, Al], 1), dtype=torch.float32)
    B = torch.tensor(np.concatenate([Bd, Bl], 1), dtype=torch.float32)
    yt = torch.tensor(ytr); ye = torch.tensor(yte); net = GR(A.shape[1], nc)
    opt = torch.optim.Adam(net.parameters(), lr=5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); Fn.cross_entropy(net(A), yt).backward(); opt.step()
    with torch.no_grad(): return (net(B).argmax(1) == ye).float().mean().item()

def fit_moe(Ad, Al, ytr, Bd, Bl, yte, nc, ep=350):
    Ad, Al, Bd, Bl = _to(Ad, Al, Bd, Bl); yt = torch.tensor(ytr); ye = torch.tensor(yte)
    net = MoE(Ad.shape[1], Al.shape[1], nc); opt = torch.optim.Adam(net.parameters(), lr=5e-3, weight_decay=1e-4)
    for _ in range(ep):
        opt.zero_grad(); Fn.cross_entropy(net(Ad, Al), yt).backward(); opt.step()
    with torch.no_grad(): return (net(Bd, Bl).argmax(1) == ye).float().mean().item()

TASKS = ["1D localized (wavelet)", "texture (28x28)", "XOR in hidden basis", "hidden basis (rotated)"]
agg = {t: {k: [] for k in ("s1", "s2", "orU", "s3", "concat", "moe")} for t in TASKS}
for name in TASKS:
    for s in range(SEEDS):
        Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
        Ad, Bd, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
        Al, Bl = S3.learned_branch(name, Xtr, ytr, Xte, yte, nc, s)
        p1 = fit_preds(Ad, ytr, Bd, yte, nc); p2 = fit_preds(Al, ytr, Bl, yte, nc)
        c1 = (p1 == yte); c2 = (p2 == yte)
        agg[name]["s1"].append(c1.mean()); agg[name]["s2"].append(c2.mean())
        agg[name]["orU"].append((c1 | c2).mean())                          # oracle union (ceiling)
        agg[name]["s3"].append(S3.fit_s3(Ad, Al, ytr, Bd, Bl, yte, nc)[0])
        agg[name]["concat"].append(fit_concat(Ad, Al, ytr, Bd, Bl, yte, nc))
        agg[name]["moe"].append(fit_moe(Ad, Al, ytr, Bd, Bl, yte, nc))

print(f"{SEEDS} seeds\n  {'task':22s} {'S1':>6s} {'S2':>6s} {'max':>6s} {'oracleU':>8s} | {'S3 gate':>8s} {'concat':>7s} {'MoE':>6s}")
for t in TASKS:
    a = {k: np.mean(v) for k, v in agg[t].items()}
    mx = max(a["s1"], a["s2"])
    print(f"  {t:22s} {a['s1']:>6.3f} {a['s2']:>6.3f} {mx:>6.3f} {a['orU']:>8.3f} | "
          f"{a['s3']:>8.3f} {a['concat']:>7.3f} {a['moe']:>6.3f}")
