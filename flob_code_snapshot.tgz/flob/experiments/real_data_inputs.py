"""
Illustrative figure of the RAW INPUTS used in the real-data validation:
  - handwritten digits (8x8 images)   - ECG beat / non-beat windows
  - GunPoint (hand-motion series)      - Coffee (spectroscopy series)
All labels in English. Saves real_data_inputs.png
"""
import os, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib import gridspec
HERE = os.path.dirname(os.path.abspath(__file__))

fig = plt.figure(figsize=(11, 6.2))
gs = gridspec.GridSpec(2, 2, hspace=0.52, wspace=0.22,
                       left=0.06, right=0.985, top=0.82, bottom=0.08)
TITLE = 13; SUB = 10.5

# ---------------- 1) handwritten digits (8x8 images) ----------------
from sklearn.datasets import load_digits
d = load_digits()
gsd = gridspec.GridSpecFromSubplotSpec(2, 5, subplot_spec=gs[0, 0], wspace=0.12, hspace=0.12)
axtitle = fig.add_subplot(gs[0, 0]); axtitle.axis("off")
axtitle.set_title("Handwritten digits  —  sklearn load_digits\n1797 real 8x8 images, 10 classes",
                  fontsize=TITLE, fontweight="bold", pad=6)
firsts = [np.where(d.target == k)[0][0] for k in range(10)]
for i, idx in enumerate(firsts):
    ax = fig.add_subplot(gsd[i // 5, i % 5])
    ax.imshow(d.images[idx], cmap="gray_r", interpolation="nearest")
    ax.set_xticks([]); ax.set_yticks([]); ax.set_title(str(d.target[idx]), fontsize=8, pad=1)

# ---------------- 2) ECG beat / non-beat windows ----------------
from scipy.datasets import electrocardiogram
from scipy.signal import find_peaks
e = electrocardiogram(); e = (e - e.mean()) / (e.std() + 1e-9)
peaks, _ = find_peaks(e, height=1.0, distance=120)
N = 128; half = N // 2
mids = [(peaks[i] + peaks[i + 1]) // 2 for i in range(len(peaks) - 1)]
beat = e[peaks[5] - half:peaks[5] + half]
nonbeat = e[mids[5] - half:mids[5] + half]
ax = fig.add_subplot(gs[0, 1])
t = np.arange(N)
ax.plot(t, beat, color="#c0392b", lw=1.6, label="class 1: beat (R-peak centred)")
ax.plot(t, nonbeat, color="#2c3e50", lw=1.3, ls="--", label="class 0: non-beat (between beats)")
ax.set_title("ECG  —  scipy electrocardiogram (360 Hz)\nQRS beat-detection, 128-sample windows",
             fontsize=TITLE, fontweight="bold", pad=6)
ax.set_xlabel("sample", fontsize=SUB); ax.set_ylabel("norm. amplitude", fontsize=SUB)
ax.legend(fontsize=8, loc="upper right"); ax.grid(alpha=0.25)

# ---------------- 3) GunPoint (hand-motion series) ----------------
from pyts.datasets import load_gunpoint, load_coffee
Xtr, Xte, ytr, yte = load_gunpoint(return_X_y=True)
ax = fig.add_subplot(gs[1, 0])
i1 = np.where(ytr == 1)[0][0]; i2 = np.where(ytr == 2)[0][0]
ax.plot(Xtr[i1], color="#c0392b", lw=1.6, label="class: Gun")
ax.plot(Xtr[i2], color="#2c3e50", lw=1.6, ls="--", label="class: Point")
ax.set_title("GunPoint  —  UCR (pyts), real hand motion\nlength 150, 2 classes: gun-draw vs point",
             fontsize=TITLE, fontweight="bold", pad=6)
ax.set_xlabel("time", fontsize=SUB); ax.set_ylabel("hand x-position", fontsize=SUB)
ax.legend(fontsize=8.5, loc="best"); ax.grid(alpha=0.25)

# ---------------- 4) Coffee (spectroscopy series) ----------------
Xtr, Xte, ytr, yte = load_coffee(return_X_y=True)
ax = fig.add_subplot(gs[1, 1])
i1 = np.where(ytr == 0)[0][0]; i2 = np.where(ytr == 1)[0][0]
ax.plot(Xtr[i1], color="#c0392b", lw=1.6, label="class: Arabica")
ax.plot(Xtr[i2], color="#2c3e50", lw=1.6, ls="--", label="class: Robusta")
ax.set_title("Coffee  —  UCR (pyts), real FTIR spectroscopy\nlength 286, 2 classes: Arabica vs Robusta",
             fontsize=TITLE, fontweight="bold", pad=6)
ax.set_xlabel("wavenumber index", fontsize=SUB); ax.set_ylabel("absorbance", fontsize=SUB)
ax.legend(fontsize=8.5, loc="best"); ax.grid(alpha=0.25)

fig.suptitle("Real-data inputs used in the validation", fontsize=15, fontweight="bold", y=0.985)
out = os.path.join(HERE, "real_data_inputs.png")
plt.savefig(out, dpi=140); print("saved", out)
