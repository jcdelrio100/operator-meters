"""
Transform-DISCOVERY mode: make reading U yield a CLEAN, reusable transform.
Under classification alone U drifts to noise (non-canonical). Here we add the objective the
theory demands -- coefficient sparsity (concentration) + atom smoothness (TV) -- so the learned
atoms stay clean/recognizable while keeping accuracy. We compare, per task:
  cls   : classification only          (drifts to noisy atoms)
  clean : classification + sparsity+TV (clean, reusable atoms)
Metric: spectral flatness of the top discriminative atoms (0=pure/clean tone, 1=white noise)
and test accuracy. Tasks: Fourier, localized(wavelet), real ECG. Warm-started from DFT.
"""
import sys, os, numpy as np, torch
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier, train, atom_flatness
from warmstart import dft_matrix, warm_start_flat

_ECG = None
def ecg_task(N=128, n_per_class=700, seed=0):
    global _ECG
    from scipy.datasets import electrocardiogram
    from scipy.signal import find_peaks
    if _ECG is None:
        e = electrocardiogram(); _ECG = (e - e.mean()) / (e.std() + 1e-9)
    e = _ECG; peaks, _ = find_peaks(e, height=1.0, distance=120); split = int(0.7 * len(e)); half = N // 2
    def build(pk, n):
        pk = [p for p in pk if half <= p < len(e) - half]
        mids = [(pk[i] + pk[i + 1]) // 2 for i in range(len(pk) - 1)]; mids = [m for m in mids if half <= m < len(e) - half]
        rng = np.random.default_rng(seed + (0 if n > 400 else 99)); X, y = [], []
        for _ in range(n):
            p = int(rng.choice(pk)) + int(rng.integers(-10, 11)); X.append(e[p - half:p + half]); y.append(1)
            m = int(rng.choice(mids)) + int(rng.integers(-10, 11)); X.append(e[m - half:m + half]); y.append(0)
        return np.array(X), np.array(y)
    Xtr, ytr = build(peaks[peaks < split], n_per_class); Xte, yte = build(peaks[peaks >= split], n_per_class // 2)
    zc = lambda X: (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-9)
    return zc(Xtr), ytr, zc(Xte), yte, 2

def fscore(F, y, nc):
    mu = F.mean(0); num = np.zeros(F.shape[1]); den = np.zeros(F.shape[1]) + 1e-9
    for c in range(nc):
        Fc = F[y == c]; num += len(Fc) * (Fc.mean(0) - mu) ** 2; den += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return num / den

def fit(Xtr, ytr, Xte, yte, nc, mode, seed=0):
    d = Xtr.shape[1]; m = UnitaryClassifier(d, nc, seed=seed); warm_start_flat(m.U, dft_matrix(d))
    kw = dict(epochs=150) if mode == "cls" else dict(epochs=150, tv=0.3, sparse=0.15)
    acc = train(m, Xtr.astype(np.float64), ytr, Xte.astype(np.float64), yte, **kw)
    U = m.U.matrix().detach().numpy()
    with torch.no_grad(): coeff = m.features(torch.tensor(Xtr.astype(np.float64))).numpy()
    top = np.argsort(fscore(coeff, ytr, nc))[::-1][:3]
    flat = atom_flatness(U, top)
    return acc, U, top, flat

TASKS = [("1D global (Fourier)", "load"), ("1D localized (wavelet)", "load"), ("real ECG (beat)", "ecg")]
rows = []
fig, axes = plt.subplots(len(TASKS), 2, figsize=(11, 8.2))
for r, (name, kind) in enumerate(TASKS):
    if kind == "ecg": Xtr, ytr, Xte, yte, nc = ecg_task(seed=0)
    else: Xtr, ytr, Xte, yte, nc, _ = MM.load(name, 0)
    res = {}
    for mode in ("cls", "clean"):
        acc, U, top, flat = fit(Xtr, ytr, Xte, yte, nc, mode)
        res[mode] = (acc, U, top, flat)
    rows.append((name, res["cls"][0], res["cls"][3], res["clean"][0], res["clean"][3]))
    for cc, mode in enumerate(("cls", "clean")):
        acc, U, top, flat = res[mode]; ax = axes[r, cc]; a = U[top[0]]
        ax.plot(a.real, color="#1f77b4", lw=1.3); ax.plot(a.imag, color="#d62728", lw=0.8, alpha=0.6)
        ax.set_title(f"{'classification only' if mode=='cls' else 'discovery (sparsity+TV)'}: "
                     f"acc={acc:.3f}, flatness={flat:.2f}", fontsize=9)
        ax.set_xticks([]); ax.set_yticks([])
        if cc == 0: ax.set_ylabel(name, fontsize=9)
from matplotlib.lines import Line2D
fig.legend([Line2D([0], [0], color="#1f77b4", lw=1.5), Line2D([0], [0], color="#d62728", lw=1.5)],
           ["Real part of atom", "Imaginary part of atom"], loc="lower center", ncol=2, fontsize=10, frameon=True)
fig.suptitle("Transform-discovery mode: reading U's top atom, classification-only (left, noisy) vs "
             "regularized discovery (right, clean)\nflatness 0 = clean tone, 1 = white noise", fontsize=11)
plt.tight_layout(rect=[0, 0.04, 1, 0.94]); plt.savefig(os.path.join(HERE, "transform_discovery.png"), dpi=130)
print(f"{'task':22s} {'cls acc':>8s} {'cls flat':>9s} {'clean acc':>10s} {'clean flat':>11s}")
for n, ca, cf, la, lf in rows: print(f"{n:22s} {ca:>8.3f} {cf:>9.2f} {la:>10.3f} {lf:>11.2f}")
print("saved transform_discovery.png")
