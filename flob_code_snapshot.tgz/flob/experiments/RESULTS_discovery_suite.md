# Transform-discovery suite (P1-P4)

Four experiments probing how far "reading U" can go as a transform-creation tool. All warm-started from
DFT; discovery objective = CE + sparsity (||Ux||1/||Ux||2) + TV(atom smoothness) [+ time-locality].

## P1 - locality prior -> sharper, Gabor/wavelet-like atoms (`p1_locality.png`)
Adding a time-locality penalty steers the discovered atom along the time-frequency trade-off.

| task | mode | acc | flatness | time-spread |
|---|---|---|---|---|
| 1D localized | discovery | 1.000 | 0.33 | 0.71 |
| 1D localized | discovery+loc | 0.998 | 0.45 | **0.16** |
| 1D Fourier | discovery | 1.000 | 0.08 | 0.59 |
| 1D Fourier | discovery+loc | 1.000 | 0.01 | 0.27 |

On the localized task the top atom's time-spread collapses 0.88(cls)→0.16 = a clean **wavelet/Gabor-like
localized** atom, at unchanged accuracy. On Fourier, +loc yields a localized **wave-packet (Gabor)** (flat
0.01). The prior lets you place the discovered transform where you want on the Heisenberg trade-off.

## P2 - rediscovering a genuinely NEW (non-Fourier) transform (`p2_rediscover.png`)
Hidden-basis task: data sparse in a planted random orthogonal basis Q (not Fourier/wavelet).

| mode | acc | align → planted Q | align → DFT |
|---|---|---|---|
| classification only | 1.000 | 0.30 | 0.50 |
| **discovery** | 1.000 | **0.64** | 0.22 |

Discovery **rediscovers the planted basis** (alignment to Q doubles, alignment to Fourier collapses);
classification alone does not. On real ECG the discovered atom is novel vs Fourier (novelty 0.57), a
data-specific transform (though broadband, not a clean tone).

## P3 - self-selected anisotropy of a free frame (`p3_anisotropy.png`)
Train the free overcomplete non-separable conv frame per source; read the kernels' aspect ratio
rho=sqrt(l2/l1) (1=isotropic, 0=elongated).

| task | mean rho | median |
|---|---|---|
| texture | 0.854 | 0.869 |
| digits | 0.854 | 0.843 |
| video | 0.914 | 0.919 |

Only a **weak** per-source preference: texture has a heavier anisotropic tail (down to 0.65), video is the
most isotropic, but means barely differ. Echoes Exp B's shallow alpha optimum — anisotropy is not a strong
discriminator here.

## P4 - catalogue on the time-frequency localization plane (`p4_catalogue.png`)
Place discovered atoms as (time-spread, freq-spread) points among classical archetypes (tone, impulse,
Gabor, wavelet, noise).

- **localized+loc** → near impulse/wavelet (time-localized, broadband): (0.12, 0.85).
- **Fourier** → toward the tonal axis: (~0.45, ~0.40).
- **ECG** → global/broadband, spread out.
- **hidden basis** → sits at the **noise** corner (0.88, 0.96): delocalized in BOTH time and frequency.

The x-let archetypes occupy the lower-left of the plane; the hidden-basis discovery lands at the noise
corner — a meaningful discriminative transform with NO time-frequency locality, i.e. **outside the entire
x-let zoo**. That is exactly the regime where a learned transform (not any fixed x-let) is required, closing
the loop with the break-even story.

## Takeaway
The system works as a transform-discovery tool: with the right regulariser it rediscovers a planted
non-Fourier basis (P2), emits clean Gabor/wavelet-like atoms on demand (P1), and its discoveries can be
catalogued against the classical zoo (P4) — including cases that provably fall outside it. The one soft
result is P3 (anisotropy is weakly selected), consistent with Exp B. Open next steps: reconstruction/
autoencoder objectives, explicit learnable-alpha Gabor frames, and discovery on more real sources.
