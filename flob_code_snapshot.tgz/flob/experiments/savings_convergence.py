"""
Parameter savings vs standard technology (spiking SNN, deep MLP) and convergence
speed-up, for S1 / S3+ (static and gate-aware effective).
  mode 'params' : parameter table + savings ratios (static and effective).
  mode 'conv'   : convergence (epochs-to-95%% + wall-clock) for S1/S3+/SNN/deep; speed-up.
  mode 'plot'   : English charts.
"""
import sys, os, json, time, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3
from snn_lif import SNN_LIF, n_params
JP = os.path.join(HERE, "savings.json"); JC = os.path.join(HERE, "conv_plus.json"); K = 16

# gate values measured in the 5-seed S3+ study (mean g_s2)
GATE = {"1D localized": 0.00, "hidden basis": 0.30, "texture 28x28": 0.09,
        "text (topic)": 0.00, "video (motion)": 0.00}
TASKS = [("1D localized",128,(128,),4), ("hidden basis",128,(128,),4),
         ("texture 28x28",784,(28,28),4), ("text (topic)",1440,(60,24),4),
         ("video (motion)",3072,(12,16,16),4)]

def head_dict(C, h=32):  return (K*C+C) + (K*h+h+h*C+C) + 1          # S1 gated head (K inputs)
def head_joint(C, h=32): return (2*K*C+C) + (2*K*h+h+h*C+C) + 2      # S3+ joint head (2K inputs) + 2 gates
def tparams(shape):      return int(np.prod(shape))**2 if len(shape)==1 else int(sum(int(d)**2 for d in shape))
def snn_p(din, C, hid=64): return din*hid+hid + hid*C+C
def deep_p(din, C, h=64, layers=3): return (din*h+h) + (layers-1)*(h*h+h) + (h*C+C)

def run_params():
    out = {}
    print(f"  {'task':14s} {'S1':>6s} {'S3+static':>10s} {'S3+eff':>7s} {'SNN':>8s} {'deep':>8s} | "
          f"{'saveVSsnn':>9s} {'saveVSdeep':>10s}")
    for name, din, shape, C in TASKS:
        s1 = head_dict(C); s3p = head_joint(C) + tparams(shape)
        eff = s1 if GATE.get(name, 1.0) <= 0.05 else s3p                # gate closed -> prune S2
        snn = snn_p(din, C); dp = deep_p(din, C)
        out[name] = {"S1": s1, "S3+static": s3p, "S3+eff": eff, "SNN": snn, "deep": dp,
                     "save_snn": snn/eff, "save_deep": dp/eff}
        print(f"  {name:14s} {s1:>6d} {s3p:>10d} {eff:>7d} {snn:>8d} {dp:>8d} | "
              f"{snn/eff:>8.0f}x {dp/eff:>9.0f}x")
    json.dump(out, open(JP, "w"), indent=1); print("saved savings.json")

# ---------------- convergence ----------------
class GR(nn.Module):
    def __init__(self, K, C, h=32):
        super().__init__(); self.lin = nn.Linear(K, C); self.nl = nn.Sequential(nn.Linear(K, h), nn.ReLU(), nn.Linear(h, C)); self.g = nn.Parameter(torch.tensor(1.0))
    def forward(self, x): return self.lin(x) + self.g*self.nl(x)
class S3plus(nn.Module):
    def __init__(self, Kd, Kl, C, h=32):
        super().__init__(); D = Kd+Kl; self.lin = nn.Linear(D, C); self.nl = nn.Sequential(nn.Linear(D, h), nn.ReLU(), nn.Linear(h, C))
        self.g_nl = nn.Parameter(torch.tensor(1.0)); self.g_s2 = nn.Parameter(torch.tensor(1.0))
    def forward(self, xd, xl): x = torch.cat([xd, self.g_s2*xl], 1); return self.lin(x)+self.g_nl*self.nl(x)
class MLP(nn.Module):
    def __init__(self, din, C, h=64, layers=3):
        super().__init__(); L=[nn.Linear(din,h),nn.ReLU()]
        for _ in range(layers-1): L+=[nn.Linear(h,h),nn.ReLU()]
        L+=[nn.Linear(h,C)]; self.net=nn.Sequential(*L)
    def forward(self, x): return self.net(x)

def e95(curve, final):
    thr = 0.95*final
    for e, a in curve:
        if a >= thr: return e
    return curve[-1][0]

def run_conv():
    out = {}
    for name in ["1D localized (wavelet)", "hidden basis (rotated)"]:
        Xtr, ytr, Xte, yte, nc, reps = MM.load(name, 0)
        Ad, Bd, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps)
        Al, Bl = S3.learned_branch(name, Xtr, ytr, Xte, yte, nc, 0)
        raw_tr = Xtr.reshape(len(Xtr), -1); raw_te = Xte.reshape(len(Xte), -1)
        mu, sd = raw_tr.mean(0), raw_tr.std(0)+1e-9; raw_tr = (raw_tr-mu)/sd; raw_te = (raw_te-mu)/sd
        res = {}
        specs = [("S1", GR, (Ad, Bd), 300, 5e-3), ("S3+", S3plus, (Ad, Al, Bd, Bl), 300, 5e-3),
                 ("SNN", SNN_LIF, (raw_tr, raw_te), 120, 2e-3), ("deep", MLP, (raw_tr, raw_te), 120, 2e-3)]
        yt = torch.tensor(ytr); ye = torch.tensor(yte)
        for kind, cls, data, ep, lr in specs:
            t0 = time.time(); curve = []
            if kind == "S1":
                A = torch.tensor(data[0], dtype=torch.float32); B = torch.tensor(data[1], dtype=torch.float32); net = GR(A.shape[1], nc)
                opt = torch.optim.Adam(net.parameters(), lr, weight_decay=1e-4)
                for e in range(ep):
                    opt.zero_grad(); (Fn.cross_entropy(net(A), yt)+0.25*net.g.abs()).backward(); opt.step()
                    if e % 5 == 0 or e == ep-1:
                        with torch.no_grad(): curve.append((e, (net(B).argmax(1)==ye).float().mean().item()))
                p = n_params(net)
            elif kind == "S3+":
                Ad_, Al_, Bd_, Bl_ = [torch.tensor(z, dtype=torch.float32) for z in data]; net = S3plus(Ad_.shape[1], Al_.shape[1], nc)
                opt = torch.optim.Adam(net.parameters(), lr, weight_decay=1e-4)
                for e in range(ep):
                    opt.zero_grad(); (Fn.cross_entropy(net(Ad_, Al_), yt)+0.25*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
                    if e % 5 == 0 or e == ep-1:
                        with torch.no_grad(): curve.append((e, (net(Bd_, Bl_).argmax(1)==ye).float().mean().item()))
                p = n_params(net) + tparams(Xtr.shape[1:])
            else:
                A = torch.tensor(data[0], dtype=torch.float32); B = torch.tensor(data[1], dtype=torch.float32)
                net = SNN_LIF(A.shape[1], 64, nc) if kind == "SNN" else MLP(A.shape[1], nc)
                opt = torch.optim.Adam(net.parameters(), lr, weight_decay=1e-4)
                for e in range(ep):
                    opt.zero_grad(); Fn.cross_entropy(net(A), yt).backward(); opt.step()
                    if e % 5 == 0 or e == ep-1:
                        with torch.no_grad(): curve.append((e, (net(B).argmax(1)==ye).float().mean().item()))
                p = n_params(net)
            wc = time.time()-t0; fa = curve[-1][1]
            res[kind] = {"curve": curve, "final": fa, "sec": wc, "params": p, "e95": e95(curve, fa)}
            print(f"  {name:24s} {kind:5s} acc={fa:.3f} e95={res[kind]['e95']:>3d}ep {wc:.2f}s params={p}")
        # speed-up vs SNN (epochs & wall-clock to 95%)
        for base in ("SNN", "deep"):
            for ours in ("S1", "S3+"):
                res[f"{ours}_vs_{base}_ep"] = res[base]["e95"]/max(res[ours]["e95"], 1)
                res[f"{ours}_vs_{base}_wc"] = res[base]["sec"]/max(res[ours]["sec"], 1e-6)
        out[name] = res; json.dump(out, open(JC, "w"), indent=1)

def plot():
    if os.path.exists(JP):
        out = json.load(open(JP)); names = list(out); x = np.arange(len(names)); w = 0.16
        models = [("S1","#555555"),("S3+static","#2ca02c"),("S3+eff","#98df8a"),("SNN","#9467bd"),("deep","#e377c2")]
        fig, ax = plt.subplots(figsize=(11, 4.4))
        for k,(mdl,c) in enumerate(models):
            ax.bar(x+(k-2)*w, [out[t][mdl] for t in names], w, color=c, label=mdl)
        ax.set_yscale("log"); ax.set_xticks(x); ax.set_xticklabels(names, rotation=15, ha="right", fontsize=8)
        ax.set_ylabel("Parameters (log)"); ax.set_title("Parameter savings: S1 / S3+ (static & gate-effective) vs SNN and deep MLP")
        ax.legend(fontsize=8, ncol=5); ax.grid(axis="y", alpha=0.3); plt.tight_layout()
        plt.savefig(os.path.join(HERE, "savings.png"), dpi=130); print("saved savings.png")
    if os.path.exists(JC):
        out = json.load(open(JC)); names = list(out)
        fig, axs = plt.subplots(1, len(names), figsize=(5.4*len(names), 3.8), sharey=True)
        if len(names) == 1: axs = [axs]
        cols = {"S1":"#555555","S3+":"#2ca02c","SNN":"#9467bd","deep":"#e377c2"}
        for ax, t in zip(axs, names):
            for mdl in ("S1","S3+","SNN","deep"):
                r = out[t][mdl]; e=[c[0] for c in r["curve"]]; a=[c[1] for c in r["curve"]]
                ax.plot(e, a, "-", color=cols[mdl], lw=1.6, label=f"{mdl} ({r['params']}p, {r['sec']:.1f}s, e95={r['e95']})")
            ax.set_title(t, fontsize=9); ax.set_xlabel("epoch"); ax.grid(alpha=0.3); ax.legend(fontsize=6.5)
        axs[0].set_ylabel("Test accuracy")
        fig.suptitle("Convergence & speed-up (legend: params, wall-clock, epochs-to-95%)")
        plt.tight_layout(); plt.savefig(os.path.join(HERE, "conv_plus.png"), dpi=130); print("saved conv_plus.png")

if __name__ == "__main__":
    m = sys.argv[1]
    (run_params if m=="params" else run_conv if m=="conv" else plot)()
