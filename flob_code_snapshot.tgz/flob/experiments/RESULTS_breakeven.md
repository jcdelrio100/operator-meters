# Break-even across modalities — Pooled Dictionary (S1) vs Learned Transform (S2)

Same shared head (article-1 `GatedResidual`), same conditions (K=16, 2 seeds, epochs). S1 = modality-appropriate fixed dictionary; S2 = unitary learned from scratch on the flattened input (PCA-reduced to ≤128 dims only when larger, for compute — a scalability step, not a predefined transform). Tasks span the article-1 modalities plus two non-classical tasks.

## Results, sorted by (S2 − S1)

| task | S1 acc | S2 acc | Δ (S2−S1) | S1 params | S2 params |
|---|---|---|---|---|---|
| text (topic) | 0.988 | 0.581 | **−0.41** | 68 | 16 452 |
| video (motion) | 1.000 | 0.711 | **−0.29** | 68 | 17 804 |
| 1D localized (wavelet) | 0.998 | 0.801 | −0.20 | 68 | 17 466 |
| texture (28×28) | 0.953 | 0.926 | −0.03 | 744 | 17 128 |
| image digits (real 8×8) | 0.940 | 0.930 | −0.01 | 1 918 | 6 014 |
| 1D global (Fourier) | 1.000 | 0.998 | −0.00 | 68 | 16 790 |
| XOR in hidden basis | 0.910 | 1.000 | **+0.09** | 34 | 16 418 |
| hidden basis (rotated) | 0.675 | 1.000 | **+0.33** | 1 082 | 16 452 |

## The break-even

There is a clean frontier. On the left, the **pooled dictionary wins decisively** on modalities whose structure matches a classical transform — text (token frequency), video (spatio-temporal Fourier), localized wavelets. In the middle sits a **crossover cluster** (texture, real digits, global-Fourier) where the two essentially tie. On the right, the **learned transform wins outright** only on the two tasks whose discriminative structure lives in a non-classical basis: an arbitrary hidden rotation (Δ +0.33) and a hidden-basis XOR (Δ +0.09).

So the break-even is the boundary between **classical-transform-expressible** structure and **arbitrary-rotation / hidden-basis** structure. Below it, hand-designed transforms embed the right prior and win at 1–2 orders of magnitude fewer parameters (S1 uses 34–2 000 params, S2 6 000–18 000). Above it, no classical transform fits and only the learned transform recovers the basis.

## Honest caveats

- **S2 is handicapped on structured modalities.** It operates on a *flattened* (and PCA-reduced) vector with a single global unitary, so it cannot exploit the 2-D/3-D/sequential structure that the dictionary's Fourier-2D/3-D and bag-of-words use directly. A structure-aware learned transform (separable / convolutional-unitary) would likely narrow the gap on video/text/images — a clear next step.
- The two tasks where S2 wins are synthetic by construction (a fixed random rotation). They demonstrate the regime where a learned transform is *necessary*, but a real-world dataset with genuinely non-classical structure would be the honest confirmation.
- S2 also carries the extra Stage-1 cost of learning the transform, not counted in the head-convergence curves.

## Conclusion for the paper

The learned transform is **not** a general replacement for the pooled dictionary: across realistic modalities (spectral, image, text, video) the dictionary wins or ties, cheaply, because classical transforms already match those signals. The learned transform earns its keep in a **specific, characterizable regime** — when the optimal representation is an arbitrary basis no classical transform exposes. The contribution is locating that break-even, not claiming the learned transform dominates.
