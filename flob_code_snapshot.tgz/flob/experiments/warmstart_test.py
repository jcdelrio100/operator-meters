"""
Warm-start test: initialize the learned transform AT the fixed transform (DFT), then
train end-to-end for the task. Question: does it then match/beat the dictionary where
the random-init learned transform lost?

  S1 union         : pooled dictionary
  best single fixed: best single transform alone
  S2 warm@0        : warm-started learned transform, BEFORE training (sanity ~ Fourier)
  S2 warm+task     : warm-started, then trained end-to-end (no weight-decay on U)

1-D tasks: flat unitary warm-started from DFT_128.
Structured tasks: separable unitary warm-started from per-axis DFTs (= Fourier-2D/3D).
"""
import sys, os, numpy as np, torch
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier
from structured_learned import MultilinearClassifier
from warmstart import dft_matrix, warm_start_flat, warm_start_separable, train_ws

SEEDS = 2


def best_single(Xtr, ytr, Xte, yte, nc, reps):
    b = 0.0; who = ""
    for name, fn in reps.items():
        A, B = MM.std_select(fn(Xtr), ytr, fn(Xte), nc)
        a = MM.fit_head(A, ytr, B, yte, nc)[0]
        if a > b: b, who = a, name
    return b, who


def head_from_model(m, Xtr, ytr, Xte, yte, nc):
    with torch.no_grad():
        Z1 = m.features(torch.tensor(Xtr)).numpy(); Z2 = m.features(torch.tensor(Xte)).numpy()
    A, B = MM.std_select(Z1, ytr, Z2, nc)
    return MM.fit_head(A, ytr, B, yte, nc)[0]


def warm_flat(Xtr, ytr, Xte, yte, nc, seed):
    F1 = Xtr.astype(np.float64); F2 = Xte.astype(np.float64)          # 1-D, d=128, no PCA
    d = F1.shape[1]; m = UnitaryClassifier(d, nc, seed=seed)
    warm_start_flat(m.U, dft_matrix(d))
    a0 = head_from_model(m, F1, ytr, F2, yte, nc)                     # before training (~Fourier)
    train_ws(m, F1, ytr, F2, yte, epochs=200)
    a1 = head_from_model(m, F1, ytr, F2, yte, nc)                     # after task training
    return a0, a1


def warm_sep(Xtr, ytr, Xte, yte, nc, seed):
    shape = Xtr.shape[1:]
    mu = Xtr.mean(0, keepdims=True); sd = Xtr.std(0, keepdims=True) + 1e-9
    F1 = ((Xtr - mu) / sd).astype(np.float64); F2 = ((Xte - mu) / sd).astype(np.float64)
    m = MultilinearClassifier(shape, nc, seed=seed)
    warm_start_separable(m.U, [dft_matrix(int(d)) for d in shape])
    a0 = head_from_model(m, F1, ytr, F2, yte, nc)
    train_ws(m, F1, ytr, F2, yte, epochs=200)
    a1 = head_from_model(m, F1, ytr, F2, yte, nc)
    return a0, a1


PLAN = [("1D localized (wavelet)", "flat"), ("hidden basis (rotated)", "flat"),
        ("video (motion)", "sep"), ("texture (28x28)", "sep")]
print(f"{SEEDS} seeds\n")
print(f"  {'task':24s} {'S1 union':>9s} {'best single':>15s} {'warm@0':>8s} {'warm+task':>10s}")
for name, kind in PLAN:
    U, BS, W0, W1 = [], [], [], []
    for s in range(SEEDS):
        Xtr, ytr, Xte, yte, nc, reps = MM.load(name, s)
        A, B, _ = MM.s1_feats(Xtr, ytr, Xte, yte, nc, reps); U.append(MM.fit_head(A, ytr, B, yte, nc)[0])
        bs, who = best_single(Xtr, ytr, Xte, yte, nc, reps); BS.append(bs)
        a0, a1 = (warm_flat if kind == "flat" else warm_sep)(Xtr, ytr, Xte, yte, nc, s)
        W0.append(a0); W1.append(a1)
    print(f"  {name:24s} {np.mean(U):>9.3f} {np.mean(BS):>10.3f}({who[:4]}) "
          f"{np.mean(W0):>8.3f} {np.mean(W1):>10.3f}")
