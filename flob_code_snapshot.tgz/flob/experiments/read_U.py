"""
"Reading" the learned unitary U to see WHAT transform S3+ discovered.
For three 1-D tasks we warm-start U at the DFT, task-train it, then extract the matrix
U = matrix_exp(C - C^H) and inspect its most DISCRIMINATIVE atoms (rows), the ones the
F-selector keeps. We plot those atoms as waveforms and their frequency content, and
measure a 'novelty' = 1 - max_j |<atom, DFT_j>| (0 = still a pure Fourier mode, 1 = a
genuinely new basis vector). Classical tasks should stay Fourier-like (low novelty);
the rotated hidden-basis and real ECG should depart (high novelty) = a discovered transform.
"""
import sys, os, numpy as np, torch
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
from learned_transform import UnitaryClassifier
from warmstart import dft_matrix, warm_start_flat, train_ws

# --- inlined ECG beat task (avoid importing real_data.py, which runs on import) ---
_ECG = None
def ecg_task(N=128, n_per_class=700, seed=0):
    global _ECG
    from scipy.datasets import electrocardiogram
    from scipy.signal import find_peaks
    if _ECG is None:
        e = electrocardiogram(); _ECG = (e - e.mean()) / (e.std() + 1e-9)
    e = _ECG; peaks, _ = find_peaks(e, height=1.0, distance=120)
    split = int(0.7 * len(e)); half = N // 2
    def build(pk, n):
        pk = [p for p in pk if half <= p < len(e) - half]
        mids = [(pk[i] + pk[i + 1]) // 2 for i in range(len(pk) - 1)]
        mids = [m for m in mids if half <= m < len(e) - half]
        rng = np.random.default_rng(seed + (0 if n > 400 else 99)); X, y = [], []
        for _ in range(n):
            p = int(rng.choice(pk)) + int(rng.integers(-10, 11)); X.append(e[p - half:p + half]); y.append(1)
            m = int(rng.choice(mids)) + int(rng.integers(-10, 11)); X.append(e[m - half:m + half]); y.append(0)
        return np.array(X), np.array(y)
    Xtr, ytr = build(peaks[peaks < split], n_per_class); Xte, yte = build(peaks[peaks >= split], n_per_class // 2)
    zc = lambda X: (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-9)
    return zc(Xtr), ytr, zc(Xte), yte, 2

def fscore(F, y, nc):
    F = np.asarray(F); mu = F.mean(0); num = np.zeros(F.shape[1]); den = np.zeros(F.shape[1]) + 1e-9
    for c in range(nc):
        Fc = F[y == c]; num += len(Fc) * (Fc.mean(0) - mu) ** 2; den += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return num / den

def get_U(Xtr, ytr, Xte, yte, nc, seed=0):
    F1 = Xtr.astype(np.float64); F2 = Xte.astype(np.float64); d = F1.shape[1]
    m = UnitaryClassifier(d, nc, seed=seed); warm_start_flat(m.U, dft_matrix(d))
    train_ws(m, F1, ytr, F2, yte, epochs=150)
    U = m.U.matrix().detach().numpy()
    with torch.no_grad(): coeff = m.features(torch.tensor(F1)).numpy()
    fs = fscore(coeff, ytr, nc)
    return U, fs

def novelty(atoms, U0):
    # atoms: (k,d) rows of U ; U0 rows = DFT atoms. corr = |U0 @ conj(atom)|
    out = []
    for a in atoms:
        a = a / (np.linalg.norm(a) + 1e-12)
        corr = np.abs(U0.conj() @ a)              # U0 rows already unit-norm
        out.append(1 - corr.max())
    return np.array(out)

TASKS = [("1D global (Fourier)", "load"), ("hidden basis (rotated)", "load"), ("real ECG (beat)", "ecg")]
d = 128; U0 = dft_matrix(d)
fig, axes = plt.subplots(len(TASKS), 4, figsize=(13, 8))
for r, (name, kind) in enumerate(TASKS):
    if kind == "ecg":
        Xtr, ytr, Xte, yte, nc = ecg_task(seed=0)
    else:
        Xtr, ytr, Xte, yte, nc, _ = MM.load(name, 0)
    U, fs = get_U(Xtr, ytr, Xte, yte, nc)
    top = np.argsort(fs)[::-1][:3]                 # 3 most discriminative atoms
    nov = novelty(U[top], U0)
    for c in range(3):
        ax = axes[r, c]; atom = U[top[c]]
        ax.plot(atom.real, color="#1f77b4", lw=1.2); ax.plot(atom.imag, color="#d62728", lw=0.8, alpha=0.6)
        ax.set_title(f"atom #{top[c]}  novelty={nov[c]:.2f}", fontsize=8)
        ax.set_xticks([]); ax.set_yticks([])
        if c == 0: ax.set_ylabel(f"{name}\n(mean novelty {nov.mean():.2f})", fontsize=8.5)
    # 4th column: frequency content of the top atom (|DFT|) -> localized (Fourier) vs spread (new)
    ax = axes[r, 3]; sp = np.abs(np.fft.fft(U[top[0]]))
    ax.stem(sp, basefmt=" "); ax.set_title(f"|DFT| of atom #{top[0]}\n(peaky=Fourier, spread=new)", fontsize=8)
    ax.set_xticks([]); ax.set_yticks([])
axes[0, 0].text(0.02, 1.25, "Real (blue) / Imag (red) part of the learned atom",
                transform=axes[0, 0].transAxes, fontsize=9)
fig.suptitle("Reading the learned unitary U: the transform S3+ discovered per task "
             "(novelty 0=Fourier mode, 1=new basis vector)", fontsize=12)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(os.path.join(HERE, "read_U.png"), dpi=130)
print("saved read_U.png")
# summary
for (name, kind) in [(t[0], t[1]) for t in TASKS]:
    pass
