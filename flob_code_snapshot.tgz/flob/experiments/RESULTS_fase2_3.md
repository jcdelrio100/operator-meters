# Fases 2–3 — Chirplet e integración

## Fase 2 — Banco chirplet (`part2_chirplet/chirplet.py`)

Átomos gaussianos con chirp `(t_c, σ, f, c)`; rasgo = `|⟨x, g⟩|` (matched filter). Sanity (lector lineal, K = 12):

| tarea | Fourier \|mag\| | chirplet | azar |
|---|---|---|---|
| up_vs_down_chirp | 0.533 | **1.000** | 0.50 |
| chirp_vs_tone | 1.000 | 0.900 | 0.50 |
| chirp_rate | 0.457 | **0.997** | 0.25 |

Interpretabilidad: los átomos más discriminativos en up/down-chirp tienen tasa |c| ≈ 21 (no nula) — la dirección vive en la pendiente t-f, como debe ser.

## Fase 3 — Harness integrado (`part3_comparison/harness_amt.py`)

Diccionario {Fourier, DWT, |CWT|, scattering, FrFT, chirplet}, selección F-ANOVA, K = 16, lector lineal.

| tarea | fourier | dwt | cwt | scatter | frft | chirplet | MATCHED | azar |
|---|---|---|---|---|---|---|---|---|
| up_vs_down_chirp | 0.617 | 0.494 | 1.000 | 0.450 | 1.000 | 1.000 | **1.000** | 0.50 |
| chirp_vs_tone | 1.000 | 0.494 | 1.000 | 0.650 | 0.978 | 0.917 | **1.000** | 0.50 |
| chirp_rate | 0.460 | 0.293 | 0.997 | 0.497 | 0.887 | 0.993 | **0.997** | 0.25 |
| narrowband_tones | 1.000 | 0.472 | 1.000 | 1.000 | 1.000 | 1.000 | **1.000** | 0.50 |
| localized_bump | 0.517 | 0.450 | 1.000 | 0.478 | 1.000 | 0.994 | **1.000** | 0.50 |

El diccionario agrupado iguala a la mejor transformada en cada tarea sin elección previa (H2).

### Barrido precisión vs K (eficiencia en parámetros) — chirp_rate (4 clases)

| K | cwt | frft | chirplet | MATCHED |
|---|---|---|---|---|
| 2 | 0.700 | 0.570 | 0.640 | 0.700 |
| 3 | 0.967 | 0.730 | 0.673 | 0.967 |
| 4 | 0.963 | 0.727 | **0.983** | 0.963 |
| 6 | 0.990 | 0.877 | **1.000** | 0.990 |
| 8 | 0.987 | 0.877 | 0.997 | 0.987 |

## Hallazgos honestos (para el artículo)

1. **El |CWT| es un baseline fuerte.** Al ser una representación tiempo-frecuencia *completa* (tiempo × frecuencia), resuelve también la dirección del chirp (ridge diagonal), así que empata a FrFT/chirplet a K fijo. La contribución de FrFT/chirplet **no** es acertar más, sino hacerlo con menos coeficientes → el eje correcto es precisión-vs-parámetros, no precisión a K fijo.
2. **La chirplet es la más compacta** en discriminación de tasa de chirp (1.000 con K = 6, frente a 0.99 del |CWT|), gracias a su rejilla explícita en `(f, c)`.
3. **La FrFT de órdenes fijos se estanca (~0.88) en chirp_rate multiclase:** cada orden α concentra una sola pendiente; con 7 órdenes fijos no cubre bien 4 tasas. → Motiva directamente la **Fase 4 (α aprendible)**: ajustar α por clase debería cerrar la brecha.
4. **up/down-chirp es demasiado fácil** (todas aciertan ya con K = 2): hay que endurecerla (más ruido, chirps más cortos/solapados) para que discrimine entre métodos.
5. **Provenance menos nítida que Fourier-vs-wavelet:** como FrFT, chirplet y |CWT| solapan en el interior del plano t-f, el enrutado se reparte entre ellas (redundancia esperada — es justo el punto de rellenar el interior). El diagnóstico limpio por transformada del paper anterior se difumina aquí.

**Siguiente:** Fase 4 (FrFT con α aprendible y átomos chirplet aprendibles, end-to-end en torch) + endurecer up/down-chirp; luego figuras apples-to-apples.
