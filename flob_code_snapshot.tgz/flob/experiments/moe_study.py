"""
Per-sample routing to approach the oracle union. Two robust variants:
  - MoE-conf  : PARAMETER-FREE confidence routing (blend the two branches' softmax
                probabilities weighted by each branch's own confidence). Cannot overfit.
  - MoE-learn : a small REGULARIZED router (dropout + weight decay) over the concat.
Compared to S3+ (gated joint head), concat, and the oracle-union ceiling. 3 seeds.
"""
import sys, os, numpy as np, torch, torch.nn as nn, torch.nn.functional as Fn
HERE = os.path.dirname(__file__)
for p in (".", "../tasks", "../src"):
    sys.path.insert(0, os.path.join(HERE, p))
import superstructure_multimodal as MM
import s3_coupled as S3
SEEDS = 3
TASKS = ["1D localized (wavelet)", "texture (28x28)", "XOR in hidden basis", "hidden basis (rotated)"]

class GR(nn.Module):
    def __init__(self, K, C, h=32):
        super().__init__(); self.lin=nn.Linear(K,C); self.nl=nn.Sequential(nn.Linear(K,h),nn.ReLU(),nn.Linear(h,C)); self.g=nn.Parameter(torch.tensor(1.0))
    def forward(self,x): return self.lin(x)+self.g*self.nl(x)
class S3plus(nn.Module):
    def __init__(self,Kd,Kl,C,h=32):
        super().__init__(); D=Kd+Kl; self.lin=nn.Linear(D,C); self.nl=nn.Sequential(nn.Linear(D,h),nn.ReLU(),nn.Linear(h,C))
        self.g_nl=nn.Parameter(torch.tensor(1.0)); self.g_s2=nn.Parameter(torch.tensor(1.0))
    def forward(self,xd,xl): x=torch.cat([xd,self.g_s2*xl],1); return self.lin(x)+self.g_nl*self.nl(x)
class MoE(nn.Module):
    def __init__(self,Kd,Kl,C,h=24,p=0.3):
        super().__init__(); self.ed=GR(Kd,C); self.el=GR(Kl,C)
        self.gate=nn.Sequential(nn.Linear(Kd+Kl,h),nn.ReLU(),nn.Dropout(p),nn.Linear(h,2))
    def forward(self,xd,xl):
        w=torch.softmax(self.gate(torch.cat([xd,xl],1)),1)
        return w[:,:1]*self.ed(xd)+w[:,1:]*self.el(xl)

def fit_logits(A,ytr,B,nc,ep=350):
    A=torch.tensor(A,dtype=torch.float32); B=torch.tensor(B,dtype=torch.float32); yt=torch.tensor(ytr); net=GR(A.shape[1],nc)
    opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(A),yt)+0.25*net.g.abs()).backward(); opt.step()
    with torch.no_grad(): return net(B).numpy()

def fit_s3plus(Ad,Al,ytr,Bd,Bl,yte,nc,ep=350):
    Ad,Al,Bd,Bl=[torch.tensor(z,dtype=torch.float32) for z in (Ad,Al,Bd,Bl)]; yt=torch.tensor(ytr); ye=torch.tensor(yte)
    net=S3plus(Ad.shape[1],Al.shape[1],nc); opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); (Fn.cross_entropy(net(Ad,Al),yt)+0.25*(net.g_nl.abs()+net.g_s2.abs())).backward(); opt.step()
    with torch.no_grad(): return (net(Bd,Bl).argmax(1)==ye).float().mean().item()

def fit_concat(Ad,Al,ytr,Bd,Bl,yte,nc,ep=350):
    A=torch.tensor(np.concatenate([Ad,Al],1),dtype=torch.float32); B=torch.tensor(np.concatenate([Bd,Bl],1),dtype=torch.float32); yt=torch.tensor(ytr); ye=torch.tensor(yte)
    net=GR(A.shape[1],nc); opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-4)
    for _ in range(ep): opt.zero_grad(); Fn.cross_entropy(net(A),yt).backward(); opt.step()
    with torch.no_grad(): return (net(B).argmax(1)==ye).float().mean().item()

def fit_moe(Ad,Al,ytr,Bd,Bl,yte,nc,ep=350):
    Ad,Al,Bd,Bl=[torch.tensor(z,dtype=torch.float32) for z in (Ad,Al,Bd,Bl)]; yt=torch.tensor(ytr); ye=torch.tensor(yte)
    net=MoE(Ad.shape[1],Al.shape[1],nc); opt=torch.optim.Adam(net.parameters(),5e-3,weight_decay=1e-3)
    for _ in range(ep): net.train(); opt.zero_grad(); Fn.cross_entropy(net(Ad,Al),yt).backward(); opt.step()
    net.eval()
    with torch.no_grad(): return (net(Bd,Bl).argmax(1)==ye).float().mean().item()

def softmax(z): z=z-z.max(1,keepdims=True); e=np.exp(z); return e/e.sum(1,keepdims=True)

print(f"{SEEDS} seeds\n  {'task':22s} {'S1':>6s} {'S2':>6s} {'oracle':>7s} {'S3+':>6s} {'concat':>7s} {'MoEconf':>8s} {'MoElearn':>9s}")
for name in TASKS:
    R={k:[] for k in ("s1","s2","orU","s3p","cc","mc","ml")}
    for s in range(SEEDS):
        Xtr,ytr,Xte,yte,nc,reps=MM.load(name,s)
        Ad,Bd,_=MM.s1_feats(Xtr,ytr,Xte,yte,nc,reps); Al,Bl=S3.learned_branch(name,Xtr,ytr,Xte,yte,nc,s)
        L1=fit_logits(Ad,ytr,Bd,nc); L2=fit_logits(Al,ytr,Bl,nc)
        p1=L1.argmax(1); p2=L2.argmax(1); c1=(p1==yte); c2=(p2==yte)
        R["s1"].append(c1.mean()); R["s2"].append(c2.mean()); R["orU"].append((c1|c2).mean())
        # confidence routing (parameter-free)
        P1=softmax(L1); P2=softmax(L2); w1=P1.max(1,keepdims=True); w2=P2.max(1,keepdims=True)
        P=(w1*P1+w2*P2)/(w1+w2); R["mc"].append((P.argmax(1)==yte).mean())
        R["s3p"].append(fit_s3plus(Ad,Al,ytr,Bd,Bl,yte,nc)); R["cc"].append(fit_concat(Ad,Al,ytr,Bd,Bl,yte,nc))
        R["ml"].append(fit_moe(Ad,Al,ytr,Bd,Bl,yte,nc))
    m=lambda k: np.mean(R[k])
    print(f"  {name:22s} {m('s1'):>6.3f} {m('s2'):>6.3f} {m('orU'):>7.3f} {m('s3p'):>6.3f} {m('cc'):>7.3f} {m('mc'):>8.3f} {m('ml'):>9.3f}")
