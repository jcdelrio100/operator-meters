"""
Prueba de concepto: una transformada unitaria APRENDIDA desde cero vs bases fijas.
Compara precision y compacidad, y visualiza que atomos descubre (deberian parecerse
a la estructura de la senal: sinusoides para tonos, chirps para barridos).
"""
import numpy as np
import torch
import sys, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "tasks"))
from learned_transform import UnitaryClassifier, train
import chirp_tasks, classic_tasks

torch.manual_seed(0)


def softmax(z):
    z = z - z.max(1, keepdims=True); e = np.exp(z); return e / e.sum(1, keepdims=True)


def linread(Ftr, ytr, Fte, yte, nc, epochs=400, lr=0.2, l2=1e-4):
    mu, sd = Ftr.mean(0), Ftr.std(0) + 1e-9
    A, B = (Ftr - mu) / sd, (Fte - mu) / sd
    rng = np.random.default_rng(0)
    W = rng.normal(0, 0.01, (A.shape[1], nc)); b = np.zeros(nc)
    Y = np.zeros((len(ytr), nc)); Y[np.arange(len(ytr)), ytr] = 1; n = len(ytr)
    for _ in range(epochs):
        p = softmax(A @ W + b); g = (p - Y) / n
        W -= lr * (A.T @ g + l2 * W); b -= lr * g.sum(0)
    return float((softmax(B @ W + b).argmax(1) == yte).mean())


def fscore(F, y, nc):
    n, D = F.shape; grand = F.mean(0); ssb = np.zeros(D); ssw = np.zeros(D)
    for c in range(nc):
        Fc = F[y == c]; ssb += len(Fc) * (Fc.mean(0) - grand) ** 2
        ssw += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return (ssb / (nc - 1)) / (ssw / (n - nc) + 1e-9)


def compact_curve(Ftr, ytr, Fte, yte, nc, Ks):
    sc = fscore(Ftr, ytr, nc)
    out = []
    for K in Ks:
        idx = np.argsort(sc)[::-1][:K]
        out.append(linread(Ftr[:, idx], ytr, Fte[:, idx], yte, nc))
    return out


def fourier_mag(X):
    return np.abs(np.fft.rfft(X, axis=1))


def pca_feats(Xtr, Xte):
    mu = Xtr.mean(0); U, S, Vt = np.linalg.svd(Xtr - mu, full_matrices=False)
    return np.abs((Xtr - mu) @ Vt.T), np.abs((Xte - mu) @ Vt.T)


TASKS = {"narrowband_tones": classic_tasks.narrowband_tones,
         "chirp_rate": chirp_tasks.chirp_rate}
Ks = [2, 4, 8, 16]

fig, axes = plt.subplots(2, 2, figsize=(11, 7))
for ti, (tname, tfn) in enumerate(TASKS.items()):
    Xtr, ytr, Xte, yte, nc = tfn(seed=0)
    N = Xtr.shape[1]
    print(f"=== {tname}  (nc={nc}, chance={1/nc:.2f}) ===")

    # transformada aprendida
    model = UnitaryClassifier(N, nc, seed=0)
    acc_e2e = train(model, Xtr, ytr, Xte, yte, epochs=300, l1=0.02)
    with torch.no_grad():
        Ztr = model.features(torch.tensor(Xtr)).numpy()
        Zte = model.features(torch.tensor(Xte)).numpy()
    lc = compact_curve(Ztr, ytr, Zte, yte, nc, Ks)

    # baselines
    Ftr, Fte = fourier_mag(Xtr), fourier_mag(Xte)
    fc = compact_curve(Ftr, ytr, Fte, yte, nc, Ks)
    Ptr, Pte = pca_feats(Xtr, Xte)
    pc = compact_curve(Ptr, ytr, Pte, yte, nc, Ks)

    print(f"  aprendida (e2e) acc={acc_e2e:.3f}")
    print(f"  {'K':>3s} {'aprendida':>10s} {'Fourier':>9s} {'PCA':>7s}")
    for i, K in enumerate(Ks):
        print(f"  {K:>3d} {lc[i]:>10.3f} {fc[i]:>9.3f} {pc[i]:>7.3f}")

    # visualizar los atomos aprendidos mas discriminativos
    U = model.U.matrix().detach().numpy()          # (N,N) filas = atomos
    top = np.argsort(fscore(Ztr, ytr, nc))[::-1][:3]
    axt, axf = axes[ti, 0], axes[ti, 1]
    t = np.arange(N)
    for j, i in enumerate(top):
        atom = U[i]
        axt.plot(t, atom.real + j * 0.6, lw=1.2)
        spec = np.abs(np.fft.rfft(atom.real))
        axf.plot(spec / (spec.max() + 1e-9) + j * 1.1, lw=1.2)
    axt.set_title(f"{tname}: atomos aprendidos (tiempo)"); axt.set_yticks([])
    axf.set_title(f"{tname}: su espectro |FFT|"); axf.set_yticks([]); axf.set_xlabel("bin de frecuencia")

plt.tight_layout()
out = os.path.join(HERE, "learned_atoms.png")
plt.savefig(out, dpi=130)
print("\nfigura ->", out)
