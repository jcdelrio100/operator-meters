"""
Explora las TRES vias del objetivo para la transformada aprendida:
  (A) discriminativa pura          -> clasifica con pocas componentes.
  (B) discriminativa + suavidad    -> atomos limpios (prior TV) manteniendo acierto.
  (C) no supervisada (sparsifying) -> base que hace la senal dispersa, sin etiquetas.
Metricas: precision (compacta K=8 y e2e) + PLANITUD espectral de los atomos
(0=limpio/tonal, 1=ruido). Figura: atomos sin prior vs con suavidad.
"""
import numpy as np
import torch
import sys, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "tasks"))
from learned_transform import (UnitaryClassifier, LearnableUnitary,
                               train, train_sparsifying, atom_flatness)
import chirp_tasks, classic_tasks

torch.manual_seed(0)


def softmax(z):
    z = z - z.max(1, keepdims=True); e = np.exp(z); return e / e.sum(1, keepdims=True)


def linread(Ftr, ytr, Fte, yte, nc, epochs=400, lr=0.2, l2=1e-4):
    mu, sd = Ftr.mean(0), Ftr.std(0) + 1e-9
    A, B = (Ftr - mu) / sd, (Fte - mu) / sd
    rng = np.random.default_rng(0); W = rng.normal(0, 0.01, (A.shape[1], nc)); b = np.zeros(nc)
    Y = np.zeros((len(ytr), nc)); Y[np.arange(len(ytr)), ytr] = 1; n = len(ytr)
    for _ in range(epochs):
        p = softmax(A @ W + b); g = (p - Y) / n
        W -= lr * (A.T @ g + l2 * W); b -= lr * g.sum(0)
    return float((softmax(B @ W + b).argmax(1) == yte).mean())


def fscore(F, y, nc):
    n, D = F.shape; grand = F.mean(0); ssb = np.zeros(D); ssw = np.zeros(D)
    for c in range(nc):
        Fc = F[y == c]; ssb += len(Fc) * (Fc.mean(0) - grand) ** 2; ssw += ((Fc - Fc.mean(0)) ** 2).sum(0)
    return (ssb / (nc - 1)) / (ssw / (n - nc) + 1e-9)


def compactK(Ftr, ytr, Fte, yte, nc, K=8):
    idx = np.argsort(fscore(Ftr, ytr, nc))[::-1][:K]
    return linread(Ftr[:, idx], ytr, Fte[:, idx], yte, nc)


def feats(model, X):
    with torch.no_grad():
        return model.features(torch.tensor(X)).numpy()


TASKS = {"narrowband_tones": classic_tasks.narrowband_tones,
         "chirp_rate": chirp_tasks.chirp_rate}

fig, axes = plt.subplots(2, 2, figsize=(11, 6))
for ti, (tname, tfn) in enumerate(TASKS.items()):
    Xtr, ytr, Xte, yte, nc = tfn(seed=0); N = Xtr.shape[1]
    print(f"\n=== {tname} (nc={nc}, chance={1/nc:.2f}) ===")
    print(f"  {'objetivo':26s} {'acc(K=8)':>9s} {'acc(e2e)':>9s} {'planitud atomos':>16s}")

    results = {}
    # (A) discriminativa pura
    mA = UnitaryClassifier(N, nc, seed=0); eA = train(mA, Xtr, ytr, Xte, yte, epochs=250, l1=0.0, tv=0.0)
    FA = feats(mA, Xtr); FAte = feats(mA, Xte)
    UA = mA.U.matrix().detach().numpy(); flA = atom_flatness(UA, np.argsort(fscore(FA, ytr, nc))[::-1][:3])
    print(f"  {'A discriminativa':26s} {compactK(FA,ytr,FAte,yte,nc):>9.3f} {eA:>9.3f} {flA:>16.3f}")

    # (B) discriminativa + suavidad
    mB = UnitaryClassifier(N, nc, seed=0); eB = train(mB, Xtr, ytr, Xte, yte, epochs=250, l1=0.01, tv=0.15)
    FB = feats(mB, Xtr); FBte = feats(mB, Xte)
    UB = mB.U.matrix().detach().numpy(); topB = np.argsort(fscore(FB, ytr, nc))[::-1][:3]
    flB = atom_flatness(UB, topB)
    print(f"  {'B discrim+suavidad':26s} {compactK(FB,ytr,FBte,yte,nc):>9.3f} {eB:>9.3f} {flB:>16.3f}")

    # (C) no supervisada (sparsifying) + lector lineal aparte
    uni = LearnableUnitary(N, seed=0); train_sparsifying(uni, Xtr, epochs=250, tv=0.1)
    with torch.no_grad():
        FC = uni.coeffs(torch.tensor(Xtr)).abs().numpy(); FCte = uni.coeffs(torch.tensor(Xte)).abs().numpy()
    UC = uni.matrix().detach().numpy(); flC = atom_flatness(UC, np.argsort(fscore(FC, ytr, nc))[::-1][:3])
    print(f"  {'C sparsifying (no sup.)':26s} {compactK(FC,ytr,FCte,yte,nc):>9.3f} {'-':>9s} {flC:>16.3f}")

    # figura: atomos A (discriminativa, sucios) vs C (sparsifying, limpios)
    t = np.arange(N)
    for j, i in enumerate(np.argsort(fscore(FA, ytr, nc))[::-1][:3]):
        axes[ti, 0].plot(t, UA[i].real + j * 0.6, lw=1.1)
    for j, i in enumerate(np.argsort(fscore(FC, ytr, nc))[::-1][:3]):
        axes[ti, 1].plot(t, UC[i].real + j * 0.6, lw=1.1)
    axes[ti, 0].set_title(f"{tname}: atomos A discriminativa (planitud {flA:.2f})"); axes[ti, 0].set_yticks([])
    axes[ti, 1].set_title(f"{tname}: atomos C sparsifying (planitud {flC:.2f})"); axes[ti, 1].set_yticks([])

plt.tight_layout()
out = os.path.join(HERE, "atoms_priors.png")
plt.savefig(out, dpi=130); print("\nfigura ->", out)
