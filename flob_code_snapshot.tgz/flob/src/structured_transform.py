"""
Thread 1 — Transformada ESTRUCTURADA (<< N^2 parametros).
El generador anti-hermitico se restringe a una banda de ancho b -> la base se
describe con pocos parametros. Barremos b y medimos parametros vs precision:
¿cuanto se puede comprimir la BASE sin perder acierto?
"""
import numpy as np, torch, sys, os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "tasks"))
from learned_transform import UnitaryClassifier, train, StructuredUnitary
import chirp_tasks

torch.manual_seed(0)


def softmax(z):
    z = z - z.max(1, keepdims=True); e = np.exp(z); return e / e.sum(1, keepdims=True)
def linread(Ftr, ytr, Fte, yte, nc, epochs=400, lr=0.2, l2=1e-4):
    mu, sd = Ftr.mean(0), Ftr.std(0)+1e-9; A, B = (Ftr-mu)/sd, (Fte-mu)/sd
    rng = np.random.default_rng(0); W = rng.normal(0, .01, (A.shape[1], nc)); b = np.zeros(nc)
    Y = np.zeros((len(ytr), nc)); Y[np.arange(len(ytr)), ytr] = 1; n = len(ytr)
    for _ in range(epochs):
        p = softmax(A@W+b); g = (p-Y)/n; W -= lr*(A.T@g+l2*W); b -= lr*g.sum(0)
    return float((softmax(B@W+b).argmax(1) == yte).mean())
def fscore(F, y, nc):
    n, D = F.shape; grand = F.mean(0); ssb = np.zeros(D); ssw = np.zeros(D)
    for c in range(nc):
        Fc = F[y==c]; ssb += len(Fc)*(Fc.mean(0)-grand)**2; ssw += ((Fc-Fc.mean(0))**2).sum(0)
    return (ssb/(nc-1))/(ssw/(n-nc)+1e-9)
def compactK(F, y, Fte, yte, nc, K=8):
    idx = np.argsort(fscore(F, y, nc))[::-1][:K]; return linread(F[:, idx], y, Fte[:, idx], yte, nc)
def feats(m, X):
    with torch.no_grad(): return m.features(torch.tensor(X)).numpy()


Xtr, ytr, Xte, yte, nc = chirp_tasks.chirp_rate(seed=0); N = Xtr.shape[1]
BANDS = [1, 2, 4, 8, 16, 32, None]     # None = generador completo (N^2)
print(f"chirp_rate (nc={nc}) — transformada estructurada: ancho de banda del generador\n")
print(f"  {'banda':>6s} {'DOF base':>9s} {'acc(K=8)':>9s} {'acc(e2e)':>9s}")
xs, ys, e2es = [], [], []
for b in BANDS:
    m = UnitaryClassifier(N, nc, seed=0, bandwidth=b)
    e2e = train(m, Xtr, ytr, Xte, yte, epochs=250, sparse=4.0)
    F, Fte = feats(m, Xtr), feats(m, Xte)
    dof = m.U.n_free() if isinstance(m.U, StructuredUnitary) else N * N
    accK = compactK(F, ytr, Fte, yte, nc)
    lab = str(b) if b is not None else "full"
    print(f"  {lab:>6s} {dof:>9d} {accK:>9.3f} {e2e:>9.3f}")
    xs.append(dof); ys.append(accK); e2es.append(e2e)

plt.figure(figsize=(6.5, 4))
plt.semilogx(xs, ys, "o-", label="acc compacta (K=8)")
plt.semilogx(xs, e2es, "s--", label="acc end-to-end")
plt.axhline(0.25, color="gray", ls=":", lw=1, label="azar")
plt.xlabel("parametros de la BASE (DOF del generador, escala log)")
plt.ylabel("precision"); plt.title("chirp_rate: precision vs compacidad de la base")
plt.legend(); plt.grid(alpha=0.3); plt.tight_layout()
out = os.path.join(HERE, "structured_params.png"); plt.savefig(out, dpi=130)
print(f"\nfigura -> {out}")
