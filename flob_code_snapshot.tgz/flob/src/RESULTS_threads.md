# Línea B — Consolidación: base estructurada, semillas, redescubrimiento de wavelets

## Thread 1 — Transformada estructurada (`structured_transform.py`)

El generador anti-hermítico se restringe a una banda de ancho b → la base se describe con ≪ N² parámetros (y exp() sigue siendo unitaria). chirp_rate, sparse=4:

| banda | DOF de la base | acc (K=8) | acc (e2e) |
|---|---|---|---|
| 1 | 382 | 0.673 | 0.803 |
| 2 | 634 | 0.807 | 0.980 |
| 4 | 1 132 | 0.950 | 0.987 |
| 8 | 2 104 | 0.903 | 1.000 |
| 16 | 3 952 | 0.993 | 1.000 |
| full | 16 384 | 0.973 | 1.000 |

**La base se puede comprimir mucho sin apenas perder.** Con banda 4 (1 132 DOF, ~7% de la base completa) ya se llega a 0.95/0.987; banda 2 (~4%) da e2e 0.980. Es decir, la propia transformada —no solo su salida— puede ser compacta. Figura `structured_params.png` (precisión vs parámetros de la base, escala log).

## Thread 2 — Barrido de semillas (`seed_sweep.py`)

Precisión compacta (K=8), media ± std sobre 3 semillas:

| tarea | aprendida | Fourier | PCA/KLT |
|---|---|---|---|
| **chirp_rate** | **0.967 ± 0.017** | 0.506 ± 0.023 | 0.657 ± 0.045 |
| narrowband_tones | 1.000 ± 0.000 | 1.000 ± 0.000 | 1.000 ± 0.000 |

La ventaja de la transformada aprendida en chirps es **grande y estable** (barras estrechas): ~0.97 frente a 0.51 (Fourier) y 0.66 (PCA). En tonos, tarea Fourier-friendly, todas empatan al 1.000. Figura `seed_sweep.png`.

## Thread 3 — Redescubrimiento de wavelets (`wavelet_rediscovery.py`)

Señales localizadas (paquetes de onda), base sparsifying no supervisada. Participation ratio PR (nº efectivo de componentes activas; bajo = localizado):

| base | PR_tiempo | PR_freq |
|---|---|---|
| **aprendida** | **15.0** | **6.1** |
| Fourier | 128.0 | 1.0 |
| aleatoria | 15.2 | 36.5 |

**Redescubre wavelets:** los 16/16 átomos aprendidos están localizados en **tiempo Y frecuencia** (PR 15 y 6) — la firma de una wavelet. Fourier está deslocalizado en tiempo (PR_t=128) y la base aleatoria es de banda ancha (PR_f=36.5). El discriminador limpio es PR_freq: los átomos aprendidos son **band-limited y localizados** (wavelets), no ruido. La figura `wavelet_rediscovery.png` lo muestra: paquetes de onda gaussianos en distintas posiciones (wavelets trasladadas), frente a una sinusoide de Fourier que ocupa toda la ventana.

## Síntesis global de la Línea B

La transformada ortogonal aprendida desde cero, con objetivo sparsifying, **redescubre la representación correcta según la estructura de la señal**: Fourier para tonos, chirps para barridos, wavelets para señales localizadas — sin que se le diga cuál usar. Es la versión *aprendida* del principio "match the transform to the data" del paper anterior. Y con el objetivo híbrido (sparsity+discriminación) esos átomos son a la vez limpios y discriminativos, con una base que además puede hacerse compacta (estructurada). Todo con recuento honesto de parámetros y validado sobre 3 semillas.

Piezas que faltarían para el paper: formalizar el objetivo híbrido, tabla comparativa final Línea A (FrFT/chirplet) vs Línea B en el mismo eje precisión-vs-parámetros, y redacción.
