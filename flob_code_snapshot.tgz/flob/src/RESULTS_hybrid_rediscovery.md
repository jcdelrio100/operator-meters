# Línea B — Objetivo híbrido y redescubrimiento

## 1. Objetivo híbrido: sparsity + discriminación (`hybrid_objective.py`)

Pérdida = CE (discriminación) + λ·concentración (‖z‖₁/‖z‖₂). Barrido de λ en chirp_rate:

| λ | acc (K=8) | acc (e2e) | planitud átomos |
|---|---|---|---|
| 0.0 | 0.967 | 1.000 | 0.48 (sucios) |
| 0.5 | 0.970 | 1.000 | 0.13 |
| 1.0 | 0.970 | 1.000 | 0.14 |
| 4.0 | 0.973 | 1.000 | 0.15 |
| 8.0 | **0.977** | 1.000 | **0.12** |

**La sparsity limpia los átomos gratis.** Con solo λ=0.5 la planitud cae de 0.48 → 0.13 (átomos limpios) sin perder acierto (0.967 → 0.970); con λ=8 se obtiene lo mejor de ambos: máxima precisión (0.977) *y* átomos limpios (0.12). No hay que elegir entre "discriminativo" y "limpio" — el punto dulce existe y no cuesta precisión. Figura `hybrid_atoms.png` (λ=0 ruido vs λ=8 chirps limpios).

## 2. Redescubrimiento: ¿reconstruye la base correcta? (`rediscovery.py`)

Transformada aprendida **no supervisada** (sparsifying, sin etiquetas) sobre datos donde sabemos la respuesta, vs base ortogonal **aleatoria** (control).

| datos | métrica | aprendida | aleatoria |
|---|---|---|---|
| tonos (bins enteros) | frac. energía en bin dominante (1 = sinusoide pura) | **0.988** (12/12 átomos tonales) | 0.070 |
| chirps | R² del ajuste lineal de frecuencia instantánea (1 = chirp) | **0.751** (6/12 átomos chirp R²>0.8; mejor 0.98) | 0.018 |

**Redescubre lo correcto.** En datos de tonos, los átomos aprendidos son sinusoides casi puras que se solapan con un modo de Fourier (pf=1.00, |FFT| = un único pico); en datos de chirp, son chirps con frecuencia instantánea lineal (R²=0.98 en el mejor). Frente a una base aleatoria (0.07 / 0.02), la diferencia es enorme. Figura `rediscovery.png`: átomo aprendido superpuesto a su modo de Fourier / su frecuencia instantánea lineal.

## Conclusión (para el paper)

Estos dos experimentos cierran la validación del concepto central de la Línea B:
1. Una transformada ortogonal aprendida desde cero **puede** dar una representación a la vez compacta, discriminativa y limpia — la clave es incluir sparsity en el objetivo (peso λ), no solo la pérdida de clasificación.
2. El mecanismo es correcto, no un artefacto: la base aprendida **redescubre** Fourier en señales tonales y chirps en señales con barrido, exactamente donde la teoría dice que debe.

Esto sitúa el método como *sparsifying transform learning* (Ravishankar–Bresler) con dos aportes propios: el objetivo híbrido sparsity+discriminación con recuento honesto de parámetros, y la validación de redescubrimiento frente a transformadas conocidas.

## Siguiente
- Transformada **estructurada** (<N² parámetros) para que la base misma sea compacta.
- Barrido de semillas + barras de error; eje precisión-vs-parámetros comparando Línea A (FrFT/chirplet) vs Línea B.
- ¿Redescubre wavelets en señales localizadas? (tercer caso de validación).
