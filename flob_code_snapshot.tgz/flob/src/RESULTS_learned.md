# Línea B — Aprender la transformada ortogonal desde cero

Se parametriza una matriz **unitaria genérica** U = exp(C − Cᴴ) (C compleja libre) que se mantiene unitaria durante todo el entrenamiento, y se aprende por gradiente. Sin imponer Fourier/wavelet/estructura. Rasgo = |U x|. Código: `part4_learned_basis/learned_transform.py`.

## Prueba de concepto (`demo_learned_transform.py`) — acierto y compacidad

| tarea | K | aprendida | Fourier | PCA/KLT |
|---|---|---|---|---|
| narrowband_tones | 4 | 1.000 | 1.000 | 1.000 |
| **chirp_rate** | 8 | **0.977** | 0.480 | 0.620 |
| chirp_rate | 16 | **1.000** | 0.460 | 0.713 |

La transformada aprendida desde cero **iguala a Fourier en tonos y lo pulveriza en chirps** (0.98 vs 0.48 con K=8), superando también a la base óptima clásica no supervisada (PCA/KLT). Concepto confirmado: partiendo de una base indefinida, el entrenamiento descubre la representación compacta óptima para la tarea.

## Exploración de los tres objetivos (`explore_objectives.py`)

Planitud espectral de los átomos: 0 = tono puro/limpio, 1 = ruido blanco.

| objetivo | acc(K=8) chirp_rate | planitud átomos |
|---|---|---|
| A · discriminativa pura | 0.950 | 0.54 (sucios) |
| B · discriminativa + suavidad (TV) | 0.987 | 0.54 (sigue sucio) |
| **C · sparsifying (NO supervisada)** | 0.960 | **0.07 (limpios)** |

(narrowband_tones: A 0.51, C **0.02** — átomos = sinusoides casi puras; todas al 1.000 de acierto.)

## Hallazgo central (para el paper)

**El objetivo importa más que la arquitectura.** Una unitaria libre entrenada solo para *clasificar* encuentra direcciones ruidosas (atajos discriminativos) — precisas pero no interpretables; y un prior de suavidad (TV) apenas ayuda. En cambio, el objetivo **sparsifying no supervisado** (hacer la señal dispersa, sin etiquetas) produce átomos **limpios y estructurados** — sinusoides puras para los tonos, formas oscilatorias con modulación de frecuencia (chirp-like) para los barridos — y esos átomos *también* clasifican bien. Ver `atoms_priors.png`.

Es decir: "óptima para clasificar" ≠ "K componentes limpios". La compacidad interpretable la da la sparsity/reconstrucción, no la pérdida discriminativa. Esto conecta directamente con *sparsifying transform learning* (Ravishankar–Bresler) y define la contribución: **cómo combinar sparsity (limpieza) + discriminación (tarea) en una sola transformada ortogonal aprendida**, con recuento honesto de parámetros.

## Preguntas abiertas / siguiente

- Objetivo híbrido: sparsifying + discriminativo (peso λ) → ¿átomos limpios Y máximos discriminativos?
- Transformada **estructurada** (menos de N² parámetros: bandas, doblemente dispersa) para que la propia base sea compacta, no solo su salida.
- ¿La base aprendida no supervisada reconstruye Fourier/chirplet en tareas donde sabemos la respuesta? (validación de que "redescubre" lo correcto).
- Barrido de semillas + barras de error; comparar con FrFT/chirplet (Línea A) en el mismo eje precisión-vs-parámetros.
