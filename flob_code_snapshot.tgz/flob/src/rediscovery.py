"""
Redescubrimiento: ¿la transformada aprendida NO supervisada (sparsifying)
reconstruye la base 'correcta' cuando sabemos la respuesta?
  - Datos de tonos puros  -> los atomos deberian ser SINUSOIDES (modos de Fourier).
  - Datos de chirps       -> los atomos deberian ser CHIRPS (frecuencia instantanea lineal).
Metricas cuantitativas + figura. Comparado con una base ortogonal ALEATORIA (control).
"""
import numpy as np, torch, sys, os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__); sys.path.insert(0, HERE)
from learned_transform import LearnableUnitary, train_sparsifying

torch.manual_seed(0)
N = 128


def gen_tones(n=600, band=(8, 40), noise=0.05, seed=0):
    """Tonos en bins ENTEROS de la DFT -> la base sparse 'correcta' es exactamente
    Fourier, asi que el test de redescubrimiento es limpio."""
    rng = np.random.default_rng(seed); t = np.arange(N); X = []
    bins = np.arange(band[0], band[1] + 1)
    for _ in range(n):
        f = rng.choice(bins); ph = rng.uniform(0, 2*np.pi)
        X.append(np.cos(2*np.pi*f*t/N + ph) + noise*rng.standard_normal(N))
    X = np.array(X); return (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True)+1e-9)


def gen_chirps(n=600, band=(8, 40), slope=(10, 30), noise=0.05, seed=0):
    rng = np.random.default_rng(seed); t = np.arange(N); X = []
    for _ in range(n):
        f0 = rng.uniform(band[0], band[1]-slope[1])
        f1 = f0 + rng.uniform(*slope)                    # siempre up-chirp
        ph = rng.uniform(0, 2*np.pi)
        inst = (f0 + (f1-f0)*t/(N-1))/N
        X.append(np.cos(2*np.pi*np.cumsum(inst) + ph) + noise*rng.standard_normal(N))
    X = np.array(X); return (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True)+1e-9)


def peak_fraction(atom):
    """Fraccion de energia en el bin de frecuencia dominante (1 = tono puro)."""
    s = np.abs(np.fft.rfft(atom.real))**2
    return float(s.max() / (s.sum() + 1e-12))


def inst_freq_linearity(atom):
    """R^2 del ajuste lineal de la frecuencia instantanea (1 = chirp lineal perfecto)."""
    a = atom.real
    A = np.fft.fft(a); h = np.zeros(N); h[0] = 1; h[1:N//2] = 2; h[N//2] = 1
    z = np.fft.ifft(A*h)                                  # senal analitica
    env = np.abs(z); phase = np.unwrap(np.angle(z))
    inst = np.diff(phase)
    w = env[1:]                                           # ponderar donde hay energia
    m = w > 0.3*w.max()
    if m.sum() < 8: return 0.0
    x = np.arange(N-1)[m]; yv = inst[m]; wt = w[m]
    p = np.polyfit(x, yv, 1, w=wt); pred = np.polyval(p, x)
    ss_res = (wt*(yv-pred)**2).sum(); ss_tot = (wt*(yv-yv.mean())**2).sum()+1e-12
    return float(1 - ss_res/ss_tot)


def energy_top_atoms(U, X, k=12):
    """Indices de los k atomos con mas energia media sobre los datos."""
    Z = np.abs(X @ U.conj().T)
    return np.argsort(Z.mean(0))[::-1][:k]


def rand_ortho(seed=1):
    uni = LearnableUnitary(N, seed=seed)
    return uni.matrix().detach().numpy()


print("REDESCUBRIMIENTO — base aprendida (sparsifying, no supervisada) vs aleatoria\n")

# --- Tonos ---
Xt = gen_tones()
uni = LearnableUnitary(N, seed=0); train_sparsifying(uni, Xt, epochs=450, tv=0.0)
Ut = uni.matrix().detach().numpy(); topt = energy_top_atoms(Ut, Xt)
pf_learn = np.mean([peak_fraction(Ut[i]) for i in topt])
Ur = rand_ortho(); topr = energy_top_atoms(Ur, Xt)
pf_rand = np.mean([peak_fraction(Ur[i]) for i in topr])
print("TONOS  -> fraccion de energia en el bin dominante (1 = sinusoide pura)")
print(f"   aprendida={pf_learn:.3f}   aleatoria={pf_rand:.3f}   (n_atomos tonales pf>0.8: "
      f"{sum(peak_fraction(Ut[i])>0.8 for i in topt)}/{len(topt)})")

# --- Chirps ---
Xc = gen_chirps()
unic = LearnableUnitary(N, seed=0); train_sparsifying(unic, Xc, epochs=300, tv=0.05)
Uc = unic.matrix().detach().numpy(); topc = energy_top_atoms(Uc, Xc)
r2_learn = np.mean([inst_freq_linearity(Uc[i]) for i in topc])
r2_rand = np.mean([inst_freq_linearity(Ur[i]) for i in energy_top_atoms(Ur, Xc)])
print("\nCHIRPS -> R^2 del ajuste lineal de la frecuencia instantanea (1 = chirp lineal)")
print(f"   aprendida={r2_learn:.3f}   aleatoria={r2_rand:.3f}   (n_atomos chirp R2>0.8: "
      f"{sum(inst_freq_linearity(Uc[i])>0.8 for i in topc)}/{len(topc)})")

# --- figura (atomo mas LIMPIO de cada tipo, no el de mas energia) ---
fig, ax = plt.subplots(2, 2, figsize=(11, 5)); t = np.arange(N)
# tono aprendido vs modo de Fourier mas cercano
best_tone = topt[int(np.argmax([peak_fraction(Ut[i]) for i in topt]))]
a = Ut[best_tone].real; fbin = np.argmax(np.abs(np.fft.rfft(a)))
fourier = np.cos(2*np.pi*fbin*t/N); fourier *= np.sign((fourier*a).sum())
ax[0, 0].plot(t, a/np.abs(a).max(), lw=1.3, label="atomo aprendido")
ax[0, 0].plot(t, fourier, "--", lw=1.0, label=f"Fourier bin {fbin}")
ax[0, 0].set_title(f"TONOS: atomo aprendido ~ sinusoide (pf={peak_fraction(a):.2f})"); ax[0, 0].legend(fontsize=8); ax[0, 0].set_yticks([])
ax[0, 1].plot(np.abs(np.fft.rfft(a))); ax[0, 1].set_title("su |FFT| (pico unico)"); ax[0, 1].set_xlabel("bin")
# chirp aprendido: forma + frecuencia instantanea lineal (el mas limpio)
best_chirp = topc[int(np.argmax([inst_freq_linearity(Uc[i]) for i in topc]))]
ac = Uc[best_chirp].real
ax[1, 0].plot(t, ac/np.abs(ac).max(), lw=1.1)
ax[1, 0].set_title(f"CHIRPS: atomo aprendido (R2 freq inst={inst_freq_linearity(ac):.2f})"); ax[1, 0].set_yticks([])
A = np.fft.fft(ac); h = np.zeros(N); h[0]=1; h[1:N//2]=2; h[N//2]=1
z = np.fft.ifft(A*h); inst = np.diff(np.unwrap(np.angle(z)))*N/(2*np.pi)
ax[1, 1].plot(inst); ax[1, 1].set_title("frecuencia instantanea (lineal = chirp)"); ax[1, 1].set_xlabel("t"); ax[1, 1].set_ylabel("bin")
plt.tight_layout(); out = os.path.join(HERE, "rediscovery.png"); plt.savefig(out, dpi=130)
print(f"\nfigura -> {out}")
