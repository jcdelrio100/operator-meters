"""
Thread 2 — Barrido de semillas con barras de error.
Compara (precision compacta K=8, media +/- std sobre 3 semillas) la transformada
APRENDIDA (hibrida: sparsity+discriminacion) vs Fourier |mag| vs PCA/KLT.
"""
import numpy as np, torch, sys, os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "tasks"))
from learned_transform import UnitaryClassifier, train
import chirp_tasks, classic_tasks

SEEDS = [0, 1, 2]
K = 8


def softmax(z):
    z = z - z.max(1, keepdims=True); e = np.exp(z); return e / e.sum(1, keepdims=True)
def linread(Ftr, ytr, Fte, yte, nc, epochs=400, lr=0.2, l2=1e-4):
    mu, sd = Ftr.mean(0), Ftr.std(0)+1e-9; A, B = (Ftr-mu)/sd, (Fte-mu)/sd
    rng = np.random.default_rng(0); W = rng.normal(0, .01, (A.shape[1], nc)); b = np.zeros(nc)
    Y = np.zeros((len(ytr), nc)); Y[np.arange(len(ytr)), ytr] = 1; n = len(ytr)
    for _ in range(epochs):
        p = softmax(A@W+b); g = (p-Y)/n; W -= lr*(A.T@g+l2*W); b -= lr*g.sum(0)
    return float((softmax(B@W+b).argmax(1) == yte).mean())
def fscore(F, y, nc):
    n, D = F.shape; grand = F.mean(0); ssb = np.zeros(D); ssw = np.zeros(D)
    for c in range(nc):
        Fc = F[y==c]; ssb += len(Fc)*(Fc.mean(0)-grand)**2; ssw += ((Fc-Fc.mean(0))**2).sum(0)
    return (ssb/(nc-1))/(ssw/(n-nc)+1e-9)
def compactK(F, y, Fte, yte, nc):
    idx = np.argsort(fscore(F, y, nc))[::-1][:K]; return linread(F[:, idx], y, Fte[:, idx], yte, nc)
def fourier_mag(X): return np.abs(np.fft.rfft(X, axis=1))
def pca_feats(Xtr, Xte):
    mu = Xtr.mean(0); _, _, Vt = np.linalg.svd(Xtr-mu, full_matrices=False)
    return np.abs((Xtr-mu)@Vt.T), np.abs((Xte-mu)@Vt.T)


TASKS = {"chirp_rate": chirp_tasks.chirp_rate, "narrowband_tones": classic_tasks.narrowband_tones}
methods = ["aprendida", "Fourier", "PCA"]
summary = {t: {m: [] for m in methods} for t in TASKS}

for tname, tfn in TASKS.items():
    for s in SEEDS:
        Xtr, ytr, Xte, yte, nc = tfn(seed=s); N = Xtr.shape[1]
        torch.manual_seed(s)
        m = UnitaryClassifier(N, nc, seed=s)
        train(m, Xtr, ytr, Xte, yte, epochs=250, sparse=4.0)
        with torch.no_grad():
            Ztr = m.features(torch.tensor(Xtr)).numpy(); Zte = m.features(torch.tensor(Xte)).numpy()
        summary[tname]["aprendida"].append(compactK(Ztr, ytr, Zte, yte, nc))
        Ftr, Fte = fourier_mag(Xtr), fourier_mag(Xte)
        summary[tname]["Fourier"].append(compactK(Ftr, ytr, Fte, yte, nc))
        Ptr, Pte = pca_feats(Xtr, Xte)
        summary[tname]["PCA"].append(compactK(Ptr, ytr, Pte, yte, nc))

print(f"Precision compacta (K={K}), media +/- std sobre {len(SEEDS)} semillas\n")
print(f"  {'tarea':18s} " + " ".join(f"{m:>16s}" for m in methods))
for tname in TASKS:
    row = f"  {tname:18s} "
    for m in methods:
        v = np.array(summary[tname][m]); row += f"{v.mean():>10.3f}+/-{v.std():<4.3f} "
    print(row)

# figura de barras con error
fig, ax = plt.subplots(figsize=(7, 4)); x = np.arange(len(TASKS)); w = 0.25
for k, mth in enumerate(methods):
    means = [np.mean(summary[t][mth]) for t in TASKS]
    stds = [np.std(summary[t][mth]) for t in TASKS]
    ax.bar(x + (k-1)*w, means, w, yerr=stds, capsize=4, label=mth)
ax.set_xticks(x); ax.set_xticklabels(list(TASKS)); ax.set_ylabel(f"precision (K={K})")
ax.set_title(f"Media +/- std ({len(SEEDS)} semillas)"); ax.legend(); ax.grid(axis="y", alpha=0.3)
plt.tight_layout(); out = os.path.join(HERE, "seed_sweep.png"); plt.savefig(out, dpi=130)
print("\nfigura ->", out)
