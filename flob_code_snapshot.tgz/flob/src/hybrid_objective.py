"""
Objetivo HIBRIDO: CE (discriminacion) + lambda * concentracion (sparsity/limpieza).
Barre lambda y mide precision (compacta K=8) y limpieza de atomos (planitud espectral)
para localizar el punto dulce: atomos LIMPIOS *y* discriminativos a la vez.
"""
import numpy as np, torch, sys, os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "tasks"))
from learned_transform import UnitaryClassifier, train, atom_flatness
import chirp_tasks, classic_tasks

torch.manual_seed(0)


def softmax(z):
    z = z - z.max(1, keepdims=True); e = np.exp(z); return e / e.sum(1, keepdims=True)
def linread(Ftr, ytr, Fte, yte, nc, epochs=400, lr=0.2, l2=1e-4):
    mu, sd = Ftr.mean(0), Ftr.std(0)+1e-9; A, B = (Ftr-mu)/sd, (Fte-mu)/sd
    rng = np.random.default_rng(0); W = rng.normal(0, .01, (A.shape[1], nc)); b = np.zeros(nc)
    Y = np.zeros((len(ytr), nc)); Y[np.arange(len(ytr)), ytr] = 1; n = len(ytr)
    for _ in range(epochs):
        p = softmax(A@W+b); g = (p-Y)/n; W -= lr*(A.T@g+l2*W); b -= lr*g.sum(0)
    return float((softmax(B@W+b).argmax(1) == yte).mean())
def fscore(F, y, nc):
    n, D = F.shape; grand = F.mean(0); ssb = np.zeros(D); ssw = np.zeros(D)
    for c in range(nc):
        Fc = F[y==c]; ssb += len(Fc)*(Fc.mean(0)-grand)**2; ssw += ((Fc-Fc.mean(0))**2).sum(0)
    return (ssb/(nc-1))/(ssw/(n-nc)+1e-9)
def compactK(F, y, Fte, yte, nc, K=8):
    idx = np.argsort(fscore(F, y, nc))[::-1][:K]; return linread(F[:, idx], y, Fte[:, idx], yte, nc)
def feats(m, X):
    with torch.no_grad(): return m.features(torch.tensor(X)).numpy()


LAMBDAS = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]
Xtr, ytr, Xte, yte, nc = chirp_tasks.chirp_rate(seed=0); N = Xtr.shape[1]
print(f"chirp_rate (nc={nc}) — barrido del peso de sparsity (lambda)\n")
print(f"  {'lambda':>7s} {'acc(K=8)':>9s} {'acc(e2e)':>9s} {'planitud':>9s}")
rows = []
saved = {}
for lam in LAMBDAS:
    m = UnitaryClassifier(N, nc, seed=0)
    e2e = train(m, Xtr, ytr, Xte, yte, epochs=250, sparse=lam)
    F, Fte = feats(m, Xtr), feats(m, Xte)
    U = m.U.matrix().detach().numpy(); top = np.argsort(fscore(F, ytr, nc))[::-1][:3]
    accK = compactK(F, ytr, Fte, yte, nc); fl = atom_flatness(U, top)
    rows.append((lam, accK, e2e, fl)); saved[lam] = (U, top)
    print(f"  {lam:>7.1f} {accK:>9.3f} {e2e:>9.3f} {fl:>9.3f}")

# figura: atomos a lambda=0 (sucio), punto dulce, y lambda alto (muy disperso)
sweet = min(rows[1:], key=lambda r: r[3] if r[1] > 0.9 else 9)[0]   # mas limpio con acc>0.9
picks = [0.0, sweet, LAMBDAS[-1]]
fig, ax = plt.subplots(1, 3, figsize=(13, 3.2)); t = np.arange(N)
for k, lam in enumerate(picks):
    U, top = saved[lam]
    for j, i in enumerate(top):
        ax[k].plot(t, U[i].real + j*0.6, lw=1.1)
    fl = atom_flatness(U, top)
    ax[k].set_title(f"lambda={lam} (planitud {fl:.2f})"); ax[k].set_yticks([])
plt.suptitle("chirp_rate: atomos aprendidos segun el peso de sparsity")
plt.tight_layout(); out = os.path.join(HERE, "hybrid_atoms.png"); plt.savefig(out, dpi=130)
print(f"\npunto dulce lambda={sweet}  |  figura -> {out}")
