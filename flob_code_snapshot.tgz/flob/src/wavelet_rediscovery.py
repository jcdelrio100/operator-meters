"""
Thread 3 — ¿Redescubre WAVELETS? En senales LOCALIZADAS (paquetes de onda con
ventana gaussiana en posicion/escala aleatoria), la base sparsifying no supervisada
deberia aprender atomos localizados en tiempo Y frecuencia = wavelets.

Metrica: participation ratio PR = (sum p)^2 / sum p^2 con p=|.|^2 (numero efectivo
de muestras/bins activos). Bajo = localizado. Fourier: PR_tiempo ~ N (deslocalizado).
Wavelet: PR_tiempo y PR_freq ambos moderados.
"""
import numpy as np, torch, sys, os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HERE = os.path.dirname(__file__); sys.path.insert(0, HERE)
from learned_transform import LearnableUnitary, train_sparsifying

torch.manual_seed(0)
N = 128


def gen_localized(n=700, band=(6, 30), width=(5, 12), noise=0.05, seed=0):
    rng = np.random.default_rng(seed); t = np.arange(N); X = []
    for _ in range(n):
        pos = rng.uniform(0.15, 0.85) * N; w = rng.uniform(*width)
        f = rng.uniform(*band); ph = rng.uniform(0, 2 * np.pi)
        env = np.exp(-((t - pos) ** 2) / (2 * w ** 2))
        X.append(env * np.cos(2 * np.pi * f * t / N + ph) + noise * rng.standard_normal(N))
    X = np.array(X); return (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-9)


def PR(p):
    p = p / (p.sum() + 1e-12)
    return 1.0 / (np.sum(p ** 2) + 1e-12)     # numero efectivo de componentes activas


def pr_time(atom): return PR(np.abs(atom) ** 2)
def pr_freq(atom): return PR(np.abs(np.fft.rfft(atom.real)) ** 2)


def energy_top(U, X, k=16):
    Z = np.abs(X @ U.conj().T); return np.argsort(Z.mean(0))[::-1][:k]


Xl = gen_localized()
uni = LearnableUnitary(N, seed=0); train_sparsifying(uni, Xl, epochs=400, tv=0.0)
U = uni.matrix().detach().numpy(); top = energy_top(U, Xl)

# controles: Fourier (filas de la DFT) y ortogonal aleatoria
F = np.exp(-2j * np.pi * np.outer(np.arange(N), np.arange(N)) / N) / np.sqrt(N)
R = LearnableUnitary(N, seed=7).matrix().detach().numpy(); topR = energy_top(R, Xl)

prt_learn = np.mean([pr_time(U[i]) for i in top]); prf_learn = np.mean([pr_freq(U[i]) for i in top])
prt_four = np.mean([pr_time(F[i]) for i in range(6, 30)]); prf_four = np.mean([pr_freq(F[i]) for i in range(6, 30)])
prt_rand = np.mean([pr_time(R[i]) for i in topR]); prf_rand = np.mean([pr_freq(R[i]) for i in topR])

print("REDESCUBRIMIENTO DE WAVELETS — señales localizadas\n")
print(f"  {'base':16s} {'PR_tiempo':>10s} {'PR_freq':>9s}   (N={N}; bajo=localizado)")
print(f"  {'aprendida':16s} {prt_learn:>10.1f} {prf_learn:>9.1f}")
print(f"  {'Fourier':16s} {prt_four:>10.1f} {prf_four:>9.1f}")
print(f"  {'aleatoria':16s} {prt_rand:>10.1f} {prf_rand:>9.1f}")
nwav = sum((pr_time(U[i]) < N/3) and (pr_freq(U[i]) < N/3) for i in top)
print(f"\n  atomos wavelet-like (localizados en tiempo Y freq) aprendidos: {nwav}/{len(top)}")
print(f"  (Fourier: localizado en freq pero PR_tiempo~{prt_four:.0f} -> deslocalizado en tiempo)")

# figura: atomos aprendidos localizados vs un modo de Fourier
fig, ax = plt.subplots(1, 3, figsize=(13, 3.3)); t = np.arange(N)
order = sorted(top, key=lambda i: np.argmax(np.abs(U[i])))     # ordenar por posicion
picks = [order[2], order[len(order)//2], order[-3]]
for i in picks:
    a = U[i].real; ax[0].plot(t, a / np.abs(a).max(), lw=1.1)
ax[0].set_title(f"atomos aprendidos (PR_t={prt_learn:.0f}) = wavelets"); ax[0].set_yticks([])
a = U[top[0]].real; ax[1].plot(t, a / np.abs(a).max(), lw=1.3)
ax[1].set_title(f"un atomo: paquete localizado"); ax[1].set_yticks([])
ax[2].plot(t, F[15].real, lw=1.1)
ax[2].set_title(f"Fourier (PR_t={prt_four:.0f}): deslocalizado"); ax[2].set_yticks([])
plt.tight_layout(); out = os.path.join(HERE, "wavelet_rediscovery.png"); plt.savefig(out, dpi=130)
print(f"\nfigura -> {out}")
