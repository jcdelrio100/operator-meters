"""
chirp_tasks.py
Generadores de tareas NO ESTACIONARIAS (chirps) para el estudio Adaptive Matched
Transforms. Formato compatible con el harness del proyecto anterior:

    train_fn() -> (Xtr, ytr, Xte, yte, nc)

con X:(n, N) real, y:(n,) int, nc = nº de clases.

Diseño clave (up_vs_down_chirp): las dos clases barren la MISMA banda de
frecuencias en sentidos opuestos, así que su |FFT| es casi idéntico -> la
magnitud de Fourier queda a nivel de azar y solo la pendiente tiempo-frecuencia
(que ven FrFT/chirplet) separa las clases.
"""
import numpy as np

N_DEFAULT = 128


def _linear_chirp(N, f0, f1, phase0=0.0, amp=1.0):
    """Chirp lineal real. f0, f1 en 'ciclos por ventana' (indice de bin FFT).
    Frecuencia instantanea barre linealmente de f0 a f1 a lo largo de N muestras."""
    t = np.arange(N)
    inst_freq_cyc_per_sample = (f0 + (f1 - f0) * t / (N - 1)) / N   # ciclos/muestra
    phase = 2 * np.pi * np.cumsum(inst_freq_cyc_per_sample) + phase0
    return amp * np.cos(phase)


def _tone(N, f, phase0=0.0, amp=1.0):
    t = np.arange(N)
    return amp * np.cos(2 * np.pi * f * t / N + phase0)


def _normalize(X):
    X = X - X.mean(1, keepdims=True)
    X = X / (X.std(1, keepdims=True) + 1e-9)
    return X


def _split(X, y, seed, test_frac=0.3):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(X))
    ntest = int(len(X) * test_frac)
    te, tr = idx[:ntest], idx[ntest:]
    return X[tr], y[tr], X[te], y[te]


def up_vs_down_chirp(N=N_DEFAULT, n_per_class=300, band=(8, 30),
                     noise=0.25, seed=0):
    """Clase 0 = up-chirp (f0->f1, f1>f0); clase 1 = down-chirp (misma banda,
    invertida). Igual |FFT|; solo difiere el signo de la pendiente t-f."""
    rng = np.random.default_rng(seed)
    fa, fb = band
    X, y = [], []
    for cls in (0, 1):
        for _ in range(n_per_class):
            lo = rng.uniform(fa, fa + 3)
            hi = rng.uniform(fb - 3, fb)
            f0, f1 = (lo, hi) if cls == 0 else (hi, lo)
            ph = rng.uniform(0, 2 * np.pi)
            amp = rng.uniform(0.8, 1.2)
            s = _linear_chirp(N, f0, f1, ph, amp)
            s = s + noise * rng.standard_normal(N)
            X.append(s); y.append(cls)
    X = _normalize(np.array(X)); y = np.array(y)
    return (*_split(X, y, seed + 1), int(np.unique(y).size))


def chirp_vs_tone(N=N_DEFAULT, n_per_class=300, band=(8, 30),
                  noise=0.25, seed=0):
    """Clase 0 = chirp (barrido); clase 1 = tono puro dentro de la misma banda."""
    rng = np.random.default_rng(seed)
    fa, fb = band
    X, y = [], []
    for cls in (0, 1):
        for _ in range(n_per_class):
            ph = rng.uniform(0, 2 * np.pi)
            amp = rng.uniform(0.8, 1.2)
            if cls == 0:
                f0 = rng.uniform(fa, fa + 4); f1 = rng.uniform(fb - 4, fb)
                if rng.random() < 0.5:
                    f0, f1 = f1, f0
                s = _linear_chirp(N, f0, f1, ph, amp)
            else:
                f = rng.uniform(fa, fb)
                s = _tone(N, f, ph, amp)
            s = s + noise * rng.standard_normal(N)
            X.append(s); y.append(cls)
    X = _normalize(np.array(X)); y = np.array(y)
    return (*_split(X, y, seed + 1), int(np.unique(y).size))


def chirp_rate(N=N_DEFAULT, n_per_class=250, rates=(-20, -7, 7, 20),
               center=18, noise=0.25, seed=0):
    """Multiclase por la TASA de chirp: cada clase barre +-rate/2 alrededor de un
    centro comun. Clases con misma energia media, distinta pendiente t-f."""
    rng = np.random.default_rng(seed)
    X, y = [], []
    for cls, r in enumerate(rates):
        for _ in range(n_per_class):
            f0 = center - r / 2 + rng.uniform(-1.5, 1.5)
            f1 = center + r / 2 + rng.uniform(-1.5, 1.5)
            ph = rng.uniform(0, 2 * np.pi)
            amp = rng.uniform(0.8, 1.2)
            s = _linear_chirp(N, f0, f1, ph, amp) + noise * rng.standard_normal(N)
            X.append(s); y.append(cls)
    X = _normalize(np.array(X)); y = np.array(y)
    return (*_split(X, y, seed + 1), int(np.unique(y).size))


def up_vs_down_chirp_hard(N=N_DEFAULT, n_per_class=300, band=(10, 26),
                          noise=0.55, seed=0):
    """Version dificil: el chirp solo esta activo en una sub-ventana aleatoria
    (posicion no correlada con la clase) y con mas ruido. La clase sigue siendo
    solo la DIRECCION del barrido -> ya no es trivialmente separable con K=2."""
    rng = np.random.default_rng(seed)
    fa, fb = band; t = np.arange(N)
    X, y = [], []
    for cls in (0, 1):
        for _ in range(n_per_class):
            L = int(rng.uniform(0.45, 0.7) * N)         # extension del chirp
            start = int(rng.uniform(0, N - L))
            lo = rng.uniform(fa, fa + 3); hi = rng.uniform(fb - 3, fb)
            f0, f1 = (lo, hi) if cls == 0 else (hi, lo)
            # frecuencia instantanea solo dentro de [start, start+L]
            local = np.clip((t - start) / max(L - 1, 1), 0, 1)
            inst = (f0 + (f1 - f0) * local) / N
            window = ((t >= start) & (t < start + L)).astype(float)
            phase = 2 * np.pi * np.cumsum(inst)
            amp = rng.uniform(0.8, 1.2)
            s = amp * window * np.cos(phase + rng.uniform(0, 2 * np.pi))
            s = s + noise * rng.standard_normal(N)
            X.append(s); y.append(cls)
    X = _normalize(np.array(X)); y = np.array(y)
    return (*_split(X, y, seed + 1), int(np.unique(y).size))


TASKS = {
    "up_vs_down_chirp": up_vs_down_chirp,
    "up_vs_down_hard": up_vs_down_chirp_hard,
    "chirp_vs_tone": chirp_vs_tone,
    "chirp_rate": chirp_rate,
}


if __name__ == "__main__":
    for name, fn in TASKS.items():
        Xtr, ytr, Xte, yte, = fn()[:4]
        nc = len(np.unique(ytr))
        print(f"{name:18s} Xtr={Xtr.shape} Xte={Xte.shape} nc={nc} "
              f"balance={np.bincount(ytr)}")
